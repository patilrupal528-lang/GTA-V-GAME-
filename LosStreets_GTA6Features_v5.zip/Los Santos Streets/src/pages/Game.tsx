import { Canvas } from "@react-three/fiber";
import { Suspense, useCallback, useEffect, useRef } from "react";
import { Stars, AdaptiveDpr, AdaptiveEvents } from "@react-three/drei";
import World from "@/components/game/World";
import Player from "@/components/game/Player";
import Vehicles from "@/components/game/Vehicles";
import NPCs from "@/components/game/NPCs";
import HUD from "@/components/game/HUD";
import MobileControls from "@/components/game/MobileControls";
import DayNight from "@/components/game/DayNight";
import Police from "@/components/game/Police";
import { ArrestOverlay } from "@/components/game/Police";
import Bullets from "@/components/game/Bullets";
import Missions from "@/components/game/Missions";
import Weather from "@/components/game/Weather";
import TrafficSystem from "@/components/game/TrafficSystem";
import ShopSystem from "@/components/game/ShopSystem";
import PauseMenu from "@/components/game/PauseMenu";
import Pickups from "@/components/game/Pickups";
import Explosions from "@/components/game/Explosions";
import RespawnSystem from "@/components/game/RespawnSystem";
import NoCrashSystem from "@/components/game/NoCrashSystem";
import Inventory from "@/components/game/Inventory";
import CharacterCustomization from "@/components/game/CharacterCustomization";
import AudioEngine from "@/components/game/Audio";
import StoryUI from "@/components/game/StoryUI";
import ErrorBoundary from "@/components/ErrorBoundary";
// ── New GTA VI features ──────────────────────────────────────────────────────
import SocialFeed from "@/components/game/SocialFeed";
import Wildlife from "@/components/game/Wildlife";
import WeaponSystem from "@/components/game/WeaponSystem";
import StealthSystem from "@/components/game/StealthSystem";
import Interiors from "@/components/game/Interiors";
import { MobileInput } from "@/components/game/types";
import { useGameStore } from "@/store/gameStore";
import { deviceProfile } from "@/utils/DeviceProfile";

export default function Game() {
  const {
    gameState, setGameState,
    paused, setPaused,
    shopOpen, setShopOpen,
    inventoryOpen, setInventoryOpen,
    wardrobeOpen, setWardrobeOpen,
    raining, setRaining,
    saveMsg,
    bullets, explosions,
    spawnBullet, removeBullet,
    spawnExplosion, removeExplosion,
    handleSave, handleLoad, toggleNoCrash,
  } = useGameStore();

  const respawnTargetRef = useRef<[number, number, number]>([60, 0, 0]);
  const missionIndexRef = useRef(0);
  const mobileInputRef = useRef<MobileInput>({
    joystick: { x: 0, y: 0 },
    shoot: false,
    enter: false,
    run: false,
    prone: false,
  });

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.code === "Escape" || e.code === "KeyP") setPaused((p) => !p);
      if (e.code === "KeyI") setInventoryOpen((v) => !v);
      if (e.code === "KeyC") setWardrobeOpen((v) => !v);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setRaining((r) => !r), 180_000);
    return () => clearInterval(t);
  }, [setRaining]);

  const handleMobileInput = useCallback((input: Partial<MobileInput>) => {
    if (input.joystick !== undefined) mobileInputRef.current.joystick = input.joystick;
    if (input.shoot    !== undefined) mobileInputRef.current.shoot    = input.shoot;
    if (input.enter    !== undefined) mobileInputRef.current.enter    = input.enter;
    if (input.run      !== undefined) mobileInputRef.current.run      = input.run;
    if (input.prone    !== undefined) mobileInputRef.current.prone    = input.prone;
  }, []);

  const handleRespawn = useCallback(() => {
    respawnTargetRef.current = [60, 0, 0];
  }, []);

  const handleCharacterSave = useCallback((cfg: typeof gameState.character) => {
    setGameState((s) => ({
      ...s,
      character:   cfg,
      missionText: `👕 Outfit changed to ${cfg.outfitName}!`,
    }));
  }, [setGameState]);

  const { dpr, antialias, perfMin, starCount, maxFPS } = deviceProfile;
  const fovForTier = deviceProfile.tier === "high" ? 58 : 62;

  return (
    <div className="game-container" style={{ width: "100vw", height: "100vh", overflow: "hidden", background: "#000" }}>
      <ErrorBoundary>
        <Canvas
          frameloop="always"
          camera={{ fov: fovForTier, near: 0.1, far: deviceProfile.tier === "high" ? 1800 : deviceProfile.tier === "mid" ? 1200 : 700 }}
          gl={{
            antialias,
            powerPreference: deviceProfile.tier === "low" ? "low-power" : "high-performance",
            stencil:    false,
            depth:      true,
            alpha:      false,
            ...(maxFPS === 120 ? { xrCompatible: false } : {}),
          }}
          dpr={[1, dpr]}
          performance={{ min: perfMin, max: dpr }}
        >
          <AdaptiveDpr pixelated />
          <AdaptiveEvents />

          <Suspense fallback={null}>
            <DayNight timeOfDay={gameState.timeOfDay} setGameState={setGameState} />
            {starCount > 0 && (
              <Stars radius={400} depth={50} count={starCount} factor={4} fade />
            )}
            <World />
            <TrafficSystem />
            <Weather raining={raining} />
            <Missions setGameState={setGameState} gameState={gameState} />
            <Pickups setGameState={setGameState} />
            <Player
              mobileInput={mobileInputRef}
              setGameState={setGameState}
              gameState={gameState}
              spawnBullet={spawnBullet}
              spawnExplosion={spawnExplosion}
              respawnTarget={respawnTargetRef}
            />
            <Vehicles  setGameState={setGameState} gameState={gameState} />
            <Police    gameState={gameState}        setGameState={setGameState} />
            <NPCs      gameState={gameState} />
            <Bullets   bullets={bullets}            removeBullet={removeBullet} />
            <Explosions explosions={explosions}     removeExplosion={removeExplosion} />

            {/* ── GTA VI New Features (3D scene) ── */}
            <Wildlife  gameState={gameState}        setGameState={setGameState} />
            <Interiors gameState={gameState}        setGameState={setGameState} />
          </Suspense>
        </Canvas>
      </ErrorBoundary>

      {/* Audio engine */}
      <AudioEngine />

      <NoCrashSystem  gameState={gameState}  setGameState={setGameState} />
      <RespawnSystem  gameState={gameState}  setGameState={setGameState} onRespawn={handleRespawn} />

      <HUD
        gameState={gameState}
        onToggleNoCrash={toggleNoCrash}
        onOpenInventory={() => setInventoryOpen(true)}
        onOpenWardrobe={()  => setWardrobeOpen(true)}
        onToggleRain={() => setRaining((r) => !r)}
        raining={raining}
      />
      <MobileControls onInput={handleMobileInput} gameState={gameState} />

      {/* Story dialogue UI */}
      <StoryUI missionText={gameState.missionText} missionIndex={missionIndexRef.current} />

      {/* Mission progress tracker */}
      <MissionTracker missionText={gameState.missionText} />

      {/* ── GTA VI New Features (HUD/UI) ── */}
      <SocialFeed   gameState={gameState} setGameState={setGameState} />
      <WeaponSystem gameState={gameState} setGameState={setGameState} />
      <StealthSystem gameState={gameState} setGameState={setGameState} />
      <ArrestOverlay wantedLevel={gameState.wanted} policeAlertLevel={gameState.policeAlertLevel} />

      {/* Wildlife attack alert */}
      {gameState.wildlifeAlert && (
        <div style={{
          position: "fixed", top: "38%", left: "50%", transform: "translateX(-50%)",
          background: "rgba(60,10,0,0.95)", border: "2px solid rgba(255,80,0,0.7)",
          borderRadius: 10, padding: "8px 22px", zIndex: 600, pointerEvents: "none",
          fontFamily: "monospace", fontSize: 13, fontWeight: 900, color: "#ff4400",
          display: "flex", alignItems: "center", gap: 10,
          animation: "wldFlash 0.3s infinite alternate",
          boxShadow: "0 0 20px rgba(255,60,0,0.4)",
        }}>
          🐊 ALLIGATOR ATTACK! — {Math.round(12)} DMG
          <style>{`@keyframes wldFlash{from{opacity:1}to{opacity:0.6}}`}</style>
        </div>
      )}

      {/* Recording NPC indicator */}
      {gameState.socialRecordingNpc && (
        <div style={{
          position: "fixed", top: "50%", right: 14,
          background: "rgba(0,0,0,0.85)", border: "1px solid rgba(255,30,80,0.5)",
          borderRadius: 8, padding: "5px 10px", zIndex: 500,
          fontFamily: "monospace", fontSize: 9, color: "#ff4488",
          display: "flex", alignItems: "center", gap: 5,
        }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#ff2244", animation: "recDot 0.5s infinite alternate" }} />
          NPC RECORDING
          <style>{`@keyframes recDot{from{opacity:1}to{opacity:0.2}}`}</style>
        </div>
      )}

      {/* Top HUD buttons */}
      <div style={{
        position: "fixed", top: 12, left: "50%", transform: "translateX(-50%)",
        display: "flex", gap: 7, zIndex: 15,
      }}>
        <TopBtn label="⏸ PAUSE"      onClick={() => setPaused((p) => !p)}        color="rgba(0,0,0,0.7)" />
        <TopBtn label="🎒 BAG"        onClick={() => setInventoryOpen(true)}       color="rgba(40,60,120,0.7)" />
        <TopBtn label="👕 FIT"        onClick={() => setWardrobeOpen(true)}        color="rgba(80,40,120,0.7)" />
        <TopBtn label={raining ? "🌧 RAIN" : "☀ DRY"} onClick={() => setRaining((r) => !r)} color="rgba(0,60,100,0.7)" />
      </div>

      {saveMsg && (
        <div style={{
          position: "fixed", top: "50%", left: "50%",
          transform: "translate(-50%,-50%)",
          background: "rgba(0,0,0,0.9)", border: "1px solid rgba(255,255,255,0.2)",
          borderRadius: 10, padding: "14px 30px",
          color: "#fff", fontFamily: "monospace", fontSize: 16,
          zIndex: 300, pointerEvents: "none",
        }}>
          {saveMsg}
        </div>
      )}

      {paused && !shopOpen && !inventoryOpen && !wardrobeOpen && (
        <PauseMenu
          gameState={gameState}
          onResume={()  => setPaused(false)}
          onOpenShop={() => { setShopOpen(true); setPaused(false); }}
          onOpenInventory={() => { setInventoryOpen(true); setPaused(false); }}
          onOpenWardrobe={()  => { setWardrobeOpen(true); setPaused(false); }}
          onSave={handleSave}
          onLoad={handleLoad}
          onToggleNoCrash={toggleNoCrash}
        />
      )}
      {shopOpen && (
        <ShopSystem gameState={gameState} setGameState={setGameState} onClose={() => setShopOpen(false)} />
      )}
      {inventoryOpen && (
        <Inventory gameState={gameState} onClose={() => setInventoryOpen(false)} />
      )}
      {wardrobeOpen && (
        <CharacterCustomization
          config={gameState.character}
          onChange={handleCharacterSave}
          onClose={() => setWardrobeOpen(false)}
        />
      )}
    </div>
  );
}

function MissionTracker({ missionText }: { missionText: string }) {
  if (!missionText) return null;
  const isComplete = missionText.includes("✅");
  return (
    <div style={{
      position: "fixed",
      top: 58,
      left: "50%",
      transform: "translateX(-50%)",
      background: isComplete ? "rgba(0,80,20,0.92)" : "rgba(0,20,60,0.92)",
      border: `1px solid ${isComplete ? "rgba(0,220,80,0.5)" : "rgba(80,160,255,0.4)"}`,
      borderRadius: 10,
      padding: "7px 22px",
      maxWidth: 520,
      width: "92vw",
      textAlign: "center",
      backdropFilter: "blur(8px)",
      zIndex: 20,
      boxShadow: isComplete ? "0 0 20px rgba(0,220,80,0.2)" : "0 4px 20px rgba(0,0,0,0.5)",
      transition: "all 0.4s ease",
    }}>
      <div style={{
        fontSize: 12,
        color: isComplete ? "#88ffaa" : "#cce4ff",
        fontFamily: "monospace",
        lineHeight: 1.5,
        fontWeight: isComplete ? 700 : 400,
      }}>
        {missionText}
      </div>
    </div>
  );
}

function TopBtn({ label, onClick, color }: { label: string; onClick: () => void; color: string }) {
  return (
    <button onClick={onClick} style={{
      background: color, border: "1px solid rgba(255,255,255,0.18)",
      borderRadius: 7, color: "#fff", fontSize: 11,
      fontFamily: "monospace", padding: "5px 11px",
      cursor: "pointer", fontWeight: 700,
      backdropFilter: "blur(4px)", letterSpacing: 0.4,
    }}>
      {label}
    </button>
  );
}
