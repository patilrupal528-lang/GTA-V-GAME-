import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { playerWorldPos } from "./Player";

const TRAFFIC_DEFS = [
  { id: 0, x: -150, z: 0, route: "horizontal" as const, lane: 4, color: "#e04040", speed: 14 },
  { id: 1, x: -100, z: 3, route: "horizontal" as const, lane: 3, color: "#4060e0", speed: 12 },
  { id: 2, x: 150, z: -3, route: "horizontal" as const, lane: -3, color: "#40a040", speed: 13 },
  { id: 3, x: 80, z: -4, route: "horizontal" as const, lane: -4, color: "#c0a000", speed: 11 },
  { id: 4, x: 0, z: -150, route: "vertical" as const, lane: 4, color: "#808080", speed: 12 },
  { id: 5, x: -3, z: -80, route: "vertical" as const, lane: 3, color: "#c06000", speed: 14 },
  { id: 6, x: 3, z: 150, route: "vertical" as const, lane: -3, color: "#008888", speed: 11 },
  { id: 7, x: 4, z: 100, route: "vertical" as const, lane: -4, color: "#884488", speed: 13 },
];

function TrafficCar({ def }: { def: typeof TRAFFIC_DEFS[0] }) {
  const ref = useRef<THREE.Group>(null);
  const posRef = useRef({ x: def.x, z: def.z });
  const speedRef = useRef(def.speed);
  const wheelRotRef = useRef(0);

  useFrame((_, delta) => {
    if (!ref.current) return;
    const dt = Math.min(delta, 0.05);
    const isH = def.route === "horizontal";
    const dir = def.lane > 0 ? 1 : -1;

    // Distance to player for near-player slowdown
    const cx = isH ? posRef.current.x : def.lane;
    const cz = isH ? def.lane : posRef.current.z;
    const dpx = cx - playerWorldPos.x;
    const dpz = cz - playerWorldPos.z;
    const distToPlayer = Math.sqrt(dpx * dpx + dpz * dpz);

    // Slow down near player
    const targetSpeed = distToPlayer < 12 ? def.speed * 0.2 : def.speed;
    speedRef.current += (targetSpeed - speedRef.current) * 4 * dt;

    // Wheel rotation
    wheelRotRef.current += speedRef.current * dt * 1.2;

    if (isH) {
      posRef.current.x += speedRef.current * dir * dt;
      if (posRef.current.x > 165) posRef.current.x = -165;
      if (posRef.current.x < -165) posRef.current.x = 165;
      ref.current.position.set(posRef.current.x, 0, def.lane);
      ref.current.rotation.y = dir > 0 ? -Math.PI / 2 : Math.PI / 2;
    } else {
      posRef.current.z += speedRef.current * dir * dt;
      if (posRef.current.z > 165) posRef.current.z = -165;
      if (posRef.current.z < -165) posRef.current.z = 165;
      ref.current.position.set(def.lane, 0, posRef.current.z);
      ref.current.rotation.y = dir > 0 ? 0 : Math.PI;
    }

    // Animate wheels
    const wFL = ref.current.getObjectByName(`w_fl_${def.id}`) as THREE.Mesh;
    const wFR = ref.current.getObjectByName(`w_fr_${def.id}`) as THREE.Mesh;
    const wRL = ref.current.getObjectByName(`w_rl_${def.id}`) as THREE.Mesh;
    const wRR = ref.current.getObjectByName(`w_rr_${def.id}`) as THREE.Mesh;
    const wr = wheelRotRef.current * dir;
    [wFL, wFR, wRL, wRR].forEach(w => { if (w) w.rotation.x = wr; });

    // Distance cull
    const gdx = cx - playerWorldPos.x, gdz = cz - playerWorldPos.z;
    ref.current.visible = (gdx * gdx + gdz * gdz) < 220 * 220;
  });

  return (
    <group ref={ref} position={[def.x, 0, def.z]}>
      {/* Body */}
      <mesh position={[0, 0.5, 0]} castShadow>
        <boxGeometry args={[2.1, 0.65, 4.2]} />
        <meshLambertMaterial color={def.color} />
      </mesh>
      {/* Cabin */}
      <mesh position={[0, 1.05, -0.25]} castShadow>
        <boxGeometry args={[1.8, 0.62, 2.1]} />
        <meshLambertMaterial color={def.color} />
      </mesh>
      {/* Windshield */}
      <mesh position={[0, 1.08, 0.92]}>
        <boxGeometry args={[1.65, 0.55, 0.06]} />
        <meshLambertMaterial color="#88ccff" transparent opacity={0.45} />
      </mesh>
      {/* Headlights */}
      <mesh position={[0, 0.55, 2.12]}>
        <boxGeometry args={[1.5, 0.2, 0.04]} />
        <meshLambertMaterial color="#fff" emissive="#ffffc0" emissiveIntensity={0.7} />
      </mesh>
      {/* Taillights */}
      <mesh position={[0, 0.55, -2.12]}>
        <boxGeometry args={[1.5, 0.2, 0.04]} />
        <meshLambertMaterial color="#ff1111" emissive="#ff0000" emissiveIntensity={0.9} />
      </mesh>
      {/* Wheels with rotation names */}
      {([
        [`w_fl_${def.id}`, -0.92, -0.2, 1.3],
        [`w_fr_${def.id}`,  0.92, -0.2, 1.3],
        [`w_rl_${def.id}`, -0.92, -0.2, -1.3],
        [`w_rr_${def.id}`,  0.92, -0.2, -1.3],
      ] as [string, number, number, number][]).map(([name, wx, wy, wz]) => (
        <mesh key={name} name={name} position={[wx, wy, wz]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.38, 0.38, 0.27, 10]} />
          <meshLambertMaterial color="#111" />
        </mesh>
      ))}
      {/* Hub caps */}
      {([ [-0.92, -0.2, 1.3], [0.92, -0.2, 1.3], [-0.92, -0.2, -1.3], [0.92, -0.2, -1.3] ] as [number,number,number][]).map(([wx, wy, wz], i) => (
        <mesh key={`h${i}`} position={[wx > 0 ? wx + 0.14 : wx - 0.14, wy, wz]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.2, 0.2, 0.04, 8]} />
          <meshLambertMaterial color="#555" />
        </mesh>
      ))}
    </group>
  );
}

export default function TrafficSystem() {
  return (
    <group>
      {TRAFFIC_DEFS.map((d) => <TrafficCar key={d.id} def={d} />)}
    </group>
  );
}
