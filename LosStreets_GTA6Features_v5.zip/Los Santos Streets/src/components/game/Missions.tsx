import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState } from "./types";
import { playerWorldPos } from "./Player";
import { playCheckpoint } from "./Audio";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

export const MISSIONS = [
  // ── ACT 1: Vice City Arrival ─────────────────────────────────────────────
  {
    id: 0, giver: "LUCIA", giverColor: "#ff44aa",
    title: "Welcome to Leonida",
    description: "Lucia: Meet me at the Vice City PD steps. Don't be late.",
    checkpoint: { x: 0, z: -30 },
    reward: 500,
    nextText: "Lucia: 'This city runs on glamour and crime. We're gonna own it.'",
  },
  {
    id: 1, giver: "JASON", giverColor: "#4488ff",
    title: "Ocean Drive Hustle",
    description: "Jason has a job on Ocean Drive. Hit the strip fast.",
    checkpoint: { x: 255, z: 55 },
    reward: 1800,
    nextText: "Jason: 'The real money's in the Keys. Follow my lead.'",
  },
  {
    id: 2, giver: "LUCIA", giverColor: "#ff44aa",
    title: "Keys Run",
    description: "Lucia needs a package from the first Leonida Key island.",
    checkpoint: { x: 140, z: 280 },
    reward: 2500,
    nextText: "Lucia: 'Beautiful, right? Now the swamp. Stay armed.'",
  },
  // ── ACT 2: Grassrivers ───────────────────────────────────────────────────
  {
    id: 3, giver: "CAL", giverColor: "#44cc44",
    title: "Into the Grassrivers",
    description: "Cal: Head into the Grassrivers wetlands. Watch for gators.",
    checkpoint: { x: -130, z: 100 },
    reward: 3000,
    nextText: "Cal: 'Found what I needed. Now meet me at the Alligator Den.'",
  },
  {
    id: 4, giver: "CAL", giverColor: "#44cc44",
    title: "Swamp Contacts",
    description: "Cal's contact is deep in the Grassrivers. Navigate through.",
    checkpoint: { x: -200, z: 200 },
    reward: 4000,
    nextText: "Cal: 'Port Gellhorn needs our attention next. Big score.'",
  },
  // ── ACT 3: Port Gellhorn ─────────────────────────────────────────────────
  {
    id: 5, giver: "JASON", giverColor: "#4488ff",
    title: "Port Gellhorn Delivery",
    description: "Jason: Bring the goods to Port Gellhorn docks. Don't get stopped.",
    checkpoint: { x: -285, z: -220 },
    reward: 5000,
    nextText: "Jason: 'The refinery. Our biggest payday is right there.'",
  },
  {
    id: 6, giver: "JASON", giverColor: "#4488ff",
    title: "Refinery Recon",
    description: "Scope out the Port Gellhorn oil refinery complex.",
    checkpoint: { x: -357, z: -260 },
    reward: 6000,
    nextText: "Jason: 'Seven figures. Just need one more piece of the puzzle.'",
  },
  // ── ACT 4: Lake Leonida & Mountains ──────────────────────────────────────
  {
    id: 7, giver: "LUCIA", giverColor: "#ff44aa",
    title: "Lake Rendezvous",
    description: "Lucia: Lay low. Meet me at Lake Leonida shore.",
    checkpoint: { x: -90, z: -320 },
    reward: 4500,
    nextText: "Lucia: 'Caliga. The answer's at the top of Mount Caliga.'",
  },
  {
    id: 8, giver: "CAL", giverColor: "#44cc44",
    title: "Mountain Climb",
    description: "Cal: Reach the Mount Caliga national park ranger station.",
    checkpoint: { x: 50, z: -380 },
    reward: 7000,
    nextText: "Cal: 'The cable car goes to the peak. They won't follow us there.'",
  },
  {
    id: 9, giver: "LUCIA", giverColor: "#ff44aa",
    title: "Above the Clouds",
    description: "Lucia: Reach the cable car station at the base of Caliga peak.",
    checkpoint: { x: 0, z: -390 },
    reward: 8000,
    nextText: "Lucia: 'I can see all of Leonida from here. All of it is ours.'",
  },
  // ── ACT 5: Grand Heist ───────────────────────────────────────────────────
  {
    id: 10, giver: "JASON", giverColor: "#4488ff",
    title: "Vice City Vice Versa",
    description: "Hit the Vice City Maze Bank. Back to where it all started.",
    checkpoint: { x: 120, z: -30 },
    reward: 15000,
    nextText: "Jason: 'Sixty million. Split three ways. Fair enough?' 💰",
  },
  {
    id: 11, giver: "ALL THREE", giverColor: "#ffcc00",
    title: "Leonida's Finest",
    description: "The final getaway — race to the Leonida Keys escape boat.",
    checkpoint: { x: 130, z: 290 },
    reward: 50000,
    nextText: "Lucia: 'Leonida, you beautiful beast. We made it.' ✈️ THE END",
  },
];

// Story NPC giver positions
const STORY_NPCS = [
  { x: 0,    z: -28,  name: "LUCIA",  color: "#ff44aa" },
  { x: 255,  z: 50,   name: "JASON",  color: "#4488ff" },
  { x: -130, z: 95,   name: "CAL",    color: "#44cc44" },
];

function Checkpoint({ x, z }: { x: number; z: number }) {
  const ref = useRef<THREE.Mesh>(null);
  const beamRef = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (ref.current) {
      ref.current.rotation.y += delta * 1.9;
      ref.current.position.y = 1.5 + Math.sin(Date.now() * 0.003) * 0.35;
    }
    if (beamRef.current) beamRef.current.rotation.y -= delta * 0.5;
  });

  return (
    <group position={[x, 0, z]}>
      <mesh ref={ref} position={[0, 1.5, 0]}>
        <octahedronGeometry args={[1.4, 0]} />
        <meshLambertMaterial color="#ff44aa" emissive="#cc0088" emissiveIntensity={0.9} transparent opacity={0.9} />
      </mesh>
      <mesh position={[0, 0.05, 0]}>
        <cylinderGeometry args={[3.5, 3.5, 0.12, 28]} />
        <meshLambertMaterial color="#ff44aa" transparent opacity={0.28} />
      </mesh>
      <mesh ref={beamRef} position={[0, 14, 0]}>
        <cylinderGeometry args={[0.12, 0.9, 28, 8]} />
        <meshLambertMaterial color="#ff44aa" transparent opacity={0.1} emissive="#ff0088" emissiveIntensity={0.3} />
      </mesh>
      <pointLight color="#ff44aa" intensity={5} distance={24} position={[0, 2, 0]} />
    </group>
  );
}

function StoryNPCMarker({ x, z, name, color }: { x: number; z: number; name: string; color: string }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => {
    if (!ref.current) return;
    const dx = x - playerWorldPos.x, dz = z - playerWorldPos.z;
    ref.current.visible = (dx * dx + dz * dz) < 130 * 130;
  });
  return (
    <group ref={ref} position={[x, 0, z]}>
      {/* Body */}
      <mesh position={[0, 1.1, 0]} castShadow>
        <boxGeometry args={[0.55, 0.76, 0.35]} />
        <meshLambertMaterial color={color} />
      </mesh>
      {/* Head */}
      <mesh position={[0, 1.88, 0]} castShadow>
        <boxGeometry args={[0.44, 0.44, 0.44]} />
        <meshLambertMaterial color="#d4a070" />
      </mesh>
      {/* Arms */}
      <mesh position={[-0.38, 1.1, 0]}><boxGeometry args={[0.18, 0.62, 0.18]} /><meshLambertMaterial color={color} /></mesh>
      <mesh position={[0.38, 1.1, 0]}><boxGeometry args={[0.18, 0.62, 0.18]} /><meshLambertMaterial color={color} /></mesh>
      {/* Legs */}
      <mesh position={[-0.14, 0.42, 0]}><boxGeometry args={[0.22, 0.62, 0.22]} /><meshLambertMaterial color="#1a1a2e" /></mesh>
      <mesh position={[0.14, 0.42, 0]}><boxGeometry args={[0.22, 0.62, 0.22]} /><meshLambertMaterial color="#1a1a2e" /></mesh>
      {/* Ground ring */}
      <mesh position={[0, 0.04, 0]}>
        <cylinderGeometry args={[1.8, 1.8, 0.08, 20]} />
        <meshLambertMaterial color={color} transparent opacity={0.55} emissive={color} emissiveIntensity={0.5} />
      </mesh>
      <pointLight color={color} intensity={2.5} distance={8} position={[0, 3, 0]} />
    </group>
  );
}

export default function Missions({ gameState, setGameState }: Props) {
  const missionIndexRef = useRef(0);
  const completedRef = useRef(false);
  const cooldownRef = useRef(0);

  useFrame((_, delta) => {
    cooldownRef.current -= delta;
    if (cooldownRef.current > 0) return;

    const mIdx = missionIndexRef.current;
    if (mIdx >= MISSIONS.length) return;

    const mission = MISSIONS[mIdx];
    const px = playerWorldPos.x;
    const pz = playerWorldPos.z;
    const dx = px - mission.checkpoint.x;
    const dz = pz - mission.checkpoint.z;
    const dist = Math.sqrt(dx * dx + dz * dz);

    if (dist < 5.5 && !completedRef.current) {
      completedRef.current = true;
      cooldownRef.current = 3.5;
      playCheckpoint();

      setGameState((s) => ({
        ...s,
        money: s.money + mission.reward,
        score: s.score + mission.reward * 10,
        missionText: `✅ [${mission.giver}] Complete! +$${mission.reward.toLocaleString()} | ${mission.nextText}`,
        missionActive: mIdx + 1 < MISSIONS.length,
      }));

      missionIndexRef.current = mIdx + 1;
      completedRef.current = false;
    } else if (!completedRef.current) {
      const dir = dist > 0 ? `${Math.round(dist)}m` : "HERE!";
      const newText = `📍 [${mission.giver}] ${mission.title}: ${mission.description} — ${dir}`;
      setGameState((s) =>
        s.missionText === newText ? s : { ...s, missionText: newText, missionActive: true }
      );
    }
  });

  const currentMission = MISSIONS[missionIndexRef.current];
  const nextMission = MISSIONS[missionIndexRef.current + 1];

  return (
    <group>
      {currentMission && (
        <Checkpoint x={currentMission.checkpoint.x} z={currentMission.checkpoint.z} />
      )}

      {STORY_NPCS.map((npc) => (
        <StoryNPCMarker key={npc.name} x={npc.x} z={npc.z} name={npc.name} color={npc.color} />
      ))}

      {/* Next mission faint preview */}
      {nextMission && (
        <group position={[nextMission.checkpoint.x, 0, nextMission.checkpoint.z]}>
          <mesh position={[0, 0.05, 0]}>
            <cylinderGeometry args={[2, 2, 0.06, 20]} />
            <meshLambertMaterial color="#ffcc00" transparent opacity={0.12} />
          </mesh>
        </group>
      )}
    </group>
  );
}
