import { GameState } from "./types";

interface Props {
  gameState: GameState;
  onResume: () => void;
  onOpenShop: () => void;
  onOpenInventory: () => void;
  onOpenWardrobe: () => void;
  onSave: () => void;
  onLoad: () => void;
  onToggleNoCrash: () => void;
}

export default function PauseMenu({
  gameState, onResume, onOpenShop, onOpenInventory,
  onOpenWardrobe, onSave, onLoad, onToggleNoCrash,
}: Props) {
  return (
    <div style={{
      position:"fixed",inset:0,background:"rgba(0,0,0,0.92)",
      zIndex:90,display:"flex",alignItems:"center",justifyContent:"center",
      fontFamily:"monospace",
    }}>
      <div style={{
        background:"linear-gradient(160deg,#0d0d1a 0%,#121220 100%)",
        border:"2px solid rgba(255,255,255,0.1)",
        borderRadius:22,padding:34,width:"min(380px,92vw)",
        textAlign:"center",boxShadow:"0 0 80px rgba(0,0,0,0.9)",
      }}>
        <div style={{ fontSize:42,fontWeight:900,color:"#fff",letterSpacing:6,marginBottom:0 }}>GTA V</div>
        <div style={{ fontSize:10,color:"#444",letterSpacing:4,marginBottom:4 }}>LOS SANTOS • MOBILE</div>
        <div style={{ fontSize:12,color:"#555",marginBottom:18,letterSpacing:2 }}>— PAUSED —</div>

        {/* Stats grid */}
        <div style={{
          background:"rgba(255,255,255,0.04)",borderRadius:12,padding:"12px 16px",
          marginBottom:20,display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,
        }}>
          {[
            ["❤️ HP",    `${Math.round(gameState.health)}%`],
            ["🛡️ AP",   `${Math.round(gameState.armor)}%`],
            ["💰 Cash",  `$${gameState.money.toLocaleString()}`],
            ["⭐ Wanted",`${gameState.wanted}/5`],
            ["🔫 Ammo",  `${gameState.ammo}/${gameState.maxAmmo}`],
            ["🏆 Score", gameState.score.toLocaleString()],
            ["🎯 Kills", gameState.kills.toString()],
            ["💀 Deaths",gameState.deaths.toString()],
          ].map(([l,v])=>(
            <div key={l} style={{ textAlign:"left" }}>
              <div style={{ fontSize:9,color:"#444" }}>{l}</div>
              <div style={{ fontSize:13,color:"#ddd",fontWeight:700 }}>{v}</div>
            </div>
          ))}
        </div>

        {/* Outfit info */}
        {gameState.character?.outfitName && (
          <div style={{
            background:"rgba(120,40,180,0.2)",border:"1px solid rgba(180,100,255,0.3)",
            borderRadius:8,padding:"5px 14px",marginBottom:14,
            fontFamily:"monospace",fontSize:11,color:"#cc88ff",
          }}>
            👕 Outfit: <b>{gameState.character.outfitName}</b>
          </div>
        )}

        {/* Action buttons */}
        <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
          <Btn label="▶  RESUME"                 color="#004d22" border="#00aa55" onClick={onResume} />
          <Btn label="🏪  AMMU-NATION SHOP"       color="#003366" border="#0066cc" onClick={onOpenShop} />
          <Btn label="🎒  INVENTORY"              color="#2a1a55" border="#6644cc" onClick={onOpenInventory} />
          <Btn label="👕  WARDROBE"               color="#44115a" border="#aa44cc" onClick={onOpenWardrobe} />
          <Btn
            label={gameState.noCrash ? "🛡️  GOD MODE — ON" : "☠  GOD MODE — OFF"}
            color={gameState.noCrash ? "#004422" : "#2a2a2a"}
            border={gameState.noCrash ? "#00cc66" : "#555"}
            onClick={onToggleNoCrash}
          />
          <Btn label="💾  SAVE GAME"              color="#3a2a00" border="#998800" onClick={onSave} />
          <Btn label="📂  LOAD GAME"              color="#2a1a3a" border="#886699" onClick={onLoad} />
        </div>

        <div style={{ marginTop:16,color:"#333",fontSize:10,lineHeight:2 }}>
          WASD — Move &nbsp;|&nbsp; Shift — Run &nbsp;|&nbsp; Space — Shoot<br/>
          F — Enter/Exit Car &nbsp;|&nbsp; I — Inventory &nbsp;|&nbsp; C — Wardrobe &nbsp;|&nbsp; P — Pause
        </div>
      </div>
    </div>
  );
}

function Btn({ label, color, border, onClick }: { label:string; color:string; border:string; onClick:()=>void }) {
  return (
    <button
      onClick={onClick}
      style={{
        background:color, border:`1px solid ${border}`,
        borderRadius:10, padding:"11px 20px", color:"#fff",
        fontSize:13, fontWeight:700, fontFamily:"monospace",
        cursor:"pointer", letterSpacing:0.5, transition:"opacity 0.15s, transform 0.1s",
      }}
      onMouseEnter={(e)=>{e.currentTarget.style.opacity="0.78";e.currentTarget.style.transform="scale(0.985)";}}
      onMouseLeave={(e)=>{e.currentTarget.style.opacity="1";e.currentTarget.style.transform="scale(1)";}}
    >
      {label}
    </button>
  );
}
