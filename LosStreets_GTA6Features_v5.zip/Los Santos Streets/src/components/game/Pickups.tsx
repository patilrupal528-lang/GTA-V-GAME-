import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState, PickupData } from "./types";
import { playerWorldPos } from "./Player";
import { playPickup } from "./Audio";

const PICKUP_RADIUS = 2.5;

const INITIAL_PICKUPS: PickupData[] = [
  { id: 0, x: 8, z: -5, type: "health", collected: false },
  { id: 1, x: -12, z: 7, type: "ammo", collected: false },
  { id: 2, x: 18, z: 18, type: "money", collected: false },
  { id: 3, x: -22, z: -18, type: "armor", collected: false },
  { id: 4, x: 35, z: 10, type: "health", collected: false },
  { id: 5, x: -35, z: -10, type: "ammo", collected: false },
  { id: 6, x: 0, z: 35, type: "money", collected: false },
  { id: 7, x: 0, z: -35, type: "money", collected: false },
  { id: 8, x: 50, z: 50, type: "weapon_rifle", collected: false },
  { id: 9, x: -50, z: -50, type: "weapon_shotgun", collected: false },
  { id: 10, x: 75, z: -10, type: "ammo", collected: false },
  { id: 11, x: -75, z: 10, type: "health", collected: false },
  { id: 12, x: 25, z: -70, type: "money", collected: false },
  { id: 13, x: -25, z: 70, type: "armor", collected: false },
  { id: 14, x: 100, z: 5, type: "weapon_sniper", collected: false },
  { id: 15, x: -5, z: 100, type: "health", collected: false },
  { id: 16, x: 5, z: -100, type: "ammo", collected: false },
  { id: 17, x: 60, z: 60, type: "money", collected: false },
  { id: 18, x: -60, z: -60, type: "money", collected: false },
  { id: 19, x: 40, z: -40, type: "armor", collected: false },
];

const PICKUP_CONFIG: Record<PickupData["type"], {
  color: string; emissive: string; icon: string;
  label: string; size: number; shape: "sphere" | "box" | "star";
}> = {
  health:         { color: "#ff2244", emissive: "#cc0022", icon: "❤️", label: "+50 HP",    size: 0.55, shape: "sphere" },
  armor:          { color: "#2244ff", emissive: "#0022cc", icon: "🛡️", label: "+50 AP",    size: 0.55, shape: "box" },
  ammo:           { color: "#ffaa00", emissive: "#cc8800", icon: "🔫", label: "+30 Ammo",  size: 0.45, shape: "box" },
  money:          { color: "#00dd44", emissive: "#00aa22", icon: "💰", label: "+$500",     size: 0.5,  shape: "sphere" },
  weapon_rifle:   { color: "#888888", emissive: "#444444", icon: "🔫", label: "Rifle",     size: 0.6,  shape: "box" },
  weapon_shotgun: { color: "#996644", emissive: "#664422", icon: "🔫", label: "Shotgun",   size: 0.6,  shape: "box" },
  weapon_sniper:  { color: "#446688", emissive: "#224466", icon: "🎯", label: "Sniper",    size: 0.6,  shape: "box" },
};

function PickupMesh({ pickup }: { pickup: PickupData }) {
  const ref = useRef<THREE.Mesh>(null);
  const cfg = PICKUP_CONFIG[pickup.type];

  useFrame((_, delta) => {
    if (!ref.current) return;
    ref.current.rotation.y += delta * 2;
    ref.current.position.y = 0.8 + Math.sin(Date.now() * 0.003) * 0.25;
  });

  return (
    <group position={[pickup.x, 0, pickup.z]}>
      {/* Ground ring */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]}>
        <ringGeometry args={[0.7, 1.0, 20]} />
        <meshLambertMaterial color={cfg.color} transparent opacity={0.4} side={THREE.DoubleSide} />
      </mesh>
      {/* Pickup item */}
      <mesh ref={ref} position={[0, 0.8, 0]}>
        {cfg.shape === "sphere"
          ? <sphereGeometry args={[cfg.size, 10, 10]} />
          : <boxGeometry args={[cfg.size * 1.4, cfg.size * 0.8, cfg.size * 1.4]} />
        }
        <meshLambertMaterial color={cfg.color} emissive={cfg.emissive} emissiveIntensity={0.6} />
      </mesh>
      <pointLight color={cfg.color} intensity={1.5} distance={6} position={[0, 1, 0]} />
    </group>
  );
}

interface Props {
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

export default function Pickups({ setGameState }: Props) {
  const [pickups, setPickups] = useState<PickupData[]>(INITIAL_PICKUPS);
  const cooldownRef = useRef<Record<number, number>>({});

  useFrame((_, delta) => {
    for (const id in cooldownRef.current) {
      cooldownRef.current[Number(id)] -= delta;
    }

    setPickups((prev) => {
      let changed = false;
      const next = prev.map((p) => {
        if (p.collected) return p;
        if ((cooldownRef.current[p.id] ?? 0) > 0) return p;

        const dx = playerWorldPos.x - p.x;
        const dz = playerWorldPos.z - p.z;
        if (dx * dx + dz * dz < PICKUP_RADIUS * PICKUP_RADIUS) {
          changed = true;
          cooldownRef.current[p.id] = 30; // respawn after 30s

          // Apply pickup effect
          setGameState((s) => {
            const updates: Partial<GameState> = {};
            switch (p.type) {
              case "health":
                updates.health = Math.min(100, s.health + 50);
                updates.missionText = "❤️ +50 Health restored!";
                break;
              case "armor":
                updates.armor = Math.min(100, s.armor + 50);
                updates.missionText = "🛡️ +50 Armor picked up!";
                break;
              case "ammo":
                updates.ammo = Math.min(s.maxAmmo, s.ammo + 30);
                updates.missionText = "🔫 +30 Ammo collected!";
                break;
              case "money":
                updates.money = s.money + 500;
                updates.score = s.score + 500;
                updates.missionText = "💰 +$500 found!";
                break;
              case "weapon_rifle":
                updates.weapon = "rifle"; updates.ammo = 30; updates.maxAmmo = 30;
                updates.missionText = "🔫 Assault Rifle picked up!";
                break;
              case "weapon_shotgun":
                updates.weapon = "shotgun"; updates.ammo = 8; updates.maxAmmo = 8;
                updates.missionText = "🔫 Shotgun picked up!";
                break;
              case "weapon_sniper":
                updates.weapon = "sniper"; updates.ammo = 10; updates.maxAmmo = 10;
                updates.missionText = "🎯 Sniper Rifle picked up!";
                break;
            }
            const inv = [...s.inventory];
            const existing = inv.find((i) => i.id === p.type);
            if (existing) existing.quantity++;
            else inv.push({ id: p.type, name: p.type.replace("_", " "), icon: PICKUP_CONFIG[p.type].icon, quantity: 1 });
            updates.inventory = inv;
            return { ...s, ...updates };
          });

          playPickup();
          // Respawn after delay
          setTimeout(() => {
            setPickups((pp) => pp.map((pp2) => pp2.id === p.id ? { ...pp2, collected: false } : pp2));
            cooldownRef.current[p.id] = 0;
          }, 30000);

          return { ...p, collected: true };
        }
        return p;
      });
      return changed ? next : prev;
    });
  });

  return (
    <group>
      {pickups.filter((p) => !p.collected).map((p) => (
        <PickupMesh key={p.id} pickup={p} />
      ))}
    </group>
  );
}
