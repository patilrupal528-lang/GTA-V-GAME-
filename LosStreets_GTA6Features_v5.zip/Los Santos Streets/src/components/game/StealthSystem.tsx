/**
 * StealthSystem — GTA VI Prone + Stealth mechanics
 *
 * • Prone (ground crawl) — press Z or stealth button
 * • Crouch (half-height)
 * • Stealth awareness meter — NPCs/police spot you slower
 * • Visual indicators: stealth HUD overlay + awareness ring
 */

import { useEffect, useRef, useState, useCallback } from "react";
import { GameState } from "./types";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

// Awareness level text
function awarenessLabel(level: number) {
  if (level < 0.15) return { text: "HIDDEN", color: "#00ff44" };
  if (level < 0.4)  return { text: "CAUTION", color: "#ffcc00" };
  if (level < 0.7)  return { text: "NOTICED", color: "#ff8800" };
  return { text: "SPOTTED!", color: "#ff2222" };
}

export default function StealthSystem({ gameState, setGameState }: Props) {
  const [awareness, setAwareness] = useState(0);
  const awarenessRef = useRef(0);
  const tickRef = useRef<ReturnType<typeof setInterval>>();

  // Awareness tick — rises faster when standing/running, drops in stealth/prone
  useEffect(() => {
    tickRef.current = setInterval(() => {
      setAwareness((prev) => {
        let next = prev;
        if (gameState.isProne) {
          next -= 0.04;
        } else if (gameState.stealthMode) {
          next -= 0.02;
        } else if (gameState.wanted > 0) {
          next += 0.035 * gameState.wanted;
        } else {
          next -= 0.01;
        }
        next = Math.max(0, Math.min(1, next));
        awarenessRef.current = next;

        // If fully spotted and not wanted, raise wanted level
        if (next >= 0.95 && gameState.wanted < 1 && gameState.kills > 0) {
          setGameState((s) => ({ ...s, wanted: Math.min(5, s.wanted + 1) }));
        }
        return next;
      });
    }, 200);
    return () => clearInterval(tickRef.current);
  }, [gameState.isProne, gameState.stealthMode, gameState.wanted, gameState.kills, setGameState]);

  // Keyboard: Z = prone, C = crouch/stealth toggle
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "z" || e.key === "Z") {
        setGameState((s) => ({
          ...s,
          isProne: !s.isProne,
          isCrouching: false,
          stealthMode: !s.isProne,
        }));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setGameState]);

  const toggleProne = useCallback(() => {
    setGameState((s) => ({
      ...s,
      isProne: !s.isProne,
      isCrouching: s.isProne ? false : s.isCrouching,
      stealthMode: !s.isProne || s.isCrouching,
    }));
  }, [setGameState]);

  const toggleCrouch = useCallback(() => {
    setGameState((s) => ({
      ...s,
      isCrouching: !s.isCrouching,
      isProne: false,
      stealthMode: !s.isCrouching,
    }));
  }, [setGameState]);

  const isStealthy = gameState.isProne || gameState.stealthMode;
  const { text: awText, color: awColor } = awarenessLabel(awareness);

  return (
    <>
      {/* Stealth controls */}
      <div style={{
        position: "fixed", bottom: 285, right: 14,
        display: "flex", flexDirection: "column", gap: 5,
        zIndex: 400, pointerEvents: "all",
      }}>
        {/* Prone */}
        <div
          onClick={toggleProne}
          style={{
            width: 52, height: 32,
            background: gameState.isProne ? "rgba(0,200,80,0.3)" : "rgba(0,0,0,0.8)",
            border: `1.5px solid ${gameState.isProne ? "rgba(0,255,100,0.6)" : "rgba(255,255,255,0.15)"}`,
            borderRadius: 8, cursor: "pointer",
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            boxShadow: gameState.isProne ? "0 0 12px rgba(0,255,100,0.3)" : "none",
            transition: "all 0.2s",
          }}
        >
          <span style={{ fontSize: 13 }}>🤸</span>
          <span style={{ fontFamily: "monospace", fontSize: 6, color: gameState.isProne ? "#00ff66" : "#666", fontWeight: 900 }}>PRONE</span>
        </div>

        {/* Crouch */}
        <div
          onClick={toggleCrouch}
          style={{
            width: 52, height: 32,
            background: gameState.isCrouching ? "rgba(0,150,200,0.3)" : "rgba(0,0,0,0.8)",
            border: `1.5px solid ${gameState.isCrouching ? "rgba(0,200,255,0.6)" : "rgba(255,255,255,0.15)"}`,
            borderRadius: 8, cursor: "pointer",
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            boxShadow: gameState.isCrouching ? "0 0 12px rgba(0,200,255,0.3)" : "none",
            transition: "all 0.2s",
          }}
        >
          <span style={{ fontSize: 13 }}>🧎</span>
          <span style={{ fontFamily: "monospace", fontSize: 6, color: gameState.isCrouching ? "#00ccff" : "#666", fontWeight: 900 }}>CROUCH</span>
        </div>
      </div>

      {/* Awareness HUD — bottom center */}
      {isStealthy && (
        <div style={{
          position: "fixed", bottom: 170, left: "50%", transform: "translateX(-50%)",
          display: "flex", flexDirection: "column", alignItems: "center", gap: 5,
          zIndex: 400, pointerEvents: "none",
        }}>
          {/* Mode label */}
          <div style={{
            background: "rgba(0,0,0,0.85)", border: `1px solid ${gameState.isProne ? "rgba(0,255,100,0.4)" : "rgba(0,200,255,0.4)"}`,
            borderRadius: 8, padding: "3px 16px",
            fontFamily: "monospace", fontSize: 10, fontWeight: 900, letterSpacing: 2,
            color: gameState.isProne ? "#00ff66" : "#00ccff",
          }}>
            {gameState.isProne ? "🤸 PRONE — CRAWLING" : "🧎 CROUCHED — STEALTH"}
          </div>

          {/* Awareness meter */}
          <div style={{
            background: "rgba(0,0,0,0.75)", borderRadius: 10, padding: "5px 12px",
            display: "flex", flexDirection: "column", gap: 3, alignItems: "center",
            border: `1px solid ${awColor}44`,
          }}>
            <div style={{ fontFamily: "monospace", fontSize: 8, color: awColor, fontWeight: 700, letterSpacing: 2 }}>
              AWARENESS: {awText}
            </div>
            <div style={{ width: 140, height: 7, background: "rgba(255,255,255,0.08)", borderRadius: 4, overflow: "hidden" }}>
              <div style={{
                width: `${awareness * 100}%`, height: "100%", borderRadius: 4,
                background: `linear-gradient(90deg, #00ff44, ${awColor})`,
                boxShadow: `0 0 6px ${awColor}`,
                transition: "width 0.3s",
              }} />
            </div>
            <div style={{
              display: "flex", gap: 10,
              fontFamily: "monospace", fontSize: 8, color: "#555",
            }}>
              <span>👁 Detection reduced by {gameState.isProne ? "80%" : "40%"}</span>
            </div>
          </div>
        </div>
      )}

      {/* Key hint — Z for prone */}
      {!isStealthy && (
        <div style={{
          position: "fixed", bottom: 10, right: 75,
          background: "rgba(0,0,0,0.5)", borderRadius: 5, padding: "2px 8px",
          fontFamily: "monospace", fontSize: 8, color: "#444",
          zIndex: 200,
        }}>
          [Z] Prone · [C] Crouch
        </div>
      )}
    </>
  );
}
