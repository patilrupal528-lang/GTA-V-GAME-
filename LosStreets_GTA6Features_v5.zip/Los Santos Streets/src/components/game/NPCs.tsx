import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState } from "./types";
import { playerWorldPos } from "./Player";
import { resolveCollision } from "../../utils/buildingCollisions";

interface NPCDef {
  id: number;
  x: number;
  z: number;
  speed: number;
  pathLength: number;
  skin: string;
  shirt: string;
  pants: string;
  shoes: string;
  tall?: boolean;
  hat?: string;
}

const NPC_DEFS: NPCDef[] = [
  { id: 0,  x: 5,    z: 14,   speed: 1.4, pathLength: 20, skin: "#e8b090", shirt: "#e03030", pants: "#222244", shoes: "#111" },
  { id: 1,  x: -5,   z: -14,  speed: 1.2, pathLength: 25, skin: "#c08060", shirt: "#3060e0", pants: "#333333", shoes: "#442211" },
  { id: 2,  x: 8,    z: 28,   speed: 1.7, pathLength: 18, skin: "#8a5030", shirt: "#30a030", pants: "#1a1a1a", shoes: "#222" },
  { id: 3,  x: -8,   z: -28,  speed: 1.0, pathLength: 22, skin: "#f0c8a0", shirt: "#c0a000", pants: "#4a3a00", shoes: "#553322", hat: "#884400" },
  { id: 4,  x: 64,   z: 5,    speed: 1.3, pathLength: 16, skin: "#5a3010", shirt: "#e06020", pants: "#2a1a00", shoes: "#111" },
  { id: 5,  x: -64,  z: -5,   speed: 1.5, pathLength: 20, skin: "#d09870", shirt: "#20a0a0", pants: "#003333", shoes: "#222" },
  { id: 6,  x: 3,    z: 68,   speed: 1.2, pathLength: 30, skin: "#e8b090", shirt: "#a020a0", pants: "#220022", shoes: "#333" },
  { id: 7,  x: -3,   z: -68,  speed: 1.1, pathLength: 28, skin: "#c08060", shirt: "#808080", pants: "#404040", shoes: "#222" },
  { id: 8,  x: 20,   z: 7,    speed: 1.6, pathLength: 14, skin: "#f0d0a0", shirt: "#ff4444", pants: "#222255", shoes: "#111", tall: true },
  { id: 9,  x: -20,  z: -7,   speed: 1.3, pathLength: 16, skin: "#b07050", shirt: "#44ff44", pants: "#113311", shoes: "#441100" },
  { id: 10, x: 0,    z: 40,   speed: 1.0, pathLength: 22, skin: "#e0c090", shirt: "#ffaa00", pants: "#443300", shoes: "#222", hat: "#111" },
  { id: 11, x: 0,    z: -40,  speed: 1.4, pathLength: 18, skin: "#c09070", shirt: "#00aaff", pants: "#003366", shoes: "#333" },
  { id: 12, x: 35,   z: -25,  speed: 1.2, pathLength: 24, skin: "#ffd0a8", shirt: "#cc6600", pants: "#334433", shoes: "#553311" },
  { id: 13, x: -35,  z: 25,   speed: 1.5, pathLength: 20, skin: "#a06040", shirt: "#6688cc", pants: "#223355", shoes: "#222" },
  { id: 14, x: 50,   z: -50,  speed: 1.1, pathLength: 26, skin: "#e8a870", shirt: "#eeeeee", pants: "#222222", shoes: "#333", tall: true },
  { id: 15, x: -50,  z: 50,   speed: 1.6, pathLength: 18, skin: "#7a4828", shirt: "#ff2244", pants: "#111133", shoes: "#110000" },
  { id: 16, x: 75,   z: 30,   speed: 1.3, pathLength: 22, skin: "#d4aa80", shirt: "#338866", pants: "#224422", shoes: "#332211" },
  { id: 17, x: -75,  z: -30,  speed: 1.4, pathLength: 20, skin: "#f8d4b0", shirt: "#884422", pants: "#553311", shoes: "#221100", hat: "#553311" },
  { id: 18, x: 10,   z: -55,  speed: 1.2, pathLength: 28, skin: "#b88060", shirt: "#aacc22", pants: "#335500", shoes: "#222" },
  { id: 19, x: -10,  z: 55,   speed: 1.5, pathLength: 18, skin: "#e0b880", shirt: "#cc22aa", pants: "#440033", shoes: "#333" },
];

function NPC({ def, wantedLevel }: { def: NPCDef; wantedLevel: number }) {
  const groupRef = useRef<THREE.Group>(null);
  const progressRef = useRef(Math.random() * def.pathLength * 2);
  const fleeRef = useRef(false);
  const startPos = useMemo(() => new THREE.Vector3(def.x, 0, def.z), [def.x, def.z]);
  const stepPhaseRef = useRef(Math.random() * Math.PI * 2);
  const scaleY = def.tall ? 1.12 : (0.88 + (def.id % 3) * 0.07);

  useFrame((_, delta) => {
    if (!groupRef.current) return;
    const dt = Math.min(delta, 0.05);

    const dx = def.x - playerWorldPos.x;
    const dz = def.z - playerWorldPos.z;
    const distSq = dx * dx + dz * dz;
    if (distSq > 180 * 180) { groupRef.current.visible = false; return; }
    groupRef.current.visible = true;

    const distToPlayer = playerWorldPos.distanceTo(groupRef.current.position);

    if (wantedLevel >= 2 && distToPlayer < 22) fleeRef.current = true;
    else if (distToPlayer > 32) fleeRef.current = false;

    if (fleeRef.current) {
      const away = new THREE.Vector3(
        groupRef.current.position.x - playerWorldPos.x, 0,
        groupRef.current.position.z - playerWorldPos.z
      ).normalize();
      const move = away.clone().multiplyScalar(4.2 * dt);
      groupRef.current.position.add(move);
      resolveCollision(groupRef.current.position, 0.3);
      groupRef.current.position.y = 0;
      groupRef.current.rotation.y = Math.atan2(away.x, away.z);
    } else {
      progressRef.current += dt * def.speed;
      const isVertical = def.id % 2 === 0;
      const totalPath = def.pathLength * 2;
      const p = ((progressRef.current % totalPath) + totalPath) % totalPath;
      const t = p < def.pathLength ? p : totalPath - p;

      if (isVertical) {
        groupRef.current.position.set(startPos.x, 0, startPos.z + t - def.pathLength / 2);
        groupRef.current.rotation.y = p < def.pathLength ? 0 : Math.PI;
      } else {
        groupRef.current.position.set(startPos.x + t - def.pathLength / 2, 0, startPos.z);
        groupRef.current.rotation.y = p < def.pathLength ? -Math.PI / 2 : Math.PI / 2;
      }
    }

    stepPhaseRef.current += dt * 5.5;
    const swing = Math.sin(stepPhaseRef.current) * 0.45;
    const armSwing = Math.sin(stepPhaseRef.current + Math.PI) * 0.32;
    const bobY = Math.abs(Math.sin(stepPhaseRef.current * 2)) * 0.025;

    const lLeg = groupRef.current.getObjectByName(`nL${def.id}`) as THREE.Mesh;
    const rLeg = groupRef.current.getObjectByName(`nR${def.id}`) as THREE.Mesh;
    if (lLeg) lLeg.rotation.x = swing;
    if (rLeg) rLeg.rotation.x = -swing;
    const lArm = groupRef.current.getObjectByName(`nAL${def.id}`) as THREE.Mesh;
    const rArm = groupRef.current.getObjectByName(`nAR${def.id}`) as THREE.Mesh;
    if (lArm) lArm.rotation.x = -armSwing;
    if (rArm) rArm.rotation.x = armSwing;
    const body = groupRef.current.getObjectByName(`nBody${def.id}`) as THREE.Mesh;
    if (body) body.position.y = 1.2 + bobY;
  });

  return (
    <group ref={groupRef} position={[def.x, 0, def.z]} scale={[1, scaleY, 1]}>
      {def.hat && (
        <>
          <mesh position={[0, 2.26, 0]}>
            <boxGeometry args={[0.52, 0.1, 0.52]} />
            <meshLambertMaterial color={def.hat} />
          </mesh>
          <mesh position={[0, 2.34, 0]}>
            <boxGeometry args={[0.38, 0.2, 0.38]} />
            <meshLambertMaterial color={def.hat} />
          </mesh>
        </>
      )}
      <mesh name={`nBody${def.id}`} position={[0, 1.2, 0]} castShadow>
        <boxGeometry args={[0.55, 0.76, 0.35]} />
        <meshLambertMaterial color={def.shirt} />
      </mesh>
      {/* Neck */}
      <mesh position={[0, 1.64, 0]}>
        <boxGeometry args={[0.18, 0.18, 0.18]} />
        <meshLambertMaterial color={def.skin} />
      </mesh>
      {/* Head */}
      <mesh position={[0, 1.9, 0]} castShadow>
        <boxGeometry args={[0.44, 0.44, 0.44]} />
        <meshLambertMaterial color={def.skin} />
      </mesh>
      {/* Eyes */}
      <mesh position={[-0.1, 1.94, 0.22]}>
        <boxGeometry args={[0.09, 0.07, 0.02]} />
        <meshLambertMaterial color="#111" />
      </mesh>
      <mesh position={[0.1, 1.94, 0.22]}>
        <boxGeometry args={[0.09, 0.07, 0.02]} />
        <meshLambertMaterial color="#111" />
      </mesh>
      {/* Arms */}
      <mesh name={`nAL${def.id}`} position={[-0.38, 1.2, 0]} castShadow>
        <boxGeometry args={[0.18, 0.62, 0.18]} />
        <meshLambertMaterial color={def.shirt} />
      </mesh>
      <mesh name={`nAR${def.id}`} position={[0.38, 1.2, 0]} castShadow>
        <boxGeometry args={[0.18, 0.62, 0.18]} />
        <meshLambertMaterial color={def.shirt} />
      </mesh>
      {/* Hands */}
      <mesh position={[-0.38, 0.85, 0]}>
        <boxGeometry args={[0.15, 0.16, 0.15]} />
        <meshLambertMaterial color={def.skin} />
      </mesh>
      <mesh position={[0.38, 0.85, 0]}>
        <boxGeometry args={[0.15, 0.16, 0.15]} />
        <meshLambertMaterial color={def.skin} />
      </mesh>
      {/* Belt */}
      <mesh position={[0, 0.82, 0]}>
        <boxGeometry args={[0.57, 0.07, 0.37]} />
        <meshLambertMaterial color="#333" />
      </mesh>
      {/* Legs */}
      <mesh name={`nL${def.id}`} position={[-0.14, 0.55, 0]} castShadow>
        <boxGeometry args={[0.22, 0.65, 0.22]} />
        <meshLambertMaterial color={def.pants} />
      </mesh>
      <mesh name={`nR${def.id}`} position={[0.14, 0.55, 0]} castShadow>
        <boxGeometry args={[0.22, 0.65, 0.22]} />
        <meshLambertMaterial color={def.pants} />
      </mesh>
      {/* Shoes */}
      <mesh position={[-0.14, 0.2, 0.06]}>
        <boxGeometry args={[0.24, 0.1, 0.36]} />
        <meshLambertMaterial color={def.shoes} />
      </mesh>
      <mesh position={[0.14, 0.2, 0.06]}>
        <boxGeometry args={[0.24, 0.1, 0.36]} />
        <meshLambertMaterial color={def.shoes} />
      </mesh>
    </group>
  );
}

export default function NPCs({ gameState }: { gameState: GameState }) {
  return (
    <group>
      {NPC_DEFS.map((def) => (
        <NPC key={def.id} def={def} wantedLevel={gameState.wanted} />
      ))}
    </group>
  );
}
