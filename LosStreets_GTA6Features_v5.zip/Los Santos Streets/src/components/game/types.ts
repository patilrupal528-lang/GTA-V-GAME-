export interface CharacterConfig {
  skinColor: string;
  outfitId: string;
  bodyColor: string;
  pantsColor: string;
  shoeColor: string;
  hatOn: boolean;
  glassesOn: boolean;
  chainOn: boolean;
  hatColor: string;
  outfitName: string;
}

export interface WeaponSlot {
  id: string;
  name: string;
  ammo: number;
  maxAmmo: number;
  icon: string;
  heavy: boolean; // heavy = stored in trunk only
}

export interface GameState {
  health: number;
  armor: number;
  money: number;
  wanted: number;
  inVehicle: boolean;
  vehicleSpeed: number;
  vehicleName: string;
  vehicleCategory: string;
  timeOfDay: number;
  score: number;
  ammo: number;
  maxAmmo: number;
  weapon: string | null;
  missionText: string;
  missionActive: boolean;
  nearVehicle: boolean;
  noCrash: boolean;
  swimming: boolean;
  deaths: number;
  kills: number;
  inventory: InventoryItem[];
  playerX: number;
  playerZ: number;
  character: CharacterConfig;
  // Stealth / movement
  isProne: boolean;
  isCrouching: boolean;
  stealthMode: boolean;
  // Weapon system
  carriedWeapons: WeaponSlot[];
  trunkWeapons: WeaponSlot[];
  maxCarrySlots: number;
  // Social media
  socialFeedActive: boolean;
  socialRecordingNpc: boolean;
  // Interior
  currentInterior: string | null;
  // Police
  policeAlertLevel: "none" | "patrol" | "surround" | "arrest";
  // Wildlife
  wildlifeAlert: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  icon: string;
  quantity: number;
}

export interface MobileInput {
  joystick: { x: number; y: number };
  shoot: boolean;
  enter: boolean;
  run: boolean;
  prone?: boolean;
}

export interface BulletData {
  id: number;
  position: [number, number, number];
  direction: [number, number, number];
}

export interface PickupData {
  id: number;
  x: number;
  z: number;
  type: "health" | "armor" | "ammo" | "money" | "weapon_rifle" | "weapon_shotgun" | "weapon_sniper";
  collected: boolean;
}

export interface ExplosionData {
  id: number;
  x: number;
  y: number;
  z: number;
  startTime: number;
}

export const DEFAULT_CHARACTER: CharacterConfig = {
  skinColor: "#e8b090",
  outfitId: "franklin",
  outfitName: "Franklin",
  bodyColor: "#1a6622",
  pantsColor: "#2a2a3a",
  shoeColor: "#222",
  hatOn: false,
  glassesOn: false,
  chainOn: false,
  hatColor: "#111",
};

export const INITIAL_CARRIED_WEAPONS: WeaponSlot[] = [
  { id: "pistol", name: "Pistol", ammo: 30, maxAmmo: 100, icon: "🔫", heavy: false },
];

export const TRUNK_WEAPONS_DEFAULT: WeaponSlot[] = [
  { id: "rifle",  name: "Assault Rifle", ammo: 90, maxAmmo: 250, icon: "🔫", heavy: true },
  { id: "shotgun",name: "Shotgun",        ammo: 12, maxAmmo: 48,  icon: "🔫", heavy: true },
];
