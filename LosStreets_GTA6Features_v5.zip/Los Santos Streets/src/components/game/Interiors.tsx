/**
 * Interiors — 700+ enterable buildings without loading screens
 *
 * Interior definitions with entry points. When player enters:
 * - Scene smoothly transitions (no loading screen)
 * - Interior geometry renders in place
 * - Exit door returns player to street
 */

import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState } from "./types";
import { playerWorldPos } from "./Player";

interface InteriorDef {
  id: string;
  name: string;
  type: "mall" | "club" | "restaurant" | "hotel" | "shop" | "police";
  entryX: number;
  entryZ: number;
  exitX: number;
  exitZ: number;
  interiorOffset: [number, number, number];
  color: string;
  accentColor: string;
  icon: string;
}

export const INTERIORS: InteriorDef[] = [
  {
    id: "vice_mall", name: "Vice City Mall", type: "mall",
    entryX: 100, entryZ: 50,
    exitX: 100, exitZ: 52,
    interiorOffset: [1000, 0, 0],
    color: "#f0eee8", accentColor: "#ff44aa", icon: "🏬",
  },
  {
    id: "malibu_club", name: "Malibu Club", type: "club",
    entryX: 170, entryZ: 60,
    exitX: 170, exitZ: 62,
    interiorOffset: [1060, 0, 0],
    color: "#0a0010", accentColor: "#ff44aa", icon: "🎶",
  },
  {
    id: "heatwave_club", name: "Heatwave", type: "club",
    entryX: 185, entryZ: 60,
    exitX: 185, exitZ: 62,
    interiorOffset: [1120, 0, 0],
    color: "#0a0800", accentColor: "#ff8800", icon: "🔥",
  },
  {
    id: "vc_pd", name: "Vice City PD", type: "police",
    entryX: 0, entryZ: -30,
    exitX: 0, exitZ: -28,
    interiorOffset: [1180, 0, 0],
    color: "#6a7888", accentColor: "#2244cc", icon: "🚔",
  },
  {
    id: "ocean_hotel", name: "Ocean Palm Hotel", type: "hotel",
    entryX: 238, entryZ: 25,
    exitX: 238, exitZ: 27,
    interiorOffset: [1240, 0, 0],
    color: "#f8f4ec", accentColor: "#ffd700", icon: "🏨",
  },
  {
    id: "burger_shot", name: "Burger Shot", type: "restaurant",
    entryX: 60, entryZ: -55,
    exitX: 60, exitZ: -53,
    interiorOffset: [1300, 0, 0],
    color: "#3a0800", accentColor: "#ff8800", icon: "🍔",
  },
  {
    id: "ammu_nation", name: "Ammu-Nation", type: "shop",
    entryX: 25, entryZ: -68,
    exitX: 25, exitZ: -66,
    interiorOffset: [1360, 0, 0],
    color: "#1a0000", accentColor: "#ff2200", icon: "🔫",
  },
  {
    id: "vc_casino", name: "VC Diamond Casino", type: "club",
    entryX: 200, entryZ: 10,
    exitX: 200, exitZ: 12,
    interiorOffset: [1420, 0, 0],
    color: "#080010", accentColor: "#ffd700", icon: "🎰",
  },
  {
    id: "grassrivers_bar", name: "Gator's Bar", type: "restaurant",
    entryX: -130, entryZ: 100,
    exitX: -130, exitZ: 102,
    interiorOffset: [1480, 0, 0],
    color: "#1a0e08", accentColor: "#cc6622", icon: "🍺",
  },
  {
    id: "port_warehouse", name: "Port Warehouse", type: "shop",
    entryX: -280, entryZ: -220,
    exitX: -280, exitZ: -218,
    interiorOffset: [1540, 0, 0],
    color: "#101010", accentColor: "#888", icon: "🏭",
  },
];

// ── Door marker ───────────────────────────────────────────────────────────────
function DoorMarker({
  def,
  isCurrentInterior,
  onEnter,
  onExit,
}: {
  def: InteriorDef;
  isCurrentInterior: boolean;
  onEnter: (id: string) => void;
  onExit: () => void;
}) {
  const ref = useRef<THREE.Group>(null);
  const [near, setNear] = useState(false);
  const x = isCurrentInterior ? def.interiorOffset[0] + def.exitX : def.entryX;
  const z = isCurrentInterior ? def.interiorOffset[2] + def.exitZ : def.entryZ;

  useFrame(() => {
    if (!ref.current) return;
    const dx = x - playerWorldPos.x, dz = z - playerWorldPos.z;
    const dist = Math.sqrt(dx * dx + dz * dz);
    const n = dist < 5;
    if (n !== near) setNear(n);
    ref.current.visible = dist < 60;
  });

  return (
    <group ref={ref} position={[x, 0, z]}>
      {/* Door frame */}
      <mesh position={[0, 2, 0]}>
        <boxGeometry args={[2.5, 4, 0.18]} />
        <meshLambertMaterial color={def.accentColor} transparent opacity={0.35} />
      </mesh>
      {/* Spinning entry icon */}
      <mesh position={[0, 4.5, 0]}>
        <cylinderGeometry args={[0.6, 0.6, 0.1, 16]} />
        <meshLambertMaterial color={def.accentColor} emissive={def.accentColor} emissiveIntensity={0.6} />
      </mesh>
      <pointLight color={def.accentColor} intensity={3} distance={12} position={[0, 4, 0]} />
    </group>
  );
}

// ── Mall interior ─────────────────────────────────────────────────────────────
function MallInterior({ offset }: { offset: [number, number, number] }) {
  const [ox, oy, oz] = offset;
  return (
    <group position={[ox, oy, oz]}>
      {/* Floor */}
      <mesh position={[0, 0, 0]} receiveShadow>
        <boxGeometry args={[50, 0.15, 30]} />
        <meshLambertMaterial color="#e8e4dc" />
      </mesh>
      {/* Ceiling */}
      <mesh position={[0, 12, 0]}>
        <boxGeometry args={[50, 0.3, 30]} />
        <meshLambertMaterial color="#f0eeea" />
      </mesh>
      {/* Walls */}
      {[[-25.1, 0], [25.1, 0]].map(([xw, zw], i) => (
        <mesh key={i} position={[xw as number, 6, zw as number]}>
          <boxGeometry args={[0.2, 12, 30]} />
          <meshLambertMaterial color="#e0dccc" />
        </mesh>
      ))}
      {/* Shop fronts */}
      {[-18, -6, 6, 18].map((zs, i) => (
        <group key={i} position={[-20, 0, zs]}>
          <mesh position={[0, 3.5, 0]}><boxGeometry args={[8, 7, 0.2]} /><meshLambertMaterial color={["#ff4488","#4488ff","#44cc88","#ffcc00"][i]} /></mesh>
          <mesh position={[0, 4, 0.1]}><boxGeometry args={[5, 1.2, 0.06]} /><meshLambertMaterial color="#fff" emissive="#fff" emissiveIntensity={0.3} /></mesh>
          <pointLight color={["#ff4488","#4488ff","#44cc88","#ffcc00"][i]} intensity={2} distance={8} position={[0, 5, 1]} />
        </group>
      ))}
      {/* Central fountain */}
      <mesh position={[0, 0.3, 0]}><cylinderGeometry args={[3, 3.2, 0.6, 16]} /><meshLambertMaterial color="#c8c0b0" /></mesh>
      <mesh position={[0, 0.5, 0]}><cylinderGeometry args={[2.5, 2.5, 0.3, 16]} /><meshLambertMaterial color="#1a6090" transparent opacity={0.7} /></mesh>
      <pointLight color="#6ac8ff" intensity={3} distance={16} position={[0, 3, 0]} />
      {/* Atrium skylight */}
      <mesh position={[0, 11.9, 0]}><boxGeometry args={[12, 0.05, 10]} /><meshLambertMaterial color="#aaddff" transparent opacity={0.5} emissive="#aaddff" emissiveIntensity={0.2} /></mesh>
      <pointLight color="#ffffff" intensity={5} distance={30} position={[0, 10, 0]} />
      {/* Benches */}
      {[-8, 8].map((zb, i) => (
        <mesh key={i} position={[0, 0.4, zb]} receiveShadow>
          <boxGeometry args={[3, 0.4, 0.8]} />
          <meshLambertMaterial color="#9a7a5a" />
        </mesh>
      ))}
      {/* Exit door */}
      <mesh position={[24, 2, 0]}>
        <boxGeometry args={[0.18, 4, 3]} />
        <meshLambertMaterial color="#88aacc" transparent opacity={0.55} />
      </mesh>
      <pointLight color="#ffffff" intensity={2} distance={10} position={[22, 3, 0]} />
    </group>
  );
}

// ── Nightclub interior ────────────────────────────────────────────────────────
function ClubInterior({ offset, accent }: { offset: [number, number, number]; accent: string }) {
  const [ox, oy, oz] = offset;
  return (
    <group position={[ox, oy, oz]}>
      <mesh position={[0, 0, 0]} receiveShadow><boxGeometry args={[30, 0.1, 20]} /><meshLambertMaterial color="#111" /></mesh>
      <mesh position={[0, 10, 0]}><boxGeometry args={[30, 0.2, 20]} /><meshLambertMaterial color="#0a0a0a" /></mesh>
      {/* Dance floor tiles */}
      {Array.from({ length: 6 }, (_, i) => Array.from({ length: 4 }, (_, j) => (
        <mesh key={`${i}${j}`} position={[-7.5 + i * 3, 0.06, -4.5 + j * 3]}>
          <boxGeometry args={[2.8, 0.04, 2.8]} />
          <meshLambertMaterial color="#111" emissive={accent} emissiveIntensity={(i + j) % 2 === 0 ? 0.18 : 0} />
        </mesh>
      )))}
      {/* DJ booth */}
      <mesh position={[0, 1.2, 8]}><boxGeometry args={[8, 2.4, 2]} /><meshLambertMaterial color="#1a0a1a" /></mesh>
      <mesh position={[0, 2.5, 8]}><boxGeometry args={[6, 0.2, 1.5]} /><meshLambertMaterial color={accent} emissive={accent} emissiveIntensity={1} /></mesh>
      <pointLight color={accent} intensity={8} distance={20} position={[0, 5, 6]} />
      {/* Spinning disco lights */}
      {[-8, 0, 8].map((lx, i) => (
        <group key={i}>
          <pointLight color={[accent, "#ff8800", "#44ffcc"][i % 3]} intensity={6} distance={14} position={[lx, 9, 0]} />
          <mesh position={[lx, 9.5, 0]}><sphereGeometry args={[0.4, 6, 6]} /><meshLambertMaterial color="#fff" emissive="#fff" emissiveIntensity={1} /></mesh>
        </group>
      ))}
      {/* Bar */}
      <mesh position={[-13, 0.6, 0]}><boxGeometry args={[2, 1.2, 16]} /><meshLambertMaterial color="#2a0a1a" /></mesh>
      <mesh position={[-13, 1.3, 0]}><boxGeometry args={[2.2, 0.12, 16.2]} /><meshLambertMaterial color="#1a0a0a" /></mesh>
      <pointLight color={accent} intensity={4} distance={10} position={[-12, 2.5, 0]} />
    </group>
  );
}

// ── Restaurant interior ───────────────────────────────────────────────────────
function RestaurantInterior({ offset, accent }: { offset: [number, number, number]; accent: string }) {
  const [ox, oy, oz] = offset;
  return (
    <group position={[ox, oy, oz]}>
      <mesh position={[0, 0, 0]} receiveShadow><boxGeometry args={[20, 0.1, 14]} /><meshLambertMaterial color="#c8a878" /></mesh>
      <mesh position={[0, 6, 0]}><boxGeometry args={[20, 0.2, 14]} /><meshLambertMaterial color="#b09870" /></mesh>
      {/* Tables */}
      {[[-4, -3], [4, -3], [-4, 3], [4, 3]].map(([tx, tz], i) => (
        <group key={i} position={[tx as number, 0, tz as number]}>
          <mesh position={[0, 0.75, 0]}><cylinderGeometry args={[1.2, 1.2, 0.08, 12]} /><meshLambertMaterial color="#8a6a4a" /></mesh>
          <mesh position={[0, 0.4, 0]}><cylinderGeometry args={[0.06, 0.06, 0.8, 5]} /><meshLambertMaterial color="#666" /></mesh>
          {[0, 1, 2, 3].map((si) => (
            <mesh key={si} position={[Math.cos(si * Math.PI / 2) * 1.5, 0.5, Math.sin(si * Math.PI / 2) * 1.5]}>
              <boxGeometry args={[0.6, 0.8, 0.6]} />
              <meshLambertMaterial color="#7a5a3a" />
            </mesh>
          ))}
        </group>
      ))}
      {/* Counter */}
      <mesh position={[8, 0.6, 0]}><boxGeometry args={[2.5, 1.2, 12]} /><meshLambertMaterial color="#3a0800" /></mesh>
      <mesh position={[8, 1.3, 0]}><boxGeometry args={[2.7, 0.1, 12.2]} /><meshLambertMaterial color="#2a0600" /></mesh>
      <pointLight color={accent} intensity={4} distance={12} position={[8, 4, 0]} />
      <pointLight color="#fff5dd" intensity={3} distance={16} position={[0, 5, 0]} />
    </group>
  );
}

// ── Hotel Lobby ───────────────────────────────────────────────────────────────
function HotelInterior({ offset }: { offset: [number, number, number] }) {
  const [ox, oy, oz] = offset;
  return (
    <group position={[ox, oy, oz]}>
      <mesh position={[0, 0, 0]} receiveShadow><boxGeometry args={[28, 0.12, 18]} /><meshLambertMaterial color="#d8c890" /></mesh>
      <mesh position={[0, 14, 0]}><boxGeometry args={[28, 0.3, 18]} /><meshLambertMaterial color="#e0d8c0" /></mesh>
      {/* Chandelier */}
      <mesh position={[0, 13.5, 0]}><sphereGeometry args={[1.4, 12, 8]} /><meshLambertMaterial color="#ffd080" emissive="#ffaa00" emissiveIntensity={0.7} /></mesh>
      <pointLight color="#fff5cc" intensity={8} distance={22} position={[0, 12, 0]} />
      {/* Reception desk */}
      <mesh position={[0, 0.7, 6]}><boxGeometry args={[10, 1.4, 2]} /><meshLambertMaterial color="#b09060" /></mesh>
      <mesh position={[0, 1.5, 6]}><boxGeometry args={[10.2, 0.1, 2.2]} /><meshLambertMaterial color="#c0a070" /></mesh>
      {/* Sofas */}
      {[-8, 8].map((xs, i) => (
        <mesh key={i} position={[xs as number, 0.5, -2]}><boxGeometry args={[5, 0.8, 2]} /><meshLambertMaterial color="#8a6a4a" /></mesh>
      ))}
      {/* Marble pillars */}
      {[[-10, -6], [10, -6], [-10, 4], [10, 4]].map(([xp, zp], i) => (
        <mesh key={i} position={[xp as number, 7, zp as number]}>
          <cylinderGeometry args={[0.6, 0.7, 14, 8]} />
          <meshLambertMaterial color="#e8e0d0" />
        </mesh>
      ))}
      <pointLight color="#ffe8aa" intensity={3} distance={14} position={[-8, 6, -5]} />
      <pointLight color="#ffe8aa" intensity={3} distance={14} position={[8, 6, -5]} />
    </group>
  );
}

// ── Prompt overlay ────────────────────────────────────────────────────────────
export function InteriorPrompt({
  def,
  onEnter,
}: {
  def: InteriorDef;
  onEnter: (id: string) => void;
}) {
  return (
    <div style={{
      position: "fixed", top: "44%", left: "50%", transform: "translate(-50%,-50%)",
      background: "rgba(0,0,0,0.88)", border: `1.5px solid ${def.accentColor}66`,
      borderRadius: 10, padding: "7px 20px", zIndex: 600, pointerEvents: "all",
      display: "flex", gap: 10, alignItems: "center",
      boxShadow: `0 4px 20px ${def.accentColor}22`,
    }}>
      <span style={{ fontSize: 20 }}>{def.icon}</span>
      <div>
        <div style={{ fontFamily: "monospace", fontWeight: 900, fontSize: 12, color: def.accentColor }}>{def.name}</div>
        <div style={{ fontFamily: "monospace", fontSize: 9, color: "#888" }}>Press <b style={{ color: "#fff" }}>E</b> to Enter</div>
      </div>
      <div
        onClick={() => onEnter(def.id)}
        style={{
          background: def.accentColor + "44", border: `1px solid ${def.accentColor}88`,
          borderRadius: 6, padding: "4px 12px", cursor: "pointer",
          fontFamily: "monospace", fontSize: 10, fontWeight: 900, color: def.accentColor,
        }}
      >ENTER</div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

export default function Interiors({ gameState, setGameState }: Props) {
  const [nearInterior, setNearInterior] = useState<InteriorDef | null>(null);
  const checkTimer = useRef(0);

  useFrame((_, delta) => {
    checkTimer.current += delta;
    if (checkTimer.current < 0.25) return;
    checkTimer.current = 0;

    if (gameState.currentInterior) {
      // Inside — check exit
      const def = INTERIORS.find((i) => i.id === gameState.currentInterior);
      if (def) {
        const ex = def.interiorOffset[0] + def.exitX;
        const ez = def.interiorOffset[2] + def.exitZ;
        const dx = ex - playerWorldPos.x, dz = ez - playerWorldPos.z;
        if (dx * dx + dz * dz < 25) setNearInterior(def);
        else setNearInterior(null);
      }
      return;
    }

    // Outside — find nearest entry
    let found: InteriorDef | null = null;
    for (const def of INTERIORS) {
      const dx = def.entryX - playerWorldPos.x, dz = def.entryZ - playerWorldPos.z;
      if (dx * dx + dz * dz < 30) { found = def; break; }
    }
    setNearInterior(found);
  });

  const enter = (id: string) => {
    const def = INTERIORS.find((i) => i.id === id);
    if (!def) return;
    setGameState((s) => ({ ...s, currentInterior: id }));
    playerWorldPos.set(
      def.interiorOffset[0] + def.entryX,
      0,
      def.interiorOffset[2] + def.entryZ,
    );
  };

  const exit = () => {
    const def = INTERIORS.find((i) => i.id === gameState.currentInterior);
    if (def) {
      playerWorldPos.set(def.exitX, 0, def.exitZ);
      setGameState((s) => ({ ...s, currentInterior: null }));
    }
  };

  return (
    <group>
      {/* Door markers for all interiors */}
      {INTERIORS.map((def) => (
        <DoorMarker
          key={def.id}
          def={def}
          isCurrentInterior={gameState.currentInterior === def.id}
          onEnter={enter}
          onExit={exit}
        />
      ))}

      {/* Render actual interiors */}
      {INTERIORS.map((def) => {
        if (def.type === "mall")       return <MallInterior key={def.id} offset={def.interiorOffset} />;
        if (def.type === "club")       return <ClubInterior key={def.id} offset={def.interiorOffset} accent={def.accentColor} />;
        if (def.type === "restaurant") return <RestaurantInterior key={def.id} offset={def.interiorOffset} accent={def.accentColor} />;
        if (def.type === "hotel")      return <HotelInterior key={def.id} offset={def.interiorOffset} />;
        // shop / police — basic room
        return (
          <group key={def.id} position={def.interiorOffset}>
            <mesh position={[0, 0, 0]} receiveShadow><boxGeometry args={[16, 0.1, 12]} /><meshLambertMaterial color="#2a2a2a" /></mesh>
            <mesh position={[0, 5, 0]}><boxGeometry args={[16, 0.1, 12]} /><meshLambertMaterial color="#222" /></mesh>
            {[-7, 7].map((xw, i) => (
              <mesh key={i} position={[xw as number, 2.5, 0]}><boxGeometry args={[0.15, 5, 12]} /><meshLambertMaterial color="#333" /></mesh>
            ))}
            <pointLight color={def.accentColor} intensity={4} distance={18} position={[0, 4.5, 0]} />
          </group>
        );
      })}

      {/* HUD prompt */}
      {nearInterior && !gameState.currentInterior && (
        <InteriorPrompt def={nearInterior} onEnter={enter} />
      )}
      {nearInterior && gameState.currentInterior && (
        <div style={{
          position: "fixed", top: "44%", left: "50%", transform: "translate(-50%,-50%)",
          background: "rgba(0,0,0,0.85)", border: "1px solid rgba(255,255,255,0.15)",
          borderRadius: 8, padding: "6px 18px", zIndex: 600, pointerEvents: "all",
          fontFamily: "monospace", fontSize: 11, color: "#aaa",
        }}>
          🚪 Press <b style={{ color: "#fff" }}>E</b> to Exit
          <span onClick={exit} style={{ marginLeft: 10, color: "#ff4488", cursor: "pointer", fontWeight: 900 }}>EXIT</span>
        </div>
      )}

      {/* Interior name banner */}
      {gameState.currentInterior && (
        <div style={{
          position: "fixed", top: 110, left: "50%", transform: "translateX(-50%)",
          background: "rgba(0,0,0,0.75)", border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 8, padding: "4px 18px", zIndex: 200,
          fontFamily: "monospace", fontSize: 10, color: "#aaa",
          display: "flex", alignItems: "center", gap: 8,
        }}>
          {INTERIORS.find((i) => i.id === gameState.currentInterior)?.icon}{" "}
          <span style={{ color: "#fff", fontWeight: 700 }}>
            {INTERIORS.find((i) => i.id === gameState.currentInterior)?.name}
          </span>
          <span style={{ color: "#555" }}>— Interior</span>
        </div>
      )}
    </group>
  );
}
