/**
 * SocialFeed — In-game TikTok/Instagram Reels style social media
 *
 * • NPCs nearby record player chaos events
 * • Video feed shows up with live comments
 * • Viewer count rises with wanted level
 */

import { useEffect, useRef, useState } from "react";
import { GameState } from "./types";

interface FeedPost {
  id: number;
  user: string;
  avatar: string;
  caption: string;
  likes: number;
  views: number;
  time: string;
  thumbnailColor: string;
  thumbnailIcon: string;
  comments: string[];
  live: boolean;
}

const NPC_ACCOUNTS = [
  { user: "ViceCityVibes", avatar: "👩" },
  { user: "LeonidaLive",   avatar: "👨" },
  { user: "OceanDriveTV",  avatar: "🧑" },
  { user: "ChaosClips_VC", avatar: "👱" },
  { user: "GrassriverGuy", avatar: "🧔" },
  { user: "KeysKiddo",     avatar: "👧" },
  { user: "VCStories",     avatar: "🧑‍🦱" },
  { user: "FloriLiveNow",  avatar: "👩‍🦰" },
];

const COMMENT_POOLS: Record<string, string[]> = {
  shooting: [
    "😱 omg is that real??",
    "bro got the whole street running lmaooo",
    "LCPD is gonna be SO mad 💀",
    "that aim tho ngl 🎯",
    "i was literally right there wth",
    "someone call 911 no wait they busy lol",
    "GTA6 is crazy realistic fr",
    "not me watching this from my balcony rn 😭",
    "he's cooked when the cops arrive",
    "this is why i stay inside 🏠",
  ],
  driving: [
    "bro is doing 120 on Ocean Drive wtf",
    "my car insurance going up just watching this 😂",
    "SPEED DEMON!! 🔥🔥🔥",
    "he took that corner at WHAT speed",
    "Florida drivers be like 💀",
    "those palm trees almost didn't make it",
    "the stunt double walked off set fr",
    "that drift was immaculate ngl",
  ],
  explosion: [
    "BRO THE EXPLOSION 💥💥💥",
    "i felt that from my apartment",
    "R.I.P to that car fr 😭",
    "Michael Bay just subscribed",
    "the whole street heard that",
    "NOT the oil tank oml 😭",
    "this feed is UNHINGED rn",
    "Vice City never disappoints",
  ],
  fight: [
    "he's got hands tho not gonna lie",
    "bro fought like 4 people 😭",
    "the NPC AI is cooked fr",
    "give this man a title fight",
    "why does everyone just stand there 💀",
    "the combo at the end was CLEAN",
  ],
};

function generatePost(wanted: number, kills: number, event: string, id: number): FeedPost {
  const acc = NPC_ACCOUNTS[id % NPC_ACCOUNTS.length];
  const pool = COMMENT_POOLS[event] ?? COMMENT_POOLS.shooting;
  const comments = Array.from({ length: 3 + (wanted * 2) }, (_, i) => pool[(id + i * 7) % pool.length]);
  const baseViews = 100 + wanted * 8000 + kills * 500;
  const colors: Record<string, string> = {
    shooting:  "#1a0a2a",
    driving:   "#0a1a2a",
    explosion: "#2a0a00",
    fight:     "#1a1a00",
  };
  const icons: Record<string, string> = {
    shooting: "🔫", driving: "🚗", explosion: "💥", fight: "👊",
  };
  const captions: Record<string, string[]> = {
    shooting:  ["POV: Vice City rn 😳", "bro said no laws in Leonida 💀", "LCPD is busy rn 🚔"],
    driving:   ["he's NOT stopping 😭", "ocean drive speedrun", "Florida driving 101 🏎️"],
    explosion: ["it's giving GTA vibes 💥", "they blew UP the whole block", "NOT the refinery 😭"],
    fight:     ["hands on Ocean Drive 👊", "bro fought the whole crew", "Vice City knuckles 💀"],
  };
  const cap = captions[event]?.[id % 3] ?? "Vice City is WILD rn 😱";
  const mins = Math.floor(Math.random() * 5) + 1;

  return {
    id, user: acc.user, avatar: acc.avatar,
    caption: cap,
    likes: Math.floor(baseViews * 0.12),
    views: baseViews,
    time: `${mins}m ago`,
    thumbnailColor: colors[event] ?? "#1a1a1a",
    thumbnailIcon: icons[event] ?? "📹",
    comments: [...new Set(comments)].slice(0, 5 + wanted),
    live: wanted >= 3,
  };
}

// ── Component ────────────────────────────────────────────────────────────────
interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

export default function SocialFeed({ gameState, setGameState }: Props) {
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [open, setOpen] = useState(false);
  const [newPostBadge, setNewPostBadge] = useState(0);
  const [liveComments, setLiveComments] = useState<string[]>([]);
  const [recordingFlash, setRecordingFlash] = useState(false);
  const postIdRef = useRef(0);
  const prevWanted = useRef(0);
  const prevKills = useRef(0);
  const commentTimer = useRef<ReturnType<typeof setInterval>>();

  // Detect chaos events
  useEffect(() => {
    const wantedRise  = gameState.wanted > prevWanted.current;
    const newKill     = gameState.kills > prevKills.current;
    prevWanted.current = gameState.wanted;
    prevKills.current  = gameState.kills;

    if (wantedRise || newKill) {
      // NPC recording flash
      setRecordingFlash(true);
      setTimeout(() => setRecordingFlash(false), 2200);

      // Generate new post after a small delay (NPC "uploads")
      const delay = 2500 + Math.random() * 3000;
      const event  = newKill ? (Math.random() > 0.5 ? "shooting" : "fight") : (gameState.wanted >= 3 ? "explosion" : "driving");
      setTimeout(() => {
        const newPost = generatePost(gameState.wanted, gameState.kills, event, postIdRef.current++);
        setPosts((prev) => [newPost, ...prev].slice(0, 20));
        setNewPostBadge((n) => n + 1);
        setGameState((s) => ({ ...s, socialRecordingNpc: true }));
        setTimeout(() => setGameState((s) => ({ ...s, socialRecordingNpc: false })), 3000);
      }, delay);
    }
  }, [gameState.wanted, gameState.kills]);

  // Live comment stream when feed is open
  useEffect(() => {
    if (!open || posts.length === 0) return;
    const allComments = posts.flatMap((p) => p.comments);
    let i = 0;
    commentTimer.current = setInterval(() => {
      const c = allComments[i % allComments.length];
      setLiveComments((prev) => [c, ...prev].slice(0, 6));
      i++;
    }, 1800);
    return () => clearInterval(commentTimer.current);
  }, [open, posts]);

  const totalViews = posts.reduce((a, p) => a + p.views, 0);
  const isHot = gameState.wanted >= 2;

  return (
    <>
      {/* Recording flash — screen edge red glow */}
      {recordingFlash && (
        <div style={{
          position: "fixed", inset: 0, pointerEvents: "none", zIndex: 500,
          border: "3px solid #ff2244",
          boxShadow: "inset 0 0 50px rgba(255,30,60,0.35)",
          borderRadius: 2,
          animation: "recFlash 2.2s ease-out forwards",
        }}>
          <div style={{
            position: "absolute", top: 14, left: "50%", transform: "translateX(-50%)",
            background: "rgba(255,20,50,0.9)", borderRadius: 6, padding: "4px 14px",
            fontFamily: "monospace", fontSize: 11, fontWeight: 900, color: "#fff",
            display: "flex", alignItems: "center", gap: 8,
          }}>
            <div style={{
              width: 8, height: 8, borderRadius: "50%", background: "#fff",
              animation: "pulse 0.5s infinite alternate",
            }} />
            NPC IS RECORDING YOU · GOING VIRAL
          </div>
        </div>
      )}

      {/* Toggle button */}
      <div
        onClick={() => { setOpen((o) => !o); setNewPostBadge(0); }}
        style={{
          position: "fixed", top: 12, left: "50%", transform: "translateX(-50%)",
          background: open ? "rgba(255,20,80,0.95)" : "rgba(0,0,0,0.85)",
          border: `1.5px solid ${isHot ? "rgba(255,50,100,0.7)" : "rgba(255,255,255,0.15)"}`,
          borderRadius: 20, padding: "5px 16px",
          display: "flex", alignItems: "center", gap: 7,
          cursor: "pointer", pointerEvents: "all", zIndex: 600,
          boxShadow: isHot ? "0 0 20px rgba(255,40,80,0.4)" : "none",
          transition: "all 0.25s",
        }}
      >
        <span style={{ fontSize: 16 }}>📱</span>
        <div>
          <div style={{ fontFamily: "monospace", fontSize: 9, fontWeight: 900, color: open ? "#fff" : "#ff4488", letterSpacing: 1 }}>
            VICE SOCIAL
          </div>
          {totalViews > 0 && (
            <div style={{ fontSize: 8, color: open ? "#ffccdd" : "#888", fontFamily: "monospace" }}>
              {totalViews.toLocaleString()} views
            </div>
          )}
        </div>
        {newPostBadge > 0 && (
          <div style={{
            background: "#ff2244", borderRadius: "50%", width: 18, height: 18,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 10, fontWeight: 900, color: "#fff",
            boxShadow: "0 0 8px rgba(255,30,60,0.8)",
          }}>{newPostBadge > 9 ? "9+" : newPostBadge}</div>
        )}
      </div>

      {/* Feed panel */}
      {open && (
        <div style={{
          position: "fixed", top: 50, left: "50%", transform: "translateX(-50%)",
          width: Math.min(360, window.innerWidth - 20),
          maxHeight: "72vh",
          background: "rgba(0,0,0,0.96)", border: "1.5px solid rgba(255,50,100,0.35)",
          borderRadius: 16, overflow: "hidden", zIndex: 590,
          display: "flex", flexDirection: "column",
          boxShadow: "0 8px 40px rgba(0,0,0,0.8)",
        }}>
          {/* Header */}
          <div style={{
            padding: "8px 14px", borderBottom: "1px solid rgba(255,255,255,0.06)",
            background: "linear-gradient(180deg,rgba(255,30,80,0.15),transparent)",
            display: "flex", alignItems: "center", gap: 8,
          }}>
            <span style={{ fontSize: 18 }}>📱</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "monospace", fontWeight: 900, fontSize: 13, color: "#ff4488" }}>VICE SOCIAL</div>
              <div style={{ fontSize: 9, color: "#666", fontFamily: "monospace" }}>Leonida's #1 chaos feed</div>
            </div>
            <div style={{ fontFamily: "monospace", fontSize: 9, color: "#ff4488" }}>
              {posts.filter((p) => p.live).length} LIVE
            </div>
          </div>

          {/* Live comments ticker */}
          {liveComments.length > 0 && (
            <div style={{
              padding: "4px 12px", background: "rgba(255,30,80,0.08)",
              borderBottom: "1px solid rgba(255,50,100,0.1)",
              maxHeight: 72, overflow: "hidden",
            }}>
              {liveComments.slice(0, 3).map((c, i) => (
                <div key={i} style={{
                  fontFamily: "monospace", fontSize: 9.5, color: i === 0 ? "#ffccdd" : "#666",
                  padding: "1px 0",
                  transition: "all 0.3s",
                }}>
                  💬 {c}
                </div>
              ))}
            </div>
          )}

          {/* Posts */}
          <div style={{ overflowY: "auto", flex: 1 }}>
            {posts.length === 0 ? (
              <div style={{ padding: 24, textAlign: "center", fontFamily: "monospace", fontSize: 11, color: "#444" }}>
                No clips yet — cause some chaos! 🎬
              </div>
            ) : (
              posts.map((post) => (
                <div key={post.id} style={{
                  padding: "10px 14px", borderBottom: "1px solid rgba(255,255,255,0.04)",
                  display: "flex", gap: 10,
                }}>
                  {/* Thumbnail */}
                  <div style={{
                    width: 72, height: 80, borderRadius: 8, flexShrink: 0,
                    background: post.thumbnailColor, border: "1px solid rgba(255,255,255,0.08)",
                    display: "flex", flexDirection: "column", alignItems: "center",
                    justifyContent: "center", position: "relative",
                  }}>
                    <span style={{ fontSize: 28 }}>{post.thumbnailIcon}</span>
                    {post.live && (
                      <div style={{
                        position: "absolute", top: 4, right: 4,
                        background: "#ff2244", borderRadius: 4, padding: "1px 5px",
                        fontFamily: "monospace", fontSize: 8, fontWeight: 900, color: "#fff",
                      }}>LIVE</div>
                    )}
                    <div style={{ position: "absolute", bottom: 4, left: 5, right: 5, fontFamily: "monospace", fontSize: 7, color: "#888", textAlign: "center" }}>
                      {post.views.toLocaleString()} views
                    </div>
                  </div>

                  {/* Content */}
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", gap: 5, alignItems: "center", marginBottom: 2 }}>
                      <span style={{ fontSize: 13 }}>{post.avatar}</span>
                      <span style={{ fontFamily: "monospace", fontSize: 10, fontWeight: 900, color: "#ff8aaa" }}>@{post.user}</span>
                      <span style={{ fontFamily: "monospace", fontSize: 8, color: "#444", marginLeft: "auto" }}>{post.time}</span>
                    </div>
                    <div style={{ fontFamily: "monospace", fontSize: 10, color: "#ddd", marginBottom: 4, lineHeight: 1.4 }}>
                      {post.caption}
                    </div>
                    {/* Comments preview */}
                    {post.comments.slice(0, 2).map((c, i) => (
                      <div key={i} style={{ fontFamily: "monospace", fontSize: 8.5, color: "#555", lineHeight: 1.4 }}>
                        💬 {c}
                      </div>
                    ))}
                    {/* Likes */}
                    <div style={{ marginTop: 4, display: "flex", gap: 10, fontFamily: "monospace", fontSize: 9, color: "#ff4488" }}>
                      <span>❤️ {post.likes.toLocaleString()}</span>
                      <span>💬 {post.comments.length}</span>
                      <span>🔁 {Math.floor(post.likes * 0.3).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes recFlash { 0%{opacity:1} 70%{opacity:1} 100%{opacity:0} }
        @keyframes pulse { from{opacity:1} to{opacity:0.3} }
      `}</style>
    </>
  );
}
