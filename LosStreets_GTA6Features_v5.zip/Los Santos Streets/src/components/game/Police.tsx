/**
 * Smart Police — GTA VI inspired AI
 *
 * Wanted 1–2: Surround + Arrest attempt (no shoot)
 * Wanted 3+:  Aggressive pursuit + shoot
 * Arrest:     Player caught → money fine, wanted drops
 * Roadblocks: Wanted 4+ = roadblock cars placed
 */

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState } from "./types";
import { playerWorldPos } from "./Player";
import { findPath } from "../../utils/pathfinding";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

interface CopData {
  id: number;
  startX: number;
  startZ: number;
  speed: number;
  role: "patrol" | "surround" | "roadblock";
}

const COP_DEFS: CopData[] = [
  { id: 0, startX: 100,  startZ: 10,   speed: 6.5, role: "patrol" },
  { id: 1, startX: -100, startZ: -10,  speed: 6.0, role: "patrol" },
  { id: 2, startX: 10,   startZ: 100,  speed: 7.0, role: "surround" },
  { id: 3, startX: -10,  startZ: -100, speed: 5.5, role: "surround" },
  { id: 4, startX: 140,  startZ: -50,  speed: 5.0, role: "roadblock" },
  { id: 5, startX: -140, startZ: 50,   speed: 5.0, role: "roadblock" },
];

const PATH_UPDATE_INTERVAL = 2.5;

// Surround offset — each cop takes a different angle around the player
const SURROUND_ANGLES = [0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2, Math.PI / 4, (3 * Math.PI) / 4];
const SURROUND_RADIUS = 10;

function PoliceCar({
  cop,
  wantedLevel,
  setGameState,
}: {
  cop: CopData;
  wantedLevel: number;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}) {
  const ref = useRef<THREE.Group>(null);
  const pathRef = useRef<[number, number][]>([]);
  const waypointIdxRef = useRef(0);
  const pathTimerRef = useRef(Math.random() * PATH_UPDATE_INTERVAL);
  const steerRef = useRef(0);
  const speedRef = useRef(0);
  const sirenTimer = useRef(0);
  const arrestTimer = useRef(0);
  const copModeRef = useRef<"patrol" | "pursue" | "surround" | "arrest">("patrol");

  useFrame((_, delta) => {
    if (!ref.current) return;
    const dt = Math.min(delta, 0.05);
    sirenTimer.current += dt;
    arrestTimer.current += dt;

    const active = wantedLevel >= 1;

    if (!active) {
      copModeRef.current = "patrol";
      ref.current.position.x = cop.startX + Math.sin(Date.now() * 0.0003 + cop.id) * 22;
      ref.current.position.z = cop.startZ + Math.cos(Date.now() * 0.0003 + cop.id) * 16;
      ref.current.position.y = 0;
      pathRef.current = [];
      waypointIdxRef.current = 0;
      speedRef.current = 0;
      return;
    }

    const px = playerWorldPos.x;
    const pz = playerWorldPos.z;
    const distToPlayer = ref.current.position.distanceTo(new THREE.Vector3(px, 0, pz));

    // ── Mode decision ──────────────────────────────────────────────
    if (wantedLevel <= 2 && cop.role !== "roadblock") {
      // Smart: surround & attempt arrest
      if (distToPlayer < SURROUND_RADIUS + 3) {
        copModeRef.current = "surround";
      } else {
        copModeRef.current = "pursue";
      }
    } else {
      copModeRef.current = "pursue";
    }

    // ── SURROUND mode ──────────────────────────────────────────────
    if (copModeRef.current === "surround") {
      const angle = SURROUND_ANGLES[cop.id % SURROUND_ANGLES.length];
      const targetX = px + Math.cos(angle) * SURROUND_RADIUS;
      const targetZ = pz + Math.sin(angle) * SURROUND_RADIUS;
      const dx = targetX - ref.current.position.x;
      const dz = targetZ - ref.current.position.z;
      const len = Math.sqrt(dx * dx + dz * dz) + 0.001;

      ref.current.position.x += (dx / len) * cop.speed * 0.65 * dt;
      ref.current.position.z += (dz / len) * cop.speed * 0.65 * dt;
      ref.current.rotation.y = Math.atan2(
        px - ref.current.position.x,
        pz - ref.current.position.z,
      );
      ref.current.position.y = 0;

      // Arrest attempt if close enough and wanted is 1–2
      if (distToPlayer < 5.5 && wantedLevel <= 2 && arrestTimer.current > 4.0) {
        arrestTimer.current = 0;
        setGameState((s) => ({
          ...s,
          money: Math.max(0, s.money - 500 * s.wanted),
          wanted: 0,
          health: Math.max(10, s.health - 5),
          missionText: "🚔 ARRESTED! Paid $" + (500 * s.wanted).toLocaleString() + " fine. Released.",
        }));
      }
      return;
    }

    // ── ROADBLOCK mode ────────────────────────────────────────────
    if (cop.role === "roadblock" && wantedLevel >= 4) {
      // Park sideways in front of player
      const angle = Math.atan2(px - cop.startX, pz - cop.startZ);
      ref.current.position.x = px + Math.cos(angle + Math.PI) * 18 + cop.id * 3;
      ref.current.position.z = pz + Math.sin(angle + Math.PI) * 18;
      ref.current.rotation.y = angle + Math.PI / 2;
      ref.current.position.y = 0;
      return;
    }

    // ── PURSUE mode (pathfinding) ─────────────────────────────────
    pathTimerRef.current += dt;
    if (pathTimerRef.current >= PATH_UPDATE_INTERVAL || pathRef.current.length === 0) {
      pathTimerRef.current = 0;
      const cx = ref.current.position.x, cz = ref.current.position.z;
      const path = findPath(cx, cz, px, pz, 500);
      pathRef.current = path.length > 0 ? path : [[px, pz]];
      waypointIdxRef.current = 0;
    }

    const path = pathRef.current;
    if (path.length > 0) {
      let wpIdx = waypointIdxRef.current;
      if (wpIdx >= path.length) wpIdx = path.length - 1;
      const [wpX, wpZ] = path[wpIdx];
      const dx = wpX - ref.current.position.x;
      const dz = wpZ - ref.current.position.z;
      const distToWp = Math.sqrt(dx * dx + dz * dz);

      if (distToWp < 3.5 && wpIdx < path.length - 1) waypointIdxRef.current = wpIdx + 1;

      if (distToWp > 0.5) {
        const targetAngle = Math.atan2(dx, dz);
        let angleDiff = targetAngle - ref.current.rotation.y;
        while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI;
        while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;
        const steerTarget = Math.max(-1, Math.min(1, angleDiff * 2));
        steerRef.current += (steerTarget - steerRef.current) * 6 * dt;
        ref.current.rotation.y += steerRef.current * 2.8 * dt;
      }
    }

    const targetSpeed = cop.speed * Math.min(wantedLevel, 3) * (1 - Math.abs(steerRef.current) * 0.3);
    speedRef.current += (targetSpeed - speedRef.current) * 4 * dt;
    const ang = ref.current.rotation.y;
    ref.current.position.x += Math.sin(ang) * speedRef.current * dt;
    ref.current.position.z += Math.cos(ang) * speedRef.current * dt;
    ref.current.position.y = 0;
    ref.current.rotation.z += (-steerRef.current * 0.04 - ref.current.rotation.z) * 5 * dt;
  });

  const sirenOn = wantedLevel >= 1;
  const sirenPhase = Math.floor(sirenTimer.current * 3.33) % 2 === 0;
  const sirenColor = sirenPhase ? "#0044ff" : "#ff2200";
  const isArresting = copModeRef.current === "surround" && wantedLevel <= 2;

  return (
    <group ref={ref} position={[cop.startX, 0, cop.startZ]}>
      {/* Car body */}
      <mesh position={[0, 0.55, 0]} castShadow>
        <boxGeometry args={[2.2, 0.7, 4.5]} />
        <meshLambertMaterial color={isArresting ? "#1a1a88" : "#2030b0"} />
      </mesh>
      {/* Cabin */}
      <mesh position={[0, 1.1, -0.3]} castShadow>
        <boxGeometry args={[1.9, 0.65, 2.2]} />
        <meshLambertMaterial color={isArresting ? "#14146a" : "#1a28a0"} />
      </mesh>
      {/* Siren bar */}
      <mesh position={[0, 1.55, -0.3]}>
        <boxGeometry args={[1.8, 0.18, 0.5]} />
        <meshLambertMaterial color="#111" />
      </mesh>
      {sirenOn && (
        <>
          <pointLight color={sirenColor} intensity={4} distance={20} position={[-0.5, 1.9, -0.3]} />
          <pointLight color={sirenPhase ? "#ff2200" : "#0044ff"} intensity={4} distance={20} position={[0.5, 1.9, -0.3]} />
        </>
      )}
      {/* ARREST spotlight when surrounding */}
      {isArresting && (
        <pointLight color="#ffffff" intensity={6} distance={16} position={[0, 2.5, 2]} />
      )}
      {/* Windshield */}
      <mesh position={[0, 1.12, 1.6]}>
        <boxGeometry args={[1.75, 0.52, 0.06]} />
        <meshLambertMaterial color="#88ccff" transparent opacity={0.45} />
      </mesh>
      {/* Wheels */}
      {([[-0.95,-0.25,1.4],[0.95,-0.25,1.4],[-0.95,-0.25,-1.4],[0.95,-0.25,-1.4]] as [number,number,number][]).map(([wx,wy,wz],i) => (
        <mesh key={i} position={[wx,wy,wz]} rotation={[Math.PI/2,0,0]} castShadow>
          <cylinderGeometry args={[0.4,0.4,0.3,10]} />
          <meshLambertMaterial color="#111" />
        </mesh>
      ))}
      {/* Headlights */}
      <mesh position={[0,0.6,2.27]}>
        <boxGeometry args={[1.6,0.22,0.04]} />
        <meshLambertMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.7} />
      </mesh>
      {/* LCPD text */}
      <mesh position={[0,0.95,-2.27]}>
        <boxGeometry args={[1.4,0.2,0.04]} />
        <meshLambertMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.4} />
      </mesh>
    </group>
  );
}

// ── Police Helicopter (wanted 4+) ─────────────────────────────────────────────
function PoliceHelicopter({ wantedLevel }: { wantedLevel: number }) {
  const ref = useRef<THREE.Group>(null);
  const angle = useRef(0);

  useFrame((_, delta) => {
    if (!ref.current || wantedLevel < 4) {
      if (ref.current) ref.current.visible = false;
      return;
    }
    ref.current.visible = true;
    angle.current += delta * 0.5;
    const r = 30;
    ref.current.position.x = playerWorldPos.x + Math.cos(angle.current) * r;
    ref.current.position.z = playerWorldPos.z + Math.sin(angle.current) * r;
    ref.current.position.y = 40;
    ref.current.rotation.y = angle.current + Math.PI;
  });

  return (
    <group ref={ref} visible={false}>
      <mesh position={[0, 0, 0]} castShadow>
        <boxGeometry args={[1.8, 1.0, 4.0]} />
        <meshLambertMaterial color="#1a28a0" />
      </mesh>
      <mesh position={[0, 0.9, 0]} rotation={[0, Date.now() * 0.002, 0]}>
        <boxGeometry args={[7, 0.06, 0.25]} />
        <meshLambertMaterial color="#666" />
      </mesh>
      <pointLight color="#ffffff" intensity={10} distance={60} position={[0, -2, 2]} />
      <pointLight color="#ff2200" intensity={3} distance={20} position={[0, 1.5, 0]} />
      <pointLight color="#0044ff" intensity={3} distance={20} position={[0.5, 1.5, 0]} />
    </group>
  );
}

// ── HUD Arrest Overlay ────────────────────────────────────────────────────────
export function ArrestOverlay({ wantedLevel, policeAlertLevel }: { wantedLevel: number; policeAlertLevel: string }) {
  if (wantedLevel === 0) return null;

  const isLowWanted = wantedLevel <= 2;
  const color = isLowWanted ? "#0044ff" : "#ff2200";
  const label = isLowWanted ? "LCPD MOVING TO ARREST" : "LETHAL FORCE AUTHORIZED";
  const icon  = isLowWanted ? "🚔" : "🚁";

  return (
    <div style={{
      position: "fixed", top: 54, right: 12,
      background: `rgba(0,0,0,0.82)`,
      border: `1.5px solid ${color}55`,
      borderRadius: 8, padding: "4px 12px",
      fontFamily: "monospace", fontSize: 9, fontWeight: 900,
      color, letterSpacing: 1, zIndex: 300,
      display: "flex", alignItems: "center", gap: 6,
      animation: "pulse 0.6s infinite alternate",
      boxShadow: `0 0 14px ${color}33`,
    }}>
      <span>{icon}</span>
      {label}
      <style>{`@keyframes pulse { from{opacity:1} to{opacity:0.6} }`}</style>
    </div>
  );
}

export default function Police({ gameState, setGameState }: Props) {
  return (
    <group>
      {COP_DEFS.map((cop) => (
        <PoliceCar
          key={cop.id}
          cop={cop}
          wantedLevel={gameState.wanted}
          setGameState={setGameState}
        />
      ))}
      <PoliceHelicopter wantedLevel={gameState.wanted} />
    </group>
  );
}
