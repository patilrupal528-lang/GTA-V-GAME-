/**
 * Wildlife — Dynamic Alligators (Leonida / Everglades inspired)
 *
 * • Alligators patrol swamp/road/pool areas
 * • Detect & chase player within radius
 * • Attack on contact — deal damage
 * • Flamingos & wild boars also roam
 */

import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState } from "./types";
import { playerWorldPos } from "./Player";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

interface AlligatorData {
  id: number;
  startX: number;
  startZ: number;
  patrolRadius: number;
  speed: number;
}

const GATORS: AlligatorData[] = [
  // Grassrivers
  { id: 0, startX: -110, startZ: 85,  patrolRadius: 22, speed: 4.5 },
  { id: 1, startX: -175, startZ: 165, patrolRadius: 18, speed: 5.0 },
  { id: 2, startX: -225, startZ: 130, patrolRadius: 25, speed: 4.0 },
  { id: 3, startX: -150, startZ: 210, patrolRadius: 20, speed: 5.5 },
  { id: 4, startX: -200, startZ: 250, patrolRadius: 16, speed: 4.8 },
  // Leonida Keys waterways
  { id: 5, startX: 145,  startZ: 300, patrolRadius: 15, speed: 3.8 },
  // Road crossings (rare, scary)
  { id: 6, startX: -80,  startZ: 95,  patrolRadius: 30, speed: 6.0 },
  { id: 7, startX: -130, startZ: 175, patrolRadius: 24, speed: 5.2 },
];

interface BoarData { id: number; startX: number; startZ: number }
const BOARS: BoarData[] = [
  { id: 0, startX: -160, startZ: 90  },
  { id: 1, startX: -240, startZ: 150 },
  { id: 2, startX: -100, startZ: 200 },
  { id: 3, startX: -300, startZ: 120 },
];

// ── Single Alligator ──────────────────────────────────────────────────────────
function Alligator({
  data,
  setGameState,
  noCrash,
}: {
  data: AlligatorData;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  noCrash: boolean;
}) {
  const ref = useRef<THREE.Group>(null);
  const stateRef = useRef<"patrol" | "chase" | "attack">("patrol");
  const patrolAngle = useRef(Math.random() * Math.PI * 2);
  const attackCooldown = useRef(0);
  const legAnim = useRef(0);

  useFrame((_, delta) => {
    if (!ref.current) return;
    const dt = Math.min(delta, 0.05);
    attackCooldown.current -= dt;

    const px = playerWorldPos.x - ref.current.position.x;
    const pz = playerWorldPos.z - ref.current.position.z;
    const dist = Math.sqrt(px * px + pz * pz);

    // State machine
    if (dist < 4 && stateRef.current !== "patrol") {
      stateRef.current = "attack";
    } else if (dist < 30) {
      stateRef.current = "chase";
    } else {
      stateRef.current = "patrol";
    }

    legAnim.current += dt * (stateRef.current === "chase" ? 8 : 3);

    if (stateRef.current === "patrol") {
      patrolAngle.current += dt * 0.4;
      const nx = data.startX + Math.cos(patrolAngle.current) * data.patrolRadius;
      const nz = data.startZ + Math.sin(patrolAngle.current) * data.patrolRadius;
      const dx = nx - ref.current.position.x;
      const dz = nz - ref.current.position.z;
      const len = Math.sqrt(dx * dx + dz * dz) + 0.001;
      ref.current.position.x += (dx / len) * data.speed * 0.4 * dt;
      ref.current.position.z += (dz / len) * data.speed * 0.4 * dt;
      ref.current.rotation.y = Math.atan2(dx, dz);
      ref.current.position.y = 0.08;
    } else if (stateRef.current === "chase") {
      const len = dist + 0.001;
      ref.current.position.x += (px / len) * data.speed * dt;
      ref.current.position.z += (pz / len) * data.speed * dt;
      ref.current.rotation.y = Math.atan2(px, pz);
      ref.current.position.y = 0.08;
    } else if (stateRef.current === "attack") {
      // Attack animation — bob up/down
      ref.current.position.y = 0.08 + Math.abs(Math.sin(legAnim.current)) * 0.2;
      if (attackCooldown.current <= 0 && !noCrash) {
        attackCooldown.current = 1.5;
        setGameState((s) => ({
          ...s,
          health: Math.max(0, s.health - 12),
          wildlifeAlert: true,
        }));
        setTimeout(() => setGameState((s) => ({ ...s, wildlifeAlert: false })), 1500);
      }
    }
  });

  return (
    <group ref={ref} position={[data.startX, 0.08, data.startZ]}>
      {/* Body */}
      <mesh castShadow>
        <boxGeometry args={[0.7, 0.28, 2.4]} />
        <meshLambertMaterial color="#2a4a1a" />
      </mesh>
      {/* Tail */}
      <mesh position={[0, 0, -1.5]}>
        <boxGeometry args={[0.4, 0.2, 1.0]} />
        <meshLambertMaterial color="#223a14" />
      </mesh>
      <mesh position={[0, 0, -2.1]}>
        <boxGeometry args={[0.22, 0.14, 0.7]} />
        <meshLambertMaterial color="#1a2e10" />
      </mesh>
      {/* Head */}
      <mesh position={[0, 0.1, 1.35]}>
        <boxGeometry args={[0.6, 0.25, 0.75]} />
        <meshLambertMaterial color="#2a4a1a" />
      </mesh>
      {/* Snout */}
      <mesh position={[0, 0.05, 1.85]}>
        <boxGeometry args={[0.45, 0.16, 0.55]} />
        <meshLambertMaterial color="#223a14" />
      </mesh>
      {/* Teeth */}
      {[-0.12, 0.12].map((xo, i) => (
        <mesh key={i} position={[xo, 0.02, 1.9]}>
          <boxGeometry args={[0.06, 0.12, 0.06]} />
          <meshLambertMaterial color="#eeeedd" />
        </mesh>
      ))}
      {/* Eyes — glowing */}
      {[-0.22, 0.22].map((xo, i) => (
        <group key={i} position={[xo, 0.22, 1.28]}>
          <mesh>
            <sphereGeometry args={[0.08, 6, 6]} />
            <meshLambertMaterial color="#ff8800" emissive="#ff4400" emissiveIntensity={1.2} />
          </mesh>
          <pointLight color="#ff6600" intensity={0.8} distance={5} />
        </group>
      ))}
      {/* Legs */}
      {[
        [-0.45, 0.85], [0.45, 0.85],
        [-0.45, -0.6], [0.45, -0.6],
      ].map(([xo, zo], i) => (
        <mesh key={i} position={[xo as number, -0.05, zo as number]}>
          <boxGeometry args={[0.18, 0.18, 0.38]} />
          <meshLambertMaterial color="#1a3a10" />
        </mesh>
      ))}
      {/* Scale ridges on back */}
      {[0.4, 0, -0.4, -0.8].map((zo, i) => (
        <mesh key={i} position={[0, 0.19, zo]}>
          <boxGeometry args={[0.1, 0.12, 0.12]} />
          <meshLambertMaterial color="#1a3a10" />
        </mesh>
      ))}
    </group>
  );
}

// ── Wild Boar ─────────────────────────────────────────────────────────────────
function WildBoar({ data }: { data: BoarData }) {
  const ref = useRef<THREE.Group>(null);
  const angle = useRef(Math.random() * Math.PI * 2);

  useFrame((_, delta) => {
    if (!ref.current) return;
    angle.current += delta * 0.5;
    const nx = data.startX + Math.cos(angle.current) * 18;
    const nz = data.startZ + Math.sin(angle.current) * 14;
    const dx = nx - ref.current.position.x;
    const dz = nz - ref.current.position.z;
    const len = Math.sqrt(dx * dx + dz * dz) + 0.001;
    ref.current.position.x += (dx / len) * 3.5 * delta;
    ref.current.position.z += (dz / len) * 3.5 * delta;
    ref.current.rotation.y = Math.atan2(dx, dz);
  });

  return (
    <group ref={ref} position={[data.startX, 0, data.startZ]}>
      <mesh position={[0, 0.45, 0]} castShadow>
        <boxGeometry args={[0.55, 0.5, 0.85]} />
        <meshLambertMaterial color="#5a3a2a" />
      </mesh>
      <mesh position={[0, 0.52, 0.52]}>
        <boxGeometry args={[0.45, 0.4, 0.35]} />
        <meshLambertMaterial color="#4a2a1a" />
      </mesh>
      {/* Tusks */}
      {[-0.14, 0.14].map((xo, i) => (
        <mesh key={i} position={[xo, 0.38, 0.76]}>
          <boxGeometry args={[0.06, 0.06, 0.18]} />
          <meshLambertMaterial color="#ddd" />
        </mesh>
      ))}
      {/* Legs */}
      {[[-0.18, 0.3], [0.18, 0.3], [-0.18, -0.2], [0.18, -0.2]].map(([xo, zo], i) => (
        <mesh key={i} position={[xo as number, 0.14, zo as number]}>
          <boxGeometry args={[0.12, 0.32, 0.12]} />
          <meshLambertMaterial color="#4a2a18" />
        </mesh>
      ))}
    </group>
  );
}

// ── Flamingo flock ────────────────────────────────────────────────────────────
const FLAMINGO_FLOCK = [
  { id: 0, x: -95,  z: 172 },
  { id: 1, x: -103, z: 179 },
  { id: 2, x: -90,  z: 185 },
  { id: 3, x: -108, z: 170 },
  { id: 4, x: -98,  z: 165 },
];

function Flamingo({ x, z, id }: { x: number; z: number; id: number }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => {
    if (!ref.current) return;
    // Gentle sway
    ref.current.position.y = Math.sin(Date.now() * 0.001 + id) * 0.04;
    ref.current.rotation.y = Math.sin(Date.now() * 0.0004 + id * 1.3) * 0.4;
  });
  return (
    <group ref={ref} position={[x, 0, z]}>
      {/* Leg 1 */}
      <mesh position={[-0.08, 0.55, 0]}><cylinderGeometry args={[0.04, 0.04, 1.1, 5]} /><meshLambertMaterial color="#ff88aa" /></mesh>
      {/* Leg 2 */}
      <mesh position={[0.08, 0.55, 0]}><cylinderGeometry args={[0.04, 0.04, 1.1, 5]} /><meshLambertMaterial color="#ff88aa" /></mesh>
      {/* Body */}
      <mesh position={[0, 1.2, 0]}><sphereGeometry args={[0.3, 7, 6]} /><meshLambertMaterial color="#ff88bb" /></mesh>
      {/* Neck */}
      <mesh position={[0, 1.75, 0.1]} rotation={[0.3, 0, 0]}><cylinderGeometry args={[0.06, 0.09, 0.7, 5]} /><meshLambertMaterial color="#ff88aa" /></mesh>
      {/* Head */}
      <mesh position={[0, 2.18, 0.28]}><sphereGeometry args={[0.16, 6, 6]} /><meshLambertMaterial color="#ff88aa" /></mesh>
      {/* Beak */}
      <mesh position={[0, 2.15, 0.44]} rotation={[0.4, 0, 0]}><boxGeometry args={[0.07, 0.07, 0.22]} /><meshLambertMaterial color="#ff4466" /></mesh>
    </group>
  );
}

// ── Main component ──────────────────────────────────────────────────────────
export default function Wildlife({ gameState, setGameState }: Props) {
  const visRef = useRef<THREE.Group>(null);

  // Cull entire wildlife group when very far from all wildlife zones
  useFrame(() => {
    if (!visRef.current) return;
    const px = playerWorldPos.x, pz = playerWorldPos.z;
    // Wildlife zones: Grassrivers (~-170,130), Keys (~140,300)
    const d1 = (px + 170) ** 2 + (pz - 130) ** 2;
    const d2 = (px - 140) ** 2 + (pz - 300) ** 2;
    visRef.current.visible = Math.min(d1, d2) < 380 * 380;
  });

  return (
    <group ref={visRef}>
      {GATORS.map((g) => (
        <Alligator key={g.id} data={g} setGameState={setGameState} noCrash={gameState.noCrash} />
      ))}
      {BOARS.map((b) => <WildBoar key={b.id} data={b} />)}
      {FLAMINGO_FLOCK.map((f) => <Flamingo key={f.id} x={f.x} z={f.z} id={f.id} />)}
    </group>
  );
}
