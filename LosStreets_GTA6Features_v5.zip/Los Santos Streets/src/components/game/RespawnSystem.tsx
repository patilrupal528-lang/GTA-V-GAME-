import { useEffect, useRef } from "react";
import { GameState } from "./types";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  onRespawn: () => void;
}

export default function RespawnSystem({ gameState, setGameState, onRespawn }: Props) {
  const deadRef = useRef(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (gameState.health <= 0 && !deadRef.current && !gameState.noCrash) {
      deadRef.current = true;

      timerRef.current = setTimeout(() => {
        setGameState((s) => ({
          ...s,
          health: 100,
          armor: 0,
          wanted: 0,
          inVehicle: false,
          vehicleSpeed: 0,
          weapon: "pistol",
          ammo: 30,
          maxAmmo: 30,
          deaths: s.deaths + 1,
          money: Math.max(0, s.money - 500),
          missionText: `💀 Wasted! -$500 fine. Respawned at Hospital. Total deaths: ${gameState.deaths + 1}`,
          missionActive: false,
        }));
        deadRef.current = false;
        onRespawn();
      }, 2500);
    }

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [gameState.health, gameState.noCrash]);

  if (gameState.health > 0 || gameState.noCrash) return null;

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 80,
      display: "flex", alignItems: "center", justifyContent: "center",
      pointerEvents: "none",
      background: "rgba(0,0,0,0.0)",
      animation: "fadeBlood 0.5s forwards",
    }}>
      <div style={{ textAlign: "center" }}>
        <div style={{
          fontSize: 64, fontWeight: 900, color: "#cc0000",
          letterSpacing: 10, fontFamily: "monospace",
          textShadow: "0 0 40px #ff0000, 0 0 80px #880000",
          animation: "wastedPulse 0.3s ease-out",
        }}>
          WASTED
        </div>
        <div style={{ color: "#ff6666", fontFamily: "monospace", fontSize: 16, marginTop: 12 }}>
          Respawning at Hospital...
        </div>
      </div>
      <style>{`
        @keyframes fadeBlood {
          0% { background: rgba(120,0,0,0.0); }
          30% { background: rgba(120,0,0,0.75); }
          80% { background: rgba(0,0,0,0.88); }
          100% { background: rgba(0,0,0,0.88); }
        }
        @keyframes wastedPulse {
          0% { transform: scale(0.5); opacity: 0; }
          60% { transform: scale(1.1); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
