import { useEffect, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { GameState } from "./types";
import { gameAI } from "../../utils/GameAI";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

/**
 * NoCrashSystem — Integrates GameAI tick + global error/crash protection.
 *
 * What it does (all silent, zero UI):
 *  1. Calls gameAI.tick() every frame for FPS monitoring
 *  2. Suppresses global JS errors via window event listeners
 *  3. Clamps health to 20 in God Mode (state repair done by GameAI tests)
 *  4. Runs lightweight state check every 120 frames (~2s) to avoid
 *     setInterval React conflicts
 */
export default function NoCrashSystem({ gameState, setGameState }: Props) {
  const frameCountRef = useRef(0);
  const errHandlerRef = useRef<((e: ErrorEvent) => void) | null>(null);
  const rejHandlerRef = useRef<((e: PromiseRejectionEvent) => void) | null>(null);

  // Register global error suppressors once
  useEffect(() => {
    errHandlerRef.current = (e: ErrorEvent) => {
      // GameAI already handles this — just prevent default here
      e.preventDefault();
    };
    rejHandlerRef.current = (e: PromiseRejectionEvent) => {
      e.preventDefault();
    };
    window.addEventListener("error", errHandlerRef.current, true);
    window.addEventListener("unhandledrejection", rejHandlerRef.current, true);

    return () => {
      if (errHandlerRef.current)
        window.removeEventListener("error", errHandlerRef.current, true);
      if (rejHandlerRef.current)
        window.removeEventListener("unhandledrejection", rejHandlerRef.current, true);
    };
  }, []);

  // Per-frame: GameAI tick + lightweight state clamping every 120 frames
  useFrame(() => {
    // FPS monitoring
    gameAI.tick();

    frameCountRef.current++;
    if (frameCountRef.current % 120 !== 0) return; // ~2 second interval

    setGameState((s) => {
      const needsFix =
        (s.noCrash && s.health < 20) ||
        s.health > 100 ||
        s.armor > 100 ||
        s.ammo < 0 ||
        s.money < 0 ||
        s.wanted < 0 ||
        s.wanted > 5;

      if (!needsFix) return s; // avoid unnecessary re-render

      return {
        ...s,
        health:  s.noCrash ? Math.max(20, Math.min(100, s.health)) : Math.max(0, Math.min(100, s.health)),
        armor:   Math.max(0, Math.min(100, s.armor)),
        ammo:    Math.max(0, s.ammo),
        money:   Math.max(0, s.money),
        wanted:  Math.max(0, Math.min(5, s.wanted)),
      };
    });
  });

  return null; // no rendered output
}
