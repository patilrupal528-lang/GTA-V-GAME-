import { useState } from "react";
import { CharacterConfig } from "./types";

interface Props {
  config: CharacterConfig;
  onChange: (cfg: CharacterConfig) => void;
  onClose: () => void;
}

const SKIN_COLORS = [
  { label: "Light",    value: "#f5d5b8" },
  { label: "Fair",     value: "#e8b090" },
  { label: "Tan",      value: "#c9905a" },
  { label: "Brown",    value: "#9a6040" },
  { label: "Dark",     value: "#6b3e26" },
  { label: "Black",    value: "#3a1e0e" },
];

const OUTFITS: Array<{
  id: string; name: string; bodyColor: string; pantsColor: string;
  shoeColor: string; desc: string; icon: string; hatColor: string;
}> = [
  { id: "franklin",  name: "Franklin",        bodyColor: "#1a6622", pantsColor: "#2a2a3a", shoeColor: "#111",    desc: "Green hoodie – Franklin's classic look", icon: "🟢", hatColor: "#111" },
  { id: "michael",   name: "Michael",         bodyColor: "#3a5a9a", pantsColor: "#303060", shoeColor: "#222",    desc: "Blue suit – Michael's signature style",  icon: "🔵", hatColor: "#2a3a5a" },
  { id: "trevor",    name: "Trevor",          bodyColor: "#7a4a2a", pantsColor: "#3a2a1a", shoeColor: "#3a2a10", desc: "Dirty jacket – Trevor's rough look",     icon: "🟤", hatColor: "#4a3a2a" },
  { id: "gangster",  name: "Grove Street",    bodyColor: "#2a7a2a", pantsColor: "#1a1a2a", shoeColor: "#fff",    desc: "Grove Street Families colors",           icon: "💚", hatColor: "#1a4a1a" },
  { id: "ballas",    name: "Ballas",          bodyColor: "#6a1a7a", pantsColor: "#2a1a3a", shoeColor: "#111",    desc: "Ballas gang colors – purple",            icon: "🟣", hatColor: "#4a0a5a" },
  { id: "lspd",      name: "LSPD Officer",    bodyColor: "#1a2a5a", pantsColor: "#1a1a2a", shoeColor: "#111",    desc: "Los Santos Police Department uniform",   icon: "👮", hatColor: "#0a1a4a" },
  { id: "army",      name: "Military",        bodyColor: "#3a4a2a", pantsColor: "#2a3a1a", shoeColor: "#2a2a1a", desc: "Army camo combat gear",                  icon: "🪖", hatColor: "#2a3a1a" },
  { id: "beach",     name: "Beach",           bodyColor: "#e8a020", pantsColor: "#1a6080", shoeColor: "#e8d080", desc: "Vespucci Beach casual wear",             icon: "🏖️", hatColor: "#f0d080" },
  { id: "suit",      name: "Black Suit",      bodyColor: "#1a1a1a", pantsColor: "#111111", shoeColor: "#333",    desc: "Formal black business suit",             icon: "🕴️", hatColor: "#1a1a1a" },
  { id: "red",       name: "Red Jacket",      bodyColor: "#aa1a1a", pantsColor: "#2a2a2a", shoeColor: "#111",    desc: "Red varsity jacket street style",        icon: "🔴", hatColor: "#8a1010" },
  { id: "white",     name: "White Tee",       bodyColor: "#f0f0f0", pantsColor: "#4a4a4a", shoeColor: "#fff",    desc: "Simple white tee + grey jeans",          icon: "⚪", hatColor: "#ddd" },
  { id: "hazmat",    name: "Hazmat",          bodyColor: "#ff9900", pantsColor: "#ff8800", shoeColor: "#cc6600", desc: "Trevor's cook suit – yellow hazmat",     icon: "☢️", hatColor: "#cc7700" },
];

const HAT_COLORS = [
  { label: "Black",  value: "#111" },
  { label: "White",  value: "#eee" },
  { label: "Navy",   value: "#1a2a4a" },
  { label: "Red",    value: "#aa1a1a" },
  { label: "Green",  value: "#1a4a1a" },
  { label: "Camo",   value: "#3a4a2a" },
];

function MiniPlayer({ cfg }: { cfg: CharacterConfig }) {
  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center", gap: 0,
      position: "relative", userSelect: "none",
    }}>
      {/* Hat */}
      {cfg.hatOn && (
        <div style={{ width: 26, height: 9, background: cfg.hatColor, borderRadius: "3px 3px 0 0", marginBottom: -2, zIndex: 1 }} />
      )}
      {/* Head */}
      <div style={{ width: 24, height: 24, background: cfg.skinColor, borderRadius: 3, border: "1px solid rgba(0,0,0,0.2)", position: "relative" }}>
        {/* Eyes */}
        <div style={{ position: "absolute", top: 8, left: 4, width: 5, height: 4, background: "#333", borderRadius: 1 }} />
        <div style={{ position: "absolute", top: 8, right: 4, width: 5, height: 4, background: "#333", borderRadius: 1 }} />
        {/* Glasses */}
        {cfg.glassesOn && (
          <div style={{ position: "absolute", top: 7, left: 2, right: 2, height: 6, border: "1.5px solid #444", borderRadius: 2, background: "rgba(100,200,255,0.25)" }} />
        )}
      </div>
      {/* Neck chain */}
      {cfg.chainOn && (
        <div style={{ width: 18, height: 4, background: "linear-gradient(90deg,#aa8800,#ffdd00,#aa8800)", borderRadius: 2, marginTop: 1 }} />
      )}
      {/* Body */}
      <div style={{ width: 30, height: 36, background: cfg.bodyColor, borderRadius: 2, marginTop: cfg.chainOn ? 1 : 3, border: "1px solid rgba(0,0,0,0.2)" }} />
      {/* Arms */}
      <div style={{ position: "absolute", top: cfg.hatOn ? 78 : 70, left: -8, width: 10, height: 32, background: cfg.bodyColor, borderRadius: 2 }} />
      <div style={{ position: "absolute", top: cfg.hatOn ? 78 : 70, right: -8, width: 10, height: 32, background: cfg.bodyColor, borderRadius: 2 }} />
      {/* Pants */}
      <div style={{ display: "flex", gap: 2, marginTop: 1 }}>
        <div style={{ width: 13, height: 30, background: cfg.pantsColor, borderRadius: "0 0 3px 3px" }} />
        <div style={{ width: 13, height: 30, background: cfg.pantsColor, borderRadius: "0 0 3px 3px" }} />
      </div>
      {/* Shoes */}
      <div style={{ display: "flex", gap: 2 }}>
        <div style={{ width: 15, height: 7, background: cfg.shoeColor, borderRadius: "0 0 3px 3px" }} />
        <div style={{ width: 15, height: 7, background: cfg.shoeColor, borderRadius: "0 0 3px 3px" }} />
      </div>
    </div>
  );
}

export default function CharacterCustomization({ config, onChange, onClose }: Props) {
  const [tab, setTab] = useState<"skin" | "outfit" | "accessories">("outfit");
  const [local, setLocal] = useState<CharacterConfig>({ ...config });

  const apply = (patch: Partial<CharacterConfig>) => {
    const next = { ...local, ...patch };
    setLocal(next);
  };

  const handleSave = () => {
    onChange(local);
    onClose();
  };

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.93)",
      zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "monospace",
    }}>
      <div style={{
        background: "linear-gradient(160deg, #0d0d1a 0%, #111120 100%)",
        border: "2px solid rgba(255,255,255,0.12)", borderRadius: 22,
        padding: 28, width: "min(680px, 97vw)", maxHeight: "93vh", overflowY: "auto",
      }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#fff", letterSpacing: 2 }}>👕 WARDROBE</div>
            <div style={{ fontSize: 10, color: "#555", letterSpacing: 2 }}>CHARACTER CUSTOMIZATION</div>
          </div>
          <button onClick={onClose} style={{ background: "#222", border: "1px solid #444", borderRadius: 8, color: "#aaa", padding: "6px 14px", cursor: "pointer", fontFamily: "monospace" }}>✕ CLOSE</button>
        </div>

        <div style={{ display: "flex", gap: 22 }}>
          {/* Preview */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
            <div style={{
              background: "rgba(255,255,255,0.04)", borderRadius: 14, padding: "30px 28px",
              border: "1px solid rgba(255,255,255,0.08)", minWidth: 110,
              display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
            }}>
              <div style={{ fontSize: 11, color: "#555", letterSpacing: 2, marginBottom: 8 }}>PREVIEW</div>
              <MiniPlayer cfg={local} />
            </div>
            {/* Outfit name */}
            <div style={{
              background: "rgba(255,200,0,0.1)", border: "1px solid rgba(255,200,0,0.3)",
              borderRadius: 8, padding: "6px 14px", textAlign: "center",
            }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#ffd700" }}>{local.outfitName}</div>
              <div style={{ fontSize: 9, color: "#666" }}>CURRENT OUTFIT</div>
            </div>
            {/* Save button */}
            <button
              onClick={handleSave}
              style={{
                background: "rgba(0,180,60,0.4)", border: "1px solid rgba(0,255,100,0.5)",
                borderRadius: 10, color: "#00ff66", padding: "10px 22px",
                cursor: "pointer", fontFamily: "monospace", fontWeight: 900, fontSize: 13,
                width: "100%", letterSpacing: 1,
              }}
            >
              ✅ SAVE & APPLY
            </button>
          </div>

          {/* Right panel */}
          <div style={{ flex: 1, minWidth: 0 }}>
            {/* Tabs */}
            <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
              {(["outfit", "skin", "accessories"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  style={{
                    flex: 1, background: tab === t ? "rgba(100,100,200,0.5)" : "rgba(255,255,255,0.04)",
                    border: `1px solid ${tab === t ? "rgba(150,150,255,0.5)" : "rgba(255,255,255,0.08)"}`,
                    borderRadius: 8, color: tab === t ? "#fff" : "#666",
                    padding: "7px 0", cursor: "pointer", fontFamily: "monospace",
                    fontWeight: tab === t ? 700 : 400, fontSize: 11, textTransform: "uppercase",
                  }}
                >
                  {t === "outfit" ? "👕 Outfit" : t === "skin" ? "🎨 Skin" : "💍 Access."}
                </button>
              ))}
            </div>

            {/* OUTFIT TAB */}
            {tab === "outfit" && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, maxHeight: 400, overflowY: "auto" }}>
                {OUTFITS.map((o) => (
                  <button
                    key={o.id}
                    onClick={() => apply({ outfitId: o.id, bodyColor: o.bodyColor, pantsColor: o.pantsColor, shoeColor: o.shoeColor, outfitName: o.name, hatColor: o.hatColor })}
                    style={{
                      background: local.outfitId === o.id ? "rgba(100,100,200,0.35)" : "rgba(255,255,255,0.04)",
                      border: `2px solid ${local.outfitId === o.id ? "rgba(150,150,255,0.6)" : "rgba(255,255,255,0.06)"}`,
                      borderRadius: 10, padding: "10px 12px", cursor: "pointer",
                      textAlign: "left", transition: "all 0.15s",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 18 }}>{o.icon}</span>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 700, color: local.outfitId === o.id ? "#fff" : "#ccc" }}>{o.name}</div>
                        <div style={{ fontSize: 9, color: "#666", lineHeight: 1.4 }}>{o.desc}</div>
                      </div>
                    </div>
                    {local.outfitId === o.id && (
                      <div style={{ display: "flex", gap: 4, marginTop: 6 }}>
                        {[o.bodyColor, o.pantsColor, o.shoeColor].map((c, i) => (
                          <div key={i} style={{ width: 12, height: 12, background: c, borderRadius: 3, border: "1px solid rgba(255,255,255,0.2)" }} />
                        ))}
                      </div>
                    )}
                  </button>
                ))}
              </div>
            )}

            {/* SKIN TAB */}
            {tab === "skin" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div style={{ color: "#888", fontSize: 12, marginBottom: 4 }}>Choose skin tone:</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10 }}>
                  {SKIN_COLORS.map((s) => (
                    <button
                      key={s.value}
                      onClick={() => apply({ skinColor: s.value })}
                      style={{
                        background: s.value,
                        border: `3px solid ${local.skinColor === s.value ? "#fff" : "rgba(255,255,255,0.1)"}`,
                        borderRadius: 10, padding: "20px 0", cursor: "pointer",
                        display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                        boxShadow: local.skinColor === s.value ? "0 0 12px rgba(255,255,255,0.4)" : "none",
                      }}
                    >
                      <div style={{ fontSize: 10, fontWeight: 700, color: "rgba(0,0,0,0.6)", fontFamily: "monospace" }}>{s.label}</div>
                      {local.skinColor === s.value && <div style={{ fontSize: 12 }}>✓</div>}
                    </button>
                  ))}
                </div>
                {/* Custom hex */}
                <div style={{ marginTop: 8 }}>
                  <div style={{ color: "#555", fontSize: 10, marginBottom: 6 }}>CUSTOM COLOR:</div>
                  <input
                    type="color"
                    value={local.skinColor}
                    onChange={(e) => apply({ skinColor: e.target.value })}
                    style={{
                      width: "100%", height: 44, border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 8, cursor: "pointer", background: "none",
                    }}
                  />
                </div>
              </div>
            )}

            {/* ACCESSORIES TAB */}
            {tab === "accessories" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {/* Hat */}
                <div style={{
                  background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "12px 14px",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                    <div style={{ color: "#fff", fontWeight: 700, fontSize: 13 }}>🧢 Cap / Hat</div>
                    <Toggle value={local.hatOn} onChange={(v) => apply({ hatOn: v })} />
                  </div>
                  {local.hatOn && (
                    <div>
                      <div style={{ color: "#555", fontSize: 10, marginBottom: 6 }}>HAT COLOR:</div>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        {HAT_COLORS.map((h) => (
                          <button
                            key={h.value}
                            onClick={() => apply({ hatColor: h.value })}
                            style={{
                              width: 32, height: 32, background: h.value,
                              border: `2px solid ${local.hatColor === h.value ? "#fff" : "rgba(255,255,255,0.1)"}`,
                              borderRadius: 6, cursor: "pointer",
                              boxShadow: local.hatColor === h.value ? "0 0 8px rgba(255,255,255,0.4)" : "none",
                            }}
                            title={h.label}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Glasses */}
                <div style={{
                  background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "12px 14px",
                  border: "1px solid rgba(255,255,255,0.06)",
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                }}>
                  <div>
                    <div style={{ color: "#fff", fontWeight: 700, fontSize: 13 }}>🕶️ Sunglasses</div>
                    <div style={{ color: "#555", fontSize: 10 }}>Stylish blue-tinted shades</div>
                  </div>
                  <Toggle value={local.glassesOn} onChange={(v) => apply({ glassesOn: v })} />
                </div>

                {/* Chain */}
                <div style={{
                  background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "12px 14px",
                  border: "1px solid rgba(255,255,255,0.06)",
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                }}>
                  <div>
                    <div style={{ color: "#fff", fontWeight: 700, fontSize: 13 }}>⛓️ Gold Chain</div>
                    <div style={{ color: "#555", fontSize: 10 }}>Gold chain necklace</div>
                  </div>
                  <Toggle value={local.chainOn} onChange={(v) => apply({ chainOn: v })} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      style={{
        width: 52, height: 28, borderRadius: 14, cursor: "pointer",
        background: value ? "rgba(0,200,80,0.5)" : "rgba(100,100,100,0.3)",
        border: `1px solid ${value ? "rgba(0,255,100,0.5)" : "rgba(255,255,255,0.1)"}`,
        position: "relative", transition: "all 0.2s", flexShrink: 0,
      }}
    >
      <div style={{
        position: "absolute", top: 3, left: value ? 26 : 4,
        width: 20, height: 20, borderRadius: "50%",
        background: value ? "#00ff66" : "#666",
        transition: "all 0.2s", boxShadow: value ? "0 0 8px #00cc44" : "none",
      }} />
    </button>
  );
}
