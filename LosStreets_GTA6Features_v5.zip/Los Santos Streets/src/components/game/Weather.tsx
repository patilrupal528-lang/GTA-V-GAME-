import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface RainDrop {
  x: number; y: number; z: number; vy: number;
}

const RAIN_COUNT = 600;
const RAIN_AREA = 80;
const RAIN_HEIGHT = 40;

export default function Weather({ raining }: { raining: boolean }) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const drops = useMemo<RainDrop[]>(() =>
    Array.from({ length: RAIN_COUNT }, () => ({
      x: (Math.random() - 0.5) * RAIN_AREA * 2,
      y: Math.random() * RAIN_HEIGHT,
      z: (Math.random() - 0.5) * RAIN_AREA * 2,
      vy: 18 + Math.random() * 8,
    })),
  []);

  useFrame((state, delta) => {
    if (!meshRef.current || !raining) return;
    const cam = state.camera.position;

    for (let i = 0; i < RAIN_COUNT; i++) {
      const d = drops[i];
      d.y -= d.vy * delta;
      if (d.y < 0) {
        d.y = RAIN_HEIGHT;
        d.x = cam.x + (Math.random() - 0.5) * RAIN_AREA * 2;
        d.z = cam.z + (Math.random() - 0.5) * RAIN_AREA * 2;
      }
      dummy.position.set(cam.x + d.x, d.y, cam.z + d.z);
      dummy.scale.set(0.04, 0.6, 0.04);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  if (!raining) return null;

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, RAIN_COUNT]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshLambertMaterial color="#aaccee" transparent opacity={0.55} />
    </instancedMesh>
  );
}
