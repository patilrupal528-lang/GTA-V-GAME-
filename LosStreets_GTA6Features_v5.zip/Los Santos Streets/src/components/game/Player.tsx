import { useRef, MutableRefObject } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { GameState, MobileInput } from "./types";
import { resolveCollision } from "../../utils/buildingCollisions";
import { playGunshot } from "./Audio";

interface Props {
  mobileInput: MutableRefObject<MobileInput>;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  gameState: GameState;
  spawnBullet: (pos: [number, number, number], dir: [number, number, number]) => void;
  spawnExplosion: (x: number, y: number, z: number) => void;
  respawnTarget: MutableRefObject<[number, number, number]>;
}

enum Controls {
  forward = "forward",
  back    = "back",
  left    = "left",
  right   = "right",
  run     = "run",
  enter   = "enter",
  shoot   = "shoot",
}

const WALK_SPEED     = 7;
const RUN_MULT       = 1.9;
const DRIVE_ACCEL    = 18;
const DRIVE_MAX      = 55;
const DRIVE_FRICTION = 0.96;
const TURN_SPEED     = 2.4;
const CAM_DIST       = 12;
const CAM_HEIGHT     = 6;
const SHOOT_CD       = 0.22;

export const playerWorldPos = new THREE.Vector3(0, 0, 5);

const animState = { runBlend: 0, aimBlend: 0, stepPhase: 0, leanX: 0 };

export default function Player({ mobileInput, setGameState, gameState, spawnBullet, spawnExplosion, respawnTarget }: Props) {
  const { camera } = useThree();
  const playerRef      = useRef<THREE.Group>(null);
  const cameraAngle    = useRef(0);
  const phantomVehicle = useRef(new THREE.Group());
  const drivingRef     = useRef(false);
  const vehicleSpeed   = useRef(0);
  const steerAngle     = useRef(0);
  const bodyRoll       = useRef(0);
  const shootCd        = useRef(0);
  const enterCooldown  = useRef(0);
  const prevHealth     = useRef(gameState.health);
  const wheelRotation  = useRef(0);

  const [, getKeys] = useKeyboardControls<Controls>();

  useFrame((_, delta) => {
    if (!playerRef.current) return;
    const dt = Math.min(delta, 0.05);
    const keys = getKeys();
    const mob  = mobileInput.current;

    // Respawn
    if (gameState.health > 0 && prevHealth.current <= 0) {
      const target = respawnTarget.current;
      playerRef.current.position.set(target[0], target[1], target[2]);
      phantomVehicle.current.position.copy(playerRef.current.position);
      drivingRef.current = false;
      vehicleSpeed.current = 0;
    }
    prevHealth.current = gameState.health;

    shootCd.current     = Math.max(0, shootCd.current - dt);
    enterCooldown.current = Math.max(0, enterCooldown.current - dt);

    const fwd  = (keys[Controls.forward] ? 1 : 0) + (mob.joystick.y < -0.2 ? 1 : 0);
    const bck  = (keys[Controls.back]    ? 1 : 0) + (mob.joystick.y >  0.2 ? 1 : 0);
    const lft  = (keys[Controls.left]    ? 1 : 0) + (mob.joystick.x < -0.2 ? 1 : 0);
    const rgt  = (keys[Controls.right]   ? 1 : 0) + (mob.joystick.x >  0.2 ? 1 : 0);
    const run  = keys[Controls.run]  || mob.run;
    const doEnter = (keys[Controls.enter] || mob.enter) && enterCooldown.current <= 0;
    const doShoot = (keys[Controls.shoot] || mob.shoot) && shootCd.current <= 0;
    const moving  = fwd > 0 || bck > 0;

    // Vehicle enter/exit
    if (doEnter) {
      enterCooldown.current = 0.6;
      if (!drivingRef.current && gameState.nearVehicle) {
        phantomVehicle.current.position.copy(playerRef.current.position);
        phantomVehicle.current.rotation.copy(playerRef.current.rotation);
        vehicleSpeed.current = 0;
        steerAngle.current = 0;
        drivingRef.current = true;
        setGameState((s) => ({
          ...s, inVehicle: true, nearVehicle: false, vehicleSpeed: 0,
          missionText: `🚗 Entered ${s.vehicleName}! Drive with joystick.`,
        }));
      } else if (drivingRef.current) {
        const exitOffset = new THREE.Vector3(-2.5, 0, 0)
          .applyQuaternion(phantomVehicle.current.quaternion);
        playerRef.current.position.copy(phantomVehicle.current.position).add(exitOffset);
        drivingRef.current = false;
        vehicleSpeed.current = 0;
        setGameState((s) => ({ ...s, inVehicle: false, vehicleSpeed: 0, missionText: "🚪 Exited vehicle." }));
      }
    }

    // Driving
    if (drivingRef.current) {
      if (fwd > 0) vehicleSpeed.current = Math.min(vehicleSpeed.current + DRIVE_ACCEL * dt, DRIVE_MAX);
      else if (bck > 0) vehicleSpeed.current = Math.max(vehicleSpeed.current - DRIVE_ACCEL * 1.5 * dt, -DRIVE_MAX * 0.4);
      else vehicleSpeed.current *= DRIVE_FRICTION;

      if (Math.abs(vehicleSpeed.current) < 0.1) vehicleSpeed.current = 0;

      const steerTarget = (rgt - lft) * TURN_SPEED * (1 - Math.abs(vehicleSpeed.current) / (DRIVE_MAX * 2));
      steerAngle.current += (steerTarget - steerAngle.current) * 8 * dt;
      const bodyRollTarget = -steerAngle.current * 0.18;
      bodyRoll.current += (bodyRollTarget - bodyRoll.current) * 5 * dt;

      if (Math.abs(vehicleSpeed.current) > 0.5) {
        phantomVehicle.current.rotation.y -= steerAngle.current * (vehicleSpeed.current / DRIVE_MAX) * dt;
      }

      const dir = new THREE.Vector3(0, 0, vehicleSpeed.current * dt)
        .applyQuaternion(phantomVehicle.current.quaternion);
      phantomVehicle.current.position.add(dir);
      resolveCollision(phantomVehicle.current.position, 2.5);
      phantomVehicle.current.position.y = 0.1;

      playerRef.current.position.copy(phantomVehicle.current.position);
      playerRef.current.position.y = 0;
      playerRef.current.rotation.y = phantomVehicle.current.rotation.y;

      playerWorldPos.copy(playerRef.current.position);

      const camAngle = phantomVehicle.current.rotation.y + Math.PI;
      const camX = phantomVehicle.current.position.x + Math.sin(camAngle) * (CAM_DIST * 1.4);
      const camZ = phantomVehicle.current.position.z + Math.cos(camAngle) * (CAM_DIST * 1.4);
      camera.position.lerp(new THREE.Vector3(camX, CAM_HEIGHT * 1.3, camZ), 5 * dt);
      camera.lookAt(phantomVehicle.current.position.x, 1.5, phantomVehicle.current.position.z);

      const kmh = Math.round(Math.abs(vehicleSpeed.current) * 3.6);
      setGameState((s) => s.vehicleSpeed === kmh ? s : { ...s, vehicleSpeed: kmh });

      // Vehicle body roll
      const carBody = playerRef.current.getObjectByName("carBody") as THREE.Mesh | undefined;
      if (carBody) carBody.rotation.z = bodyRoll.current;

      // Wheel spin animation
      wheelRotation.current += vehicleSpeed.current * dt * 3;
      ["wfl", "wfr", "wrl", "wrr"].forEach((name) => {
        const w = playerRef.current!.getObjectByName(name) as THREE.Mesh | undefined;
        if (w) w.rotation.x = wheelRotation.current;
      });

      return;
    }

    // On foot
    const speed = run ? WALK_SPEED * RUN_MULT : WALK_SPEED;

    if (lft && !moving) cameraAngle.current += 1.8 * dt;
    if (rgt && !moving) cameraAngle.current -= 1.8 * dt;

    if (fwd > 0 || bck > 0) {
      const sign = fwd > 0 ? 1 : -0.55;
      const moveAngle = cameraAngle.current;
      const dx = Math.sin(moveAngle) * speed * sign * dt;
      const dz = Math.cos(moveAngle) * speed * sign * dt;
      playerRef.current.position.x += dx;
      playerRef.current.position.z += dz;
      resolveCollision(playerRef.current.position, 0.5);
      playerRef.current.position.y = 0;
      playerRef.current.rotation.y = moveAngle + (fwd > 0 ? 0 : Math.PI);
    }
    if ((lft || rgt) && moving) {
      const offset = lft ? Math.PI / 2 : -Math.PI / 2;
      playerRef.current.rotation.y = cameraAngle.current + offset;
    }

    playerWorldPos.copy(playerRef.current.position);

    const camX = playerRef.current.position.x + Math.sin(cameraAngle.current) * CAM_DIST;
    const camZ = playerRef.current.position.z + Math.cos(cameraAngle.current) * CAM_DIST;
    camera.position.lerp(new THREE.Vector3(camX, CAM_HEIGHT, camZ), 8 * dt);
    camera.lookAt(playerRef.current.position.x, 1.2, playerRef.current.position.z);

    // Shooting — with audio
    if (doShoot && gameState.ammo > 0) {
      shootCd.current = SHOOT_CD;
      playGunshot();
      const dir = new THREE.Vector3(
        Math.sin(playerRef.current.rotation.y),
        0.08,
        Math.cos(playerRef.current.rotation.y)
      ).normalize();
      const origin: [number, number, number] = [
        playerRef.current.position.x + dir.x,
        1.4,
        playerRef.current.position.z + dir.z,
      ];
      spawnBullet(origin, [dir.x, dir.y, dir.z]);
      setGameState((s) => ({ ...s, ammo: Math.max(0, s.ammo - 1) }));
    }

    // Procedural animation
    animState.runBlend  += ((moving ? (run ? 1 : 0.55) : 0) - animState.runBlend) * 10 * dt;
    animState.aimBlend  += ((doShoot ? 1 : 0) - animState.aimBlend) * 8 * dt;
    animState.stepPhase += moving ? dt * (4 + animState.runBlend * 4) : 0;
    const leanTarget = (rgt - lft) * (moving ? 0.18 : 0);
    animState.leanX += (leanTarget - animState.leanX) * 6 * dt;

    const swing    = Math.sin(animState.stepPhase) * (0.38 + animState.runBlend * 0.38);
    const armSwing = Math.sin(animState.stepPhase + Math.PI) * (0.26 + animState.runBlend * 0.22);
    const bobY     = moving ? Math.abs(Math.sin(animState.stepPhase * 2)) * 0.035 : 0;

    const p = playerRef.current;
    const lLeg = p.getObjectByName("ll") as THREE.Mesh | undefined;
    const rLeg = p.getObjectByName("rl") as THREE.Mesh | undefined;
    if (lLeg) lLeg.rotation.x = swing;
    if (rLeg) rLeg.rotation.x = -swing;
    const lArm = p.getObjectByName("la") as THREE.Mesh | undefined;
    const rArm = p.getObjectByName("ra") as THREE.Mesh | undefined;
    if (lArm) lArm.rotation.x = -armSwing - animState.aimBlend * 0.6;
    if (rArm) rArm.rotation.x = armSwing - animState.aimBlend * 0.6;
    const body = p.getObjectByName("body") as THREE.Mesh | undefined;
    if (body) { body.position.y = 1.1 + bobY; body.rotation.z = animState.leanX; }
    const head = p.getObjectByName("head") as THREE.Mesh | undefined;
    if (head) head.position.y = 1.82 + bobY;
  });

  const { bodyColor, pantsColor, shoeColor, skinColor, hatOn, hatColor, glassesOn, chainOn } = gameState.character;

  return (
    <group ref={playerRef} position={[0, 0, 5]}>
      {/* Hat */}
      {hatOn && (
        <>
          <mesh position={[0, 2.22, 0]} name="hat">
            <boxGeometry args={[0.52, 0.1, 0.52]} />
            <meshLambertMaterial color={hatColor} />
          </mesh>
          <mesh position={[0, 2.3, 0]}>
            <boxGeometry args={[0.38, 0.22, 0.38]} />
            <meshLambertMaterial color={hatColor} />
          </mesh>
        </>
      )}
      {/* Head */}
      <mesh name="head" position={[0, 1.82, 0]} castShadow>
        <boxGeometry args={[0.44, 0.44, 0.44]} />
        <meshLambertMaterial color={skinColor} />
      </mesh>
      {/* Eyes */}
      <mesh position={[-0.1, 1.86, 0.22]}>
        <boxGeometry args={[0.09, 0.07, 0.02]} />
        <meshLambertMaterial color="#111" />
      </mesh>
      <mesh position={[0.1, 1.86, 0.22]}>
        <boxGeometry args={[0.09, 0.07, 0.02]} />
        <meshLambertMaterial color="#111" />
      </mesh>
      {/* Sunglasses */}
      {glassesOn && (
        <mesh position={[0, 1.86, 0.23]}>
          <boxGeometry args={[0.38, 0.1, 0.02]} />
          <meshLambertMaterial color="#111" transparent opacity={0.75} />
        </mesh>
      )}
      {/* Neck */}
      <mesh position={[0, 1.56, 0]}>
        <boxGeometry args={[0.18, 0.18, 0.18]} />
        <meshLambertMaterial color={skinColor} />
      </mesh>
      {/* Gold chain */}
      {chainOn && (
        <mesh position={[0, 1.5, 0.08]}>
          <boxGeometry args={[0.28, 0.05, 0.04]} />
          <meshLambertMaterial color="#ffcc00" emissive="#aa8800" emissiveIntensity={0.5} />
        </mesh>
      )}
      {/* Body */}
      <mesh name="body" position={[0, 1.1, 0]} castShadow>
        <boxGeometry args={[0.55, 0.75, 0.35]} />
        <meshLambertMaterial color={bodyColor} />
      </mesh>
      {/* Left Arm */}
      <mesh name="la" position={[-0.38, 1.12, 0]} castShadow>
        <boxGeometry args={[0.18, 0.62, 0.18]} />
        <meshLambertMaterial color={bodyColor} />
      </mesh>
      {/* Right Arm */}
      <mesh name="ra" position={[0.38, 1.12, 0]} castShadow>
        <boxGeometry args={[0.18, 0.62, 0.18]} />
        <meshLambertMaterial color={bodyColor} />
      </mesh>
      {/* Hands */}
      <mesh position={[-0.38, 0.78, 0]}>
        <boxGeometry args={[0.16, 0.17, 0.16]} />
        <meshLambertMaterial color={skinColor} />
      </mesh>
      <mesh position={[0.38, 0.78, 0]}>
        <boxGeometry args={[0.16, 0.17, 0.16]} />
        <meshLambertMaterial color={skinColor} />
      </mesh>
      {/* Belt */}
      <mesh position={[0, 0.73, 0]}>
        <boxGeometry args={[0.57, 0.07, 0.37]} />
        <meshLambertMaterial color="#333" />
      </mesh>
      {/* Left Leg */}
      <mesh name="ll" position={[-0.14, 0.38, 0]} castShadow>
        <boxGeometry args={[0.22, 0.62, 0.22]} />
        <meshLambertMaterial color={pantsColor} />
      </mesh>
      {/* Right Leg */}
      <mesh name="rl" position={[0.14, 0.38, 0]} castShadow>
        <boxGeometry args={[0.22, 0.62, 0.22]} />
        <meshLambertMaterial color={pantsColor} />
      </mesh>
      {/* Shoes */}
      <mesh position={[-0.14, 0.07, 0.06]}>
        <boxGeometry args={[0.24, 0.1, 0.36]} />
        <meshLambertMaterial color={shoeColor} />
      </mesh>
      <mesh position={[0.14, 0.07, 0.06]}>
        <boxGeometry args={[0.24, 0.1, 0.36]} />
        <meshLambertMaterial color={shoeColor} />
      </mesh>

      {/* In-vehicle car model */}
      {gameState.inVehicle && (
        <group name="carBody" position={[0, 0.5, 0]}>
          {/* Main body */}
          <mesh castShadow>
            <boxGeometry args={[2.3, 0.68, 4.6]} />
            <meshLambertMaterial color="#1a1a2e" />
          </mesh>
          {/* Cabin */}
          <mesh position={[0, 0.65, -0.22]}>
            <boxGeometry args={[1.95, 0.6, 2.1]} />
            <meshLambertMaterial color="#16213e" />
          </mesh>
          {/* Front windshield */}
          <mesh position={[0, 0.65, 1.04]}>
            <boxGeometry args={[1.75, 0.52, 0.06]} />
            <meshLambertMaterial color="#88ccff" transparent opacity={0.5} />
          </mesh>
          {/* Rear window */}
          <mesh position={[0, 0.65, -1.28]}>
            <boxGeometry args={[1.68, 0.48, 0.06]} />
            <meshLambertMaterial color="#88ccff" transparent opacity={0.4} />
          </mesh>
          {/* Side windows */}
          <mesh position={[0.98, 0.65, 0]}>
            <boxGeometry args={[0.05, 0.45, 1.8]} />
            <meshLambertMaterial color="#88ccff" transparent opacity={0.38} />
          </mesh>
          <mesh position={[-0.98, 0.65, 0]}>
            <boxGeometry args={[0.05, 0.45, 1.8]} />
            <meshLambertMaterial color="#88ccff" transparent opacity={0.38} />
          </mesh>
          {/* Headlights */}
          <mesh position={[-0.75, 0.2, 2.33]}>
            <boxGeometry args={[0.55, 0.2, 0.05]} />
            <meshLambertMaterial color="#fff" emissive="#ffffa0" emissiveIntensity={0.9} />
          </mesh>
          <mesh position={[0.75, 0.2, 2.33]}>
            <boxGeometry args={[0.55, 0.2, 0.05]} />
            <meshLambertMaterial color="#fff" emissive="#ffffa0" emissiveIntensity={0.9} />
          </mesh>
          {/* Taillights */}
          <mesh position={[0, 0.2, -2.33]}>
            <boxGeometry args={[1.75, 0.22, 0.05]} />
            <meshLambertMaterial color="#ff2222" emissive="#ff0000" emissiveIntensity={1.0} />
          </mesh>
          {/* Wheels with rotation */}
          {([[-1.05, -0.25, 1.5, "wfl"], [1.05, -0.25, 1.5, "wfr"], [-1.05, -0.25, -1.5, "wrl"], [1.05, -0.25, -1.5, "wrr"]] as [number,number,number,string][]).map(([x, y, z, name], i) => (
            <group key={i} position={[x, y, z]}>
              <mesh name={name} rotation={[0, 0, 0]}>
                <cylinderGeometry args={[0.42, 0.42, 0.32, 12]} />
                <meshLambertMaterial color="#111" />
              </mesh>
              <mesh rotation={[Math.PI / 2, 0, 0]}>
                <cylinderGeometry args={[0.24, 0.24, 0.06, 8]} />
                <meshLambertMaterial color="#888" />
              </mesh>
            </group>
          ))}
          {/* Spoiler */}
          <mesh position={[0, 0.98, -2.2]}>
            <boxGeometry args={[2.0, 0.1, 0.55]} />
            <meshLambertMaterial color="#111" />
          </mesh>
          {/* Front bumper */}
          <mesh position={[0, 0.15, 2.38]}>
            <boxGeometry args={[2.1, 0.24, 0.14]} />
            <meshLambertMaterial color="#222" />
          </mesh>
        </group>
      )}
    </group>
  );
}
