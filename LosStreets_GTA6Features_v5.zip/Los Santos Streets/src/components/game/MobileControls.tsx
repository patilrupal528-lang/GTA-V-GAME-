import { useRef, useCallback, useState } from "react";
import { GameState, MobileInput } from "./types";

interface Props {
  onInput: (input: Partial<MobileInput>) => void;
  gameState: GameState;
}

const JOYSTICK_MAX = 50;

export default function MobileControls({ onInput, gameState }: Props) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const originRef = useRef({ x: 0, y: 0 });
  const touchIdRef = useRef<number | null>(null);
  const [shootActive, setShootActive] = useState(false);

  const onJoyStart = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    const t = e.changedTouches[0];
    touchIdRef.current = t.identifier;
    originRef.current = { x: t.clientX, y: t.clientY };
  }, []);

  const onJoyMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    let touch: { clientX: number; clientY: number } | null = null;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === touchIdRef.current) { touch = { clientX: t.clientX, clientY: t.clientY }; break; }
    }
    if (!touch) return;
    const dx = touch.clientX - originRef.current.x;
    const dy = touch.clientY - originRef.current.y;
    const dist = Math.min(Math.sqrt(dx * dx + dy * dy), JOYSTICK_MAX);
    const angle = Math.atan2(dy, dx);
    const kx = Math.cos(angle) * dist;
    const ky = Math.sin(angle) * dist;
    setKnob({ x: kx, y: ky });
    onInput({ joystick: { x: kx / JOYSTICK_MAX, y: ky / JOYSTICK_MAX } });
  }, [onInput]);

  const onJoyEnd = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    setKnob({ x: 0, y: 0 });
    touchIdRef.current = null;
    onInput({ joystick: { x: 0, y: 0 } });
  }, [onInput]);

  return (
    <div style={{
      position: "fixed", bottom: 0, left: 0, right: 0, height: 200,
      zIndex: 20, pointerEvents: "none", display: "flex",
      justifyContent: "space-between", alignItems: "flex-end", padding: "0 20px 24px",
    }}
      className="mobile-only"
    >
      {/* Left Joystick */}
      <div style={{ pointerEvents: "all" }}>
        <div
          onTouchStart={onJoyStart}
          onTouchMove={onJoyMove}
          onTouchEnd={onJoyEnd}
          onTouchCancel={onJoyEnd}
          style={{
            width: 110, height: 110, borderRadius: "50%",
            background: "rgba(255,255,255,0.10)",
            border: "2px solid rgba(255,255,255,0.28)",
            position: "relative", touchAction: "none",
            backdropFilter: "blur(3px)",
          }}
        >
          <div style={{
            position: "absolute", top: "50%", left: "50%", width: 42, height: 42,
            borderRadius: "50%", background: "rgba(255,255,255,0.75)",
            border: "2px solid rgba(255,255,255,0.95)",
            transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))`,
            boxShadow: "0 2px 10px rgba(0,0,0,0.4)",
            transition: knob.x === 0 && knob.y === 0 ? "transform 0.15s" : "none",
          }} />
        </div>
      </div>

      {/* Right Action Buttons */}
      <div style={{ pointerEvents: "all", display: "flex", flexDirection: "column", gap: 10, alignItems: "flex-end" }}>
        {/* Run */}
        <div style={{ display: "flex", gap: 10 }}>
          <Btn
            label="⚡"
            sub="RUN"
            color="rgba(180,120,0,0.7)"
            border="rgba(255,200,50,0.5)"
            onStart={() => onInput({ run: true })}
            onEnd={() => onInput({ run: false })}
          />
          {/* Enter/Exit */}
          <Btn
            label={gameState.inVehicle ? "🚪" : "🚗"}
            sub={gameState.inVehicle ? "EXIT" : "ENTER"}
            color="rgba(30,100,200,0.7)"
            border="rgba(80,160,255,0.5)"
            onStart={() => onInput({ enter: true })}
            onEnd={() => onInput({ enter: false })}
            glow={gameState.nearVehicle}
          />
        </div>
        {/* Shoot */}
        <Btn
          label="🔫"
          sub="SHOOT"
          color={shootActive ? "rgba(220,30,30,0.9)" : "rgba(160,20,20,0.7)"}
          border="rgba(255,80,80,0.6)"
          size={64}
          onStart={() => { setShootActive(true); onInput({ shoot: true }); }}
          onEnd={() => { setShootActive(false); onInput({ shoot: false }); }}
        />
      </div>

      <style>{`
        .mobile-only { display: flex; }
        @media (min-width: 768px) { .mobile-only { display: none; } }
      `}</style>
    </div>
  );
}

function Btn({
  label, sub, color, border, size = 55, onStart, onEnd, glow = false
}: {
  label: string; sub: string; color: string; border: string;
  size?: number; onStart: () => void; onEnd: () => void; glow?: boolean;
}) {
  return (
    <div
      onTouchStart={(e) => { e.preventDefault(); onStart(); }}
      onTouchEnd={(e) => { e.preventDefault(); onEnd(); }}
      onTouchCancel={(e) => { e.preventDefault(); onEnd(); }}
      style={{
        width: size, height: size, borderRadius: "50%",
        background: color, border: `2px solid ${border}`,
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        cursor: "pointer", touchAction: "manipulation", userSelect: "none",
        backdropFilter: "blur(4px)", WebkitTapHighlightColor: "transparent",
        boxShadow: glow ? "0 0 15px rgba(80,160,255,0.8)" : "0 2px 10px rgba(0,0,0,0.5)",
        transition: "box-shadow 0.2s",
      }}
    >
      <span style={{ fontSize: size * 0.36 }}>{label}</span>
      <span style={{ fontSize: 8, color: "rgba(255,255,255,0.7)", fontFamily: "monospace", letterSpacing: 0.5 }}>{sub}</span>
    </div>
  );
}
