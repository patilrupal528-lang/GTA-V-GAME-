import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState } from "./types";

interface Props {
  timeOfDay: number;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

export default function DayNight({ timeOfDay, setGameState }: Props) {
  const sunRef = useRef<THREE.DirectionalLight>(null);
  const ambientRef = useRef<THREE.AmbientLight>(null);
  const hemiRef = useRef<THREE.HemisphereLight>(null);
  const skyRef = useRef<THREE.Mesh>(null);
  const timeRef = useRef(timeOfDay);
  const frameRef = useRef(0);

  useFrame((_, delta) => {
    timeRef.current = (timeRef.current + delta * 0.018) % 1;
    const t = timeRef.current;
    // FIX: Only update React state every 60 frames (~1s) to prevent 60fps re-renders
    frameRef.current++;
    if (frameRef.current % 60 === 0) {
      setGameState((s) => (Math.abs(s.timeOfDay - t) > 0.001 ? { ...s, timeOfDay: t } : s));
    }

    const angle = t * Math.PI * 2 - Math.PI / 2;
    const sinA = Math.sin(angle);
    const dayIntensity = Math.max(0, sinA);
    const dusk = Math.max(0, Math.sin(angle) < 0.3 ? 1 - Math.abs(sinA) * 4 : 0);

    if (sunRef.current) {
      sunRef.current.position.set(Math.cos(angle) * 200, Math.abs(sinA) * 200, 80);
      sunRef.current.intensity = dayIntensity * 2.8 + dusk * 1.2;
      sunRef.current.color.setRGB(
        1,
        Math.max(0.3, dayIntensity * 0.85 + dusk * 0.5),
        Math.max(0.1, dayIntensity * 0.6 - dusk * 0.3)
      );
    }
    if (ambientRef.current) {
      ambientRef.current.intensity = 0.06 + dayIntensity * 0.55;
    }
    if (hemiRef.current) {
      hemiRef.current.intensity = 0.08 + dayIntensity * 0.3;
    }

    // Sky color
    if (skyRef.current) {
      const mat = skyRef.current.material as THREE.MeshBasicMaterial;
      if (dayIntensity > 0.1) {
        mat.color.setRGB(
          0.4 + dayIntensity * 0.15 + dusk * 0.3,
          0.55 + dayIntensity * 0.25 - dusk * 0.2,
          0.65 + dayIntensity * 0.3 - dusk * 0.3
        );
      } else {
        mat.color.setRGB(0.02, 0.04, 0.12);
      }
    }
  });

  return (
    <>
      {/* Sky dome */}
      <mesh ref={skyRef} scale={[-1, 1, 1]}>
        <sphereGeometry args={[490, 24, 12]} />
        <meshBasicMaterial side={THREE.BackSide} color="#87ceeb" />
      </mesh>

      <directionalLight
        ref={sunRef}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-far={500}
        shadow-camera-left={-200}
        shadow-camera-right={200}
        shadow-camera-top={200}
        shadow-camera-bottom={-200}
        shadow-bias={-0.001}
      />
      <ambientLight ref={ambientRef} color="#9bb4d4" intensity={0.3} />
      <hemisphereLight ref={hemiRef} args={["#87ceeb", "#2d4a20", 0.25]} />
    </>
  );
}
