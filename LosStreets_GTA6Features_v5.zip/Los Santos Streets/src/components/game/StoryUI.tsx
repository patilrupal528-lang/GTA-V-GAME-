import { useEffect, useState } from "react";

interface DialogueLine {
  speaker: string;
  color: string;
  text: string;
}

const INTRO_DIALOGUE: DialogueLine[] = [
  { speaker: "FRANKLIN", color: "#44cc66", text: "Aye, welcome to Los Santos. It's dangerous out here." },
  { speaker: "MICHAEL", color: "#4488ff", text: "This city will eat you alive if you let it. Stay sharp." },
  { speaker: "TREVOR", color: "#ff4444", text: "I LOVE this place! Let's cause some CHAOS!" },
];

interface Props {
  missionText: string;
  missionIndex: number;
}

export default function StoryUI({ missionText, missionIndex }: Props) {
  const [dialogueLine, setDialogueLine] = useState<DialogueLine | null>(null);
  const [visible, setVisible] = useState(false);
  const [prevText, setPrevText] = useState("");

  useEffect(() => {
    if (missionIndex === 0 && !visible && missionText !== prevText) {
      setDialogueLine(INTRO_DIALOGUE[0]);
      setVisible(true);
      const t1 = setTimeout(() => setDialogueLine(INTRO_DIALOGUE[1]), 3500);
      const t2 = setTimeout(() => setDialogueLine(INTRO_DIALOGUE[2]), 7000);
      const t3 = setTimeout(() => setVisible(false), 10500);
      setPrevText(missionText);
      return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
    }
  }, [missionIndex]);

  if (!visible || !dialogueLine) return null;

  return (
    <div style={{
      position: "fixed",
      bottom: 160,
      left: "50%",
      transform: "translateX(-50%)",
      background: "rgba(0,0,0,0.88)",
      border: `2px solid ${dialogueLine.color}44`,
      borderLeft: `4px solid ${dialogueLine.color}`,
      borderRadius: 10,
      padding: "12px 22px",
      maxWidth: 500,
      width: "90vw",
      zIndex: 50,
      animation: "fadeInUp 0.3s ease",
      backdropFilter: "blur(8px)",
    }}>
      <div style={{
        fontSize: 11,
        fontFamily: "monospace",
        fontWeight: 900,
        letterSpacing: 2,
        color: dialogueLine.color,
        marginBottom: 5,
      }}>
        {dialogueLine.speaker}
      </div>
      <div style={{
        fontSize: 13,
        color: "#eee",
        fontFamily: "monospace",
        lineHeight: 1.5,
      }}>
        "{dialogueLine.text}"
      </div>
      <style>{`@keyframes fadeInUp { from{opacity:0;transform:translateX(-50%) translateY(10px)} to{opacity:1;transform:translateX(-50%) translateY(0)} }`}</style>
    </div>
  );
}
