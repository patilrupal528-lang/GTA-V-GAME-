import { useRef, useMemo, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { ExplosionData } from "./types";
import { playExplosion } from "./Audio";

const PARTICLE_COUNT = 18;
const DURATION = 1.2;

function Explosion({ data, onDone }: { data: ExplosionData; onDone: () => void }) {
  const groupRef = useRef<THREE.Group>(null);
  const doneRef  = useRef(false);
  // FIX: capture actual elapsed time at mount so startTime=0 doesn't break timing
  const mountTimeRef = useRef<number | null>(null);

  useEffect(() => { playExplosion(); }, []);

  const particles = useMemo(() =>
    Array.from({ length: PARTICLE_COUNT }, () => ({
      dir: new THREE.Vector3(
        (Math.random() - 0.5) * 2,
        Math.random() * 1.5,
        (Math.random() - 0.5) * 2
      ).normalize(),
      speed: 4 + Math.random() * 8,
      size:  0.15 + Math.random() * 0.5,
    })), []
  );

  const meshRefs = useRef<(THREE.Mesh | null)[]>([]);

  useFrame((state) => {
    if (doneRef.current) return;

    // Capture clock time on first frame after mount
    if (mountTimeRef.current === null) {
      mountTimeRef.current = state.clock.elapsedTime;
    }

    const elapsed = state.clock.elapsedTime - mountTimeRef.current;
    const t = elapsed / DURATION;

    if (t >= 1) {
      if (!doneRef.current) { doneRef.current = true; onDone(); }
      return;
    }

    meshRefs.current.forEach((mesh, i) => {
      if (!mesh) return;
      const p = particles[i];
      mesh.position.set(
        data.x + p.dir.x * p.speed * elapsed,
        data.y + p.dir.y * p.speed * elapsed - 4.9 * elapsed * elapsed,
        data.z + p.dir.z * p.speed * elapsed
      );
      (mesh.material as THREE.MeshLambertMaterial).opacity = 1 - t;
      mesh.scale.setScalar(p.size * (1 - t * 0.5));
    });

    // Shrink flash sphere
    if (groupRef.current) {
      const flash = groupRef.current.children[0] as THREE.Mesh | undefined;
      if (flash) flash.scale.setScalar(Math.max(0, (0.3 - t) * 15));
    }
  });

  return (
    <group ref={groupRef}>
      {/* Flash sphere */}
      <mesh position={[data.x, data.y + 0.5, data.z]}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshLambertMaterial color="#ffff88" emissive="#ffcc00" emissiveIntensity={2} transparent opacity={0.9} />
      </mesh>
      {/* Fire particles */}
      {particles.map((p, i) => (
        <mesh
          key={i}
          ref={(el) => { meshRefs.current[i] = el; }}
          position={[data.x, data.y, data.z]}
        >
          <sphereGeometry args={[p.size, 5, 5]} />
          <meshLambertMaterial
            color={i % 3 === 0 ? "#ff4400" : i % 3 === 1 ? "#ff8800" : "#ffcc00"}
            emissive={i % 2 === 0 ? "#cc2200" : "#cc6600"}
            emissiveIntensity={1.5}
            transparent
          />
        </mesh>
      ))}
      {/* Light flash */}
      <pointLight position={[data.x, data.y + 1, data.z]} color="#ff8800" intensity={8} distance={20} />
    </group>
  );
}

interface Props {
  explosions: ExplosionData[];
  removeExplosion: (id: number) => void;
}

export default function Explosions({ explosions, removeExplosion }: Props) {
  return (
    <>
      {explosions.map((e) => (
        <Explosion key={e.id} data={e} onDone={() => removeExplosion(e.id)} />
      ))}
    </>
  );
}
