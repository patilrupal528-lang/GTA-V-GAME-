import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { BulletData } from "./types";

interface BulletProps {
  data: BulletData;
  onRemove: (id: number) => void;
}

function Bullet({ data, onRemove }: BulletProps) {
  const ref = useRef<THREE.Mesh>(null);
  const lifeRef = useRef(0);
  const pos = useRef(new THREE.Vector3(...data.position));
  const dir = useRef(new THREE.Vector3(...data.direction).normalize());

  useFrame((_, delta) => {
    if (!ref.current) return;
    lifeRef.current += delta;
    if (lifeRef.current > 2) {
      onRemove(data.id);
      return;
    }
    const speed = 40;
    pos.current.addScaledVector(dir.current, speed * delta);
    ref.current.position.copy(pos.current);

    // Simple ground collision
    if (pos.current.y < 0) {
      onRemove(data.id);
    }
  });

  return (
    <mesh ref={ref} position={data.position} castShadow>
      <sphereGeometry args={[0.06, 5, 5]} />
      <meshLambertMaterial color="#ffdd44" emissive="#ffaa00" emissiveIntensity={1} />
    </mesh>
  );
}

interface Props {
  bullets: BulletData[];
  removeBullet: (id: number) => void;
}

export default function Bullets({ bullets, removeBullet }: Props) {
  return (
    <group>
      {bullets.map((b) => (
        <Bullet key={b.id} data={b} onRemove={removeBullet} />
      ))}
    </group>
  );
}
