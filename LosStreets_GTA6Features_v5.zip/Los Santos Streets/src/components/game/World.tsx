/**
 * LEONIDA — GTA VI inspired world map
 *
 * Regions:
 *  Vice City        — Miami-inspired metro, neon beaches, Art Deco, skyscrapers
 *  Ocean Drive      — Beachfront boardwalk, neon clubs, luxury hotels
 *  Little Havana    — Cuban-flavoured suburb west of VC core
 *  Port Gellhorn    — NW industrial docks & suburban sprawl
 *  Grassrivers      — Everglades-style wetlands, swamp shacks, wildlife
 *  Leonida Keys     — Florida Keys chain — small islands with bridges
 *  Lake Leonida     — Inland lake / recreation area
 *  Mount Caliga     — N wilderness — mountains, national park, snow caps
 *
 * World extents ≈ 1800 × 1800 units (playerWorldPos in metres equiv.)
 */

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { playerWorldPos } from "./Player";
import { deviceProfile } from "../../utils/DeviceProfile";

// ─── LOD distances per tier ─────────────────────────────────────────────────
const LOD = {
  high: { full: 350, med: 550, cull: 750 },
  mid:  { full: 220, med: 340, cull: 480 },
  low:  { full: 110, med: 180, cull: 260 },
}[deviceProfile.tier];

// ─── Culled Group ────────────────────────────────────────────────────────────
function CulledGroup({ cx, cz, r, children }: { cx: number; cz: number; r: number; children: React.ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  const rSq = r * r;
  useFrame(() => {
    if (!ref.current) return;
    const dx = cx - playerWorldPos.x, dz = cz - playerWorldPos.z;
    ref.current.visible = (dx * dx + dz * dz) < rSq;
  });
  return <group ref={ref}>{children}</group>;
}

// ─── Building ────────────────────────────────────────────────────────────────
function Building({
  x, z, w, h, d, c, wc, label, neon,
}: {
  x: number; z: number; w: number; h: number; d: number;
  c: string; wc?: string; label?: string; neon?: string;
}) {
  const isTall = h > 40;
  const isVeryTall = h > 80;
  const near = x * x + z * z < 90000;

  return (
    <CulledGroup cx={x} cz={z} r={LOD.cull}>
      <group position={[x, h / 2, z]}>
        {/* Main body */}
        <mesh castShadow receiveShadow>
          <boxGeometry args={[w, h, d]} />
          <meshLambertMaterial color={c} />
        </mesh>

        {/* Window glass overlay — only near player */}
        {near && wc && (
          <>
            <mesh position={[0, 0, d / 2 + 0.02]}>
              <boxGeometry args={[w - 0.5, h - 1, 0.04]} />
              <meshLambertMaterial color={wc} transparent opacity={0.28} />
            </mesh>
            <mesh position={[w / 2 + 0.02, 0, 0]}>
              <boxGeometry args={[0.04, h - 1, d - 0.5]} />
              <meshLambertMaterial color={wc} transparent opacity={0.2} />
            </mesh>
            {/* Horizontal window bands */}
            {Array.from({ length: Math.min(10, Math.floor(h / 10)) }, (_, i) => (
              <mesh key={i} position={[0, -h / 2 + 6 + i * 10, d / 2 + 0.03]}>
                <boxGeometry args={[w - 0.8, 1.6, 0.02]} />
                <meshLambertMaterial color={wc} transparent opacity={0.5} emissive={wc} emissiveIntensity={0.12} />
              </mesh>
            ))}
          </>
        )}

        {/* Rooftop slab */}
        <mesh position={[0, h / 2 + 0.35, 0]}>
          <boxGeometry args={[w + 0.2, 0.7, d + 0.2]} />
          <meshLambertMaterial color="#1e1e1e" />
        </mesh>

        {/* Rooftop AC */}
        {isTall && (
          <mesh position={[w * 0.22, h / 2 + 0.8, d * 0.2]}>
            <boxGeometry args={[1.6, 0.7, 0.9]} />
            <meshLambertMaterial color="#444" />
          </mesh>
        )}

        {/* Antenna + warning light */}
        {isVeryTall && (
          <>
            <mesh position={[0, h / 2 + 3.5, 0]}>
              <cylinderGeometry args={[0.1, 0.18, 6, 5]} />
              <meshLambertMaterial color="#666" />
            </mesh>
            <pointLight color="#ff2200" intensity={1.0} distance={14} position={[0, h / 2 + 7, 0]} />
          </>
        )}

        {/* Neon sign */}
        {neon && (
          <>
            <mesh position={[0, -h / 2 + 4, d / 2 + 0.08]}>
              <boxGeometry args={[w * 0.7, 1.4, 0.08]} />
              <meshLambertMaterial color={neon} emissive={neon} emissiveIntensity={2} />
            </mesh>
            <pointLight color={neon} intensity={3} distance={18} position={[0, -h / 2 + 4.5, d / 2 + 1]} />
          </>
        )}

        {h > 60 && <pointLight color="#ff2200" intensity={0.8} distance={12} position={[0, h / 2 + 1.5, 0]} />}
      </group>
    </CulledGroup>
  );
}

// ─── Road ────────────────────────────────────────────────────────────────────
function Road({ x, z, l, w, r = 0, markings = true }: { x: number; z: number; l: number; w: number; r?: number; markings?: boolean }) {
  return (
    <group position={[x, 0.02, z]} rotation={[0, r, 0]}>
      <mesh receiveShadow>
        <boxGeometry args={[l, 0.04, w]} />
        <meshLambertMaterial color="#1a1a1a" />
      </mesh>
      {markings && (
        <>
          <mesh position={[0, 0.021, 0]}>
            <boxGeometry args={[l, 0.01, 0.28]} />
            <meshLambertMaterial color="#e8dc50" />
          </mesh>
          <mesh position={[0, 0.021, w / 2 - 0.5]}>
            <boxGeometry args={[l, 0.01, 0.18]} />
            <meshLambertMaterial color="#ddd" />
          </mesh>
          <mesh position={[0, 0.021, -(w / 2 - 0.5)]}>
            <boxGeometry args={[l, 0.01, 0.18]} />
            <meshLambertMaterial color="#ddd" />
          </mesh>
        </>
      )}
    </group>
  );
}

// ─── Palm Tree ───────────────────────────────────────────────────────────────
function PalmTree({ x, z }: { x: number; z: number }) {
  const h = 7 + (Math.abs(x + z * 2) % 5);
  return (
    <CulledGroup cx={x} cz={z} r={LOD.med}>
      <group position={[x, 0, z]}>
        {/* Trunk — slight lean */}
        <mesh position={[0.3, h / 2, 0.2]} rotation={[0.06, 0, 0.05]}>
          <cylinderGeometry args={[0.18, 0.28, h, 6]} />
          <meshLambertMaterial color="#7a5a2a" />
        </mesh>
        {/* Fronds — 6 directions */}
        {[0, 60, 120, 180, 240, 300].map((deg, i) => (
          <mesh
            key={i}
            position={[
              0.3 + Math.cos((deg * Math.PI) / 180) * 2.2,
              h + 0.5,
              0.2 + Math.sin((deg * Math.PI) / 180) * 2.2,
            ]}
            rotation={[0.38, (deg * Math.PI) / 180, 0]}
          >
            <boxGeometry args={[3.5, 0.12, 0.5]} />
            <meshLambertMaterial color={["#1a6a1a", "#1e781e", "#157015"][i % 3]} />
          </mesh>
        ))}
        {/* Coconuts */}
        <mesh position={[0.3, h + 0.3, 0.2]}>
          <sphereGeometry args={[0.4, 6, 6]} />
          <meshLambertMaterial color="#5a3a10" />
        </mesh>
      </group>
    </CulledGroup>
  );
}

// ─── Swamp Tree ───────────────────────────────────────────────────────────────
function SwampTree({ x, z }: { x: number; z: number }) {
  const h = 5 + (Math.abs(x * z) % 4);
  return (
    <CulledGroup cx={x} cz={z} r={LOD.med}>
      <group position={[x, 0, z]}>
        <mesh position={[0, h / 2, 0]} rotation={[0.02, 0, Math.sin(x) * 0.1]}>
          <cylinderGeometry args={[0.22, 0.35, h, 5]} />
          <meshLambertMaterial color="#3a2a1a" />
        </mesh>
        {/* Hanging moss canopy */}
        <mesh position={[0, h + 1.5, 0]}>
          <sphereGeometry args={[2.5 + (Math.abs(x) % 2) * 0.5, 6, 5]} />
          <meshLambertMaterial color="#2a4a1a" transparent opacity={0.85} />
        </mesh>
        {/* Hanging vines */}
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[Math.sin(i * 2) * 1.2, h - 0.5, Math.cos(i * 2) * 1.2]}>
            <cylinderGeometry args={[0.04, 0.04, 2.5, 4]} />
            <meshLambertMaterial color="#2a3a1a" transparent opacity={0.7} />
          </mesh>
        ))}
        {/* Aerial roots */}
        <mesh position={[-0.6, 0.6, 0.4]}>
          <cylinderGeometry args={[0.06, 0.06, 1.2, 4]} />
          <meshLambertMaterial color="#3a2a1a" />
        </mesh>
      </group>
    </CulledGroup>
  );
}

// ─── Street Lamp ─────────────────────────────────────────────────────────────
function Lamp({ x, z, neon }: { x: number; z: number; neon?: boolean }) {
  return (
    <CulledGroup cx={x} cz={z} r={100}>
      <group position={[x, 0, z]}>
        <mesh position={[0, 4.5, 0]}>
          <cylinderGeometry args={[0.07, 0.1, 9, 5]} />
          <meshLambertMaterial color="#555" />
        </mesh>
        <mesh position={[0.8, 9, 0]}>
          <boxGeometry args={[1.6, 0.14, 0.14]} />
          <meshLambertMaterial color="#444" />
        </mesh>
        <mesh position={[0.8, 8.7, 0]}>
          <boxGeometry args={[0.44, 0.24, 0.44]} />
          <meshLambertMaterial
            color={neon ? "#ff88cc" : "#ffe080"}
            emissive={neon ? "#ff44aa" : "#ffe080"}
            emissiveIntensity={0.9}
          />
        </mesh>
        <pointLight
          position={[0.8, 8.4, 0]}
          intensity={neon ? 2.5 : 1.8}
          distance={neon ? 28 : 22}
          color={neon ? "#ff88cc" : "#ffe880"}
        />
      </group>
    </CulledGroup>
  );
}

// ─── VICE CITY — Downtown skyscrapers ────────────────────────────────────────
function ViceCity() {
  const TOWERS = [
    // Mega towers
    { x: 120, z: -30, w: 12, h: 200, d: 12, c: "#1a2a3a", wc: "#5a9acc", neon: "#ff44aa" },
    { x: 100, z: -10, w: 10, h: 160, d: 10, c: "#2a3a4a", wc: "#6aaccc" },
    { x: 140, z: -15, w: 11, h: 145, d: 11, c: "#1e2e3e", wc: "#7abcdc" },
    { x: 160, z: -30, w: 9,  h: 130, d: 9,  c: "#253545", wc: "#70b0d0" },
    // Mid
    { x: 180, z: -20, w: 10, h: 100, d: 10, c: "#2a3040", wc: "#68a8c8" },
    { x: 200, z: -35, w: 9,  h: 90,  d: 9,  c: "#304050", wc: "#6098b8" },
    { x: 80,  z: -20, w: 10, h: 85,  d: 10, c: "#c0a080", wc: "#e0c0a0" }, // Art Deco
    { x: 80,  z: -50, w: 8,  h: 78,  d: 8,  c: "#d0b090", wc: "#f0d0b0" },
    { x: 60,  z: -30, w: 8,  h: 70,  d: 8,  c: "#c8b888", wc: "#e8d8a8" },
    { x: 100, z: -40, w: 8,  h: 68,  d: 8,  c: "#304060", wc: "#5090b8" },
    { x: 120, z: -50, w: 9,  h: 72,  d: 9,  c: "#283848", wc: "#5898b8" },
    { x: 140, z: -45, w: 7,  h: 58,  d: 7,  c: "#1a2a3a", wc: "#4888a8" },
    { x: 160, z: -50, w: 8,  h: 65,  d: 8,  c: "#263646", wc: "#5898b8" },
    { x: 220, z: -20, w: 9,  h: 88,  d: 9,  c: "#202030", wc: "#5080b0", neon: "#44ffcc" },
    { x: 220, z: -45, w: 8,  h: 75,  d: 8,  c: "#1c2c3c", wc: "#4898c8" },
    { x: 200, z: -60, w: 7,  h: 55,  d: 7,  c: "#2a3a4a", wc: "#6098b8" },
    // Short commercial
    { x: 60,  z: -55, w: 7,  h: 22,  d: 7,  c: "#e0c8a8", wc: "#fff0d8", neon: "#ff8800" },
    { x: 240, z: -30, w: 8,  h: 35,  d: 8,  c: "#1a2a3a", wc: "#4888b8", neon: "#8844ff" },
  ];

  const OCEAN_DRIVE = [
    { x: 255, z: 15,  w: 8,  h: 20, d: 6, c: "#f5e8cc", wc: "#fff8e4", neon: "#ff4488" },
    { x: 255, z: 35,  w: 7,  h: 18, d: 6, c: "#e8d4b8", wc: "#fff0d8", neon: "#44ccff" },
    { x: 255, z: 55,  w: 8,  h: 24, d: 6, c: "#fceedd", wc: "#fff8ee", neon: "#ff8800" },
    { x: 255, z: 75,  w: 7,  h: 16, d: 6, c: "#f0e8d8", wc: "#fff8e8", neon: "#ff44cc" },
    { x: 255, z: 95,  w: 8,  h: 22, d: 6, c: "#f8f0e0", wc: "#fffaf0", neon: "#88ff44" },
    { x: 255, z: 115, w: 7,  h: 18, d: 6, c: "#ecdcc8", wc: "#ffeedd", neon: "#ffcc00" },
    { x: 238, z: 25,  w: 10, h: 30, d: 8, c: "#f0e4d0", wc: "#fff4e4", neon: "#ff6688" },
    { x: 238, z: 65,  w: 10, h: 28, d: 8, c: "#f4e8d8", wc: "#fff8e8", neon: "#4488ff" },
    { x: 238, z: 105, w: 10, h: 32, d: 8, c: "#f0dcc8", wc: "#ffeedd", neon: "#ff4400" },
  ];

  return (
    <group>
      {TOWERS.map((b, i) => <Building key={`vc${i}`} {...b} />)}
      {OCEAN_DRIVE.map((b, i) => <Building key={`od${i}`} {...b} />)}
    </group>
  );
}

// ─── Vice City Amenities ──────────────────────────────────────────────────────
function ViceCityPD() {
  return (
    <CulledGroup cx={0} cz={-30} r={200}>
      <group position={[0, 0, -30]}>
        <mesh position={[0, 9, 0]} castShadow><boxGeometry args={[30, 18, 20]} /><meshLambertMaterial color="#6a7888" /></mesh>
        <mesh position={[0, 18.5, 0]}><boxGeometry args={[30.4, 1, 20.4]} /><meshLambertMaterial color="#505868" /></mesh>
        <mesh position={[0, 10, 10.1]}><boxGeometry args={[8, 5, 0.1]} /><meshLambertMaterial color="#2244cc" transparent opacity={0.55} /></mesh>
        <mesh position={[0, 20, 0]}><boxGeometry args={[12, 2, 0.2]} /><meshLambertMaterial color="#1133cc" emissive="#0022cc" emissiveIntensity={0.5} /></mesh>
        <pointLight color="#0044ff" intensity={5} distance={35} position={[0, 22, 3]} />
        <mesh position={[0, 0.3, 14]}><boxGeometry args={[22, 0.6, 0.3]} /><meshLambertMaterial color="#ff8800" /></mesh>
      </group>
    </CulledGroup>
  );
}

function ViceMall() {
  return (
    <CulledGroup cx={100} cz={50} r={250}>
      <group position={[100, 0, 50]}>
        <mesh position={[0, 8, 0]} castShadow><boxGeometry args={[50, 16, 24]} /><meshLambertMaterial color="#ddd8cc" /></mesh>
        <mesh position={[0, 16.5, 0]}><boxGeometry args={[50.4, 1, 24.4]} /><meshLambertMaterial color="#ccc8bc" /></mesh>
        {/* Glass atrium dome */}
        <mesh position={[0, 22, 0]}><cylinderGeometry args={[10, 12, 12, 16]} /><meshLambertMaterial color="#aaccee" transparent opacity={0.55} /></mesh>
        {/* Entrance doors */}
        <mesh position={[0, 5, 12.1]}><boxGeometry args={[8, 8, 0.1]} /><meshLambertMaterial color="#88ccee" transparent opacity={0.5} /></mesh>
        <mesh position={[0, 28, 0]}><boxGeometry args={[20, 2, 0.2]} /><meshLambertMaterial color="#ff44aa" emissive="#ff44aa" emissiveIntensity={0.8} /></mesh>
        <pointLight color="#ff44aa" intensity={4} distance={30} position={[0, 26, 2]} />
        <pointLight color="#ffffff" intensity={2} distance={20} position={[0, 10, 0]} />
      </group>
    </CulledGroup>
  );
}

function NightclubStrip() {
  const clubs = [
    { x: 170, z: 60, name: "MALIBU", neon: "#ff44aa", color: "#1a0a1a" },
    { x: 185, z: 60, name: "HEATWAVE",neon: "#ff8800", color: "#0a0a1a" },
    { x: 200, z: 60, name: "CHROME", neon: "#44ccff", color: "#0a1a2a" },
    { x: 215, z: 60, name: "VICE", neon: "#ff4444", color: "#1a0a0a" },
    { x: 230, z: 60, name: "GALAXY", neon: "#8844ff", color: "#0a0a1a" },
  ];
  return (
    <CulledGroup cx={200} cz={60} r={200}>
      <group>
        {clubs.map((c, i) => (
          <group key={i} position={[c.x, 0, c.z]}>
            <mesh position={[0, 5, 0]} castShadow><boxGeometry args={[12, 10, 12]} /><meshLambertMaterial color={c.color} /></mesh>
            <mesh position={[0, 10.4, 0]}><boxGeometry args={[12.4, 0.8, 12.4]} /><meshLambertMaterial color="#111" /></mesh>
            <mesh position={[0, 6.5, 6.08]}><boxGeometry args={[8, 1.5, 0.08]} /><meshLambertMaterial color={c.neon} emissive={c.neon} emissiveIntensity={2.5} /></mesh>
            <mesh position={[0, 11.5, 0]}><boxGeometry args={[8, 2, 0.2]} /><meshLambertMaterial color={c.neon} emissive={c.neon} emissiveIntensity={1.5} /></mesh>
            <pointLight color={c.neon} intensity={6} distance={25} position={[0, 10, 2]} />
          </group>
        ))}
      </group>
    </CulledGroup>
  );
}

// ─── Ocean Drive Boardwalk ────────────────────────────────────────────────────
function OceanDrive() {
  return (
    <CulledGroup cx={280} cz={70} r={300}>
      <group>
        {/* Boardwalk */}
        <mesh position={[285, 0.1, 70]} receiveShadow>
          <boxGeometry args={[20, 0.18, 260]} />
          <meshLambertMaterial color="#c8b890" />
        </mesh>
        {/* Beach sand */}
        <mesh position={[310, -0.05, 70]} receiveShadow>
          <boxGeometry args={[70, 0.1, 260]} />
          <meshLambertMaterial color="#e0d090" />
        </mesh>
        {/* Volleyball nets */}
        {[-30, 30, 90].map((z, i) => (
          <group key={i} position={[310, 0, 70 + z]}>
            <mesh position={[-5, 1.8, 0]}><cylinderGeometry args={[0.08, 0.08, 3.6, 5]} /><meshLambertMaterial color="#888" /></mesh>
            <mesh position={[5, 1.8, 0]}><cylinderGeometry args={[0.08, 0.08, 3.6, 5]} /><meshLambertMaterial color="#888" /></mesh>
            <mesh position={[0, 3.4, 0]}><boxGeometry args={[10, 0.08, 0.5]} /><meshLambertMaterial color="#fff" transparent opacity={0.6} /></mesh>
          </group>
        ))}
        {/* Lifeguard towers */}
        {[-60, 0, 60, 120].map((z, i) => (
          <group key={i} position={[318, 0, 70 + z]}>
            <mesh position={[0, 0.9, 0]}><boxGeometry args={[1, 1.8, 1]} /><meshLambertMaterial color="#888" /></mesh>
            <mesh position={[0, 1.8, 0]}><boxGeometry args={[2.5, 0.12, 2.5]} /><meshLambertMaterial color="#cc2200" /></mesh>
            <mesh position={[0, 2.6, 0]}><boxGeometry args={[2.4, 1.6, 2.4]} /><meshLambertMaterial color="#cc2200" /></mesh>
          </group>
        ))}
        {/* Beach neon lamp poles */}
        {Array.from({ length: 14 }, (_, i) => (
          <Lamp key={i} x={283} z={-60 + i * 20} neon />
        ))}
        {/* Atlantic Ocean */}
        <mesh position={[380, -1, 70]} receiveShadow>
          <boxGeometry args={[180, 2, 500]} />
          <meshLambertMaterial color="#1a5a9a" transparent opacity={0.88} />
        </mesh>
        <mesh position={[296, 0.1, 70]}>
          <boxGeometry args={[12, 0.06, 500]} />
          <meshLambertMaterial color="#2a6ab0" transparent opacity={0.42} />
        </mesh>
        {/* Wave line */}
        <mesh position={[338, 0.2, 70]}>
          <boxGeometry args={[10, 0.28, 500]} />
          <meshLambertMaterial color="#3a7ac0" transparent opacity={0.5} />
        </mesh>
      </group>
    </CulledGroup>
  );
}

// ─── Leonida Keys ─────────────────────────────────────────────────────────────
function LeonidaKeys() {
  const ISLANDS = [
    { x: 140, z: 270, w: 80, d: 45 },
    { x: 130, z: 360, w: 65, d: 40 },
    { x: 120, z: 445, w: 55, d: 35 },
    { x: 110, z: 520, w: 45, d: 30 },
    { x: 100, z: 590, w: 35, d: 25 },
    { x: 90,  z: 650, w: 28, d: 20 },
  ];

  return (
    <CulledGroup cx={120} cz={460} r={450}>
      <group>
        {/* Deep ocean floor */}
        <mesh position={[120, -2, 450]}>
          <boxGeometry args={[400, 3.5, 600]} />
          <meshLambertMaterial color="#0a3060" />
        </mesh>
        {/* Clear turquoise water between keys */}
        <mesh position={[120, -0.5, 460]}>
          <boxGeometry args={[380, 1, 580]} />
          <meshLambertMaterial color="#1a8080" transparent opacity={0.75} />
        </mesh>
        {/* Shallow reef water shimmer */}
        <mesh position={[120, 0.1, 460]}>
          <boxGeometry args={[380, 0.05, 580]} />
          <meshLambertMaterial color="#30b0b0" transparent opacity={0.35} />
        </mesh>

        {/* Island bodies */}
        {ISLANDS.map((isl, i) => (
          <group key={i}>
            <mesh position={[isl.x, 0.05, isl.z]} receiveShadow>
              <boxGeometry args={[isl.w, 0.08, isl.d]} />
              <meshLambertMaterial color="#d0c888" />
            </mesh>
            {/* Sandy beach ring */}
            <mesh position={[isl.x, 0.06, isl.z]}>
              <boxGeometry args={[isl.w + 6, 0.04, isl.d + 6]} />
              <meshLambertMaterial color="#e0d898" transparent opacity={0.6} />
            </mesh>
            {/* Vegetation strip */}
            <mesh position={[isl.x, 0.12, isl.z]}>
              <boxGeometry args={[isl.w - 12, 0.06, isl.d - 10]} />
              <meshLambertMaterial color="#1e5a1e" />
            </mesh>
            {/* Key buildings */}
            <Building x={isl.x - 8} z={isl.z - 4} w={8} h={10} d={7} c="#f0e8d0" wc="#fff8f0" neon="#ff88cc" />
            <Building x={isl.x + 6} z={isl.z + 3} w={7} h={8} d={6} c="#f8f0e0" wc="#fffff0" />
            {/* Palm trees */}
            {Array.from({ length: 4 }, (_, j) => (
              <PalmTree key={j}
                x={isl.x - isl.w / 2 + 8 + j * (isl.w / 5)}
                z={isl.z + (j % 2 === 0 ? -isl.d / 3 : isl.d / 3)}
              />
            ))}
            {/* Wooden pier */}
            <mesh position={[isl.x + isl.w / 2 + 8, 0.15, isl.z]}>
              <boxGeometry args={[18, 0.25, 3]} />
              <meshLambertMaterial color="#9a7a5a" />
            </mesh>
            {/* Sailboat */}
            <group position={[isl.x + isl.w / 2 + 22, 0, isl.z + 4]}>
              <mesh position={[0, 0.6, 0]}><boxGeometry args={[4.5, 1.2, 10]} /><meshLambertMaterial color="#f0e8d0" /></mesh>
              <mesh position={[0, 3.5, 0]}><cylinderGeometry args={[0.1, 0.1, 7, 5]} /><meshLambertMaterial color="#888" /></mesh>
              <mesh position={[0, 3.5, -1.5]} rotation={[0, 0, 0.35]}>
                <boxGeometry args={[0.06, 5.5, 3.5]} /><meshLambertMaterial color="#fff" transparent opacity={0.8} />
              </mesh>
            </group>
          </group>
        ))}

        {/* Overseas Highway bridges connecting keys */}
        {ISLANDS.slice(0, -1).map((isl, i) => {
          const nextIsl = ISLANDS[i + 1];
          const midZ = (isl.z + nextIsl.z) / 2;
          const bridgeLen = nextIsl.z - isl.z - isl.d / 2 - nextIsl.d / 2;
          return (
            <group key={`bridge${i}`}>
              <mesh position={[isl.x, 1.0, midZ]}>
                <boxGeometry args={[14, 0.5, bridgeLen]} />
                <meshLambertMaterial color="#b0b0b0" />
              </mesh>
              <mesh position={[isl.x, 0.9, midZ]}>
                <boxGeometry args={[0.4, 1.2, bridgeLen]} />
                <meshLambertMaterial color="#888" />
              </mesh>
              {/* Bridge pylons */}
              {Array.from({ length: Math.floor(bridgeLen / 20) }, (_, j) => (
                <mesh key={j} position={[isl.x, -1, midZ - bridgeLen / 2 + j * 20 + 10]}>
                  <cylinderGeometry args={[0.8, 1.0, 5, 6]} />
                  <meshLambertMaterial color="#999" />
                </mesh>
              ))}
            </group>
          );
        })}

        {/* Bridge from VC to first key */}
        <mesh position={[140, 1.0, 215]}>
          <boxGeometry args={[14, 0.5, 60]} />
          <meshLambertMaterial color="#b0b0b0" />
        </mesh>
      </group>
    </CulledGroup>
  );
}

// ─── Grassrivers ──────────────────────────────────────────────────────────────
function Grassrivers() {
  return (
    <CulledGroup cx={-170} cz={130} r={400}>
      <group>
        {/* Main swamp floor */}
        <mesh position={[-170, -0.1, 130]} receiveShadow>
          <boxGeometry args={[400, 0.2, 420]} />
          <meshLambertMaterial color="#2a4a1a" />
        </mesh>

        {/* Swamp water channels */}
        {[
          { x: -100, z: 80,  l: 180, w: 22 },
          { x: -180, z: 160, l: 160, w: 18 },
          { x: -120, z: 220, l: 200, w: 25 },
          { x: -200, z: 80,  l: 130, w: 15, r: Math.PI / 4 },
          { x: -150, z: 280, l: 160, w: 20 },
          { x: -250, z: 120, l: 140, w: 16 },
          { x: -80,  z: 180, l: 120, w: 14, r: Math.PI / 6 },
        ].map((ch, i) => (
          <mesh key={i} position={[ch.x, 0.02, ch.z]} rotation={[0, ch.r ?? 0, 0]} receiveShadow>
            <boxGeometry args={[ch.l, 0.06, ch.w]} />
            <meshLambertMaterial color="#1a4a2a" transparent opacity={0.85} />
          </mesh>
        ))}

        {/* Lily pads */}
        {[
          [-100, 80], [-130, 95], [-115, 70], [-160, 165], [-195, 80],
          [-200, 220], [-230, 120], [-80, 195],
        ].map(([px, pz], i) => (
          <mesh key={`lily${i}`} position={[px, 0.1, pz]} rotation={[-Math.PI / 2, 0, i * 0.8]}>
            <circleGeometry args={[1.2 + i * 0.3, 8]} />
            <meshLambertMaterial color="#2a6a2a" side={THREE.DoubleSide} />
          </mesh>
        ))}

        {/* Swamp trees scattered */}
        {[
          [-90, 60], [-110, 110], [-140, 70], [-160, 100], [-180, 70],
          [-200, 100], [-220, 80], [-240, 110], [-260, 90], [-280, 120],
          [-100, 200], [-130, 230], [-160, 250], [-190, 200], [-220, 240],
          [-250, 200], [-280, 220], [-300, 160], [-320, 200], [-90, 160],
          [-110, 290], [-140, 310], [-170, 280], [-200, 300], [-230, 280],
        ].map(([tx, tz], i) => (
          <SwampTree key={i} x={tx} z={tz} />
        ))}

        {/* Wooden shacks & outlaw camps */}
        {[
          { x: -130, z: 100 }, { x: -150, z: 130 }, { x: -200, z: 140 },
          { x: -250, z: 100 }, { x: -160, z: 250 }, { x: -220, z: 240 },
        ].map((sh, i) => (
          <group key={`shack${i}`} position={[sh.x, 0, sh.z]}>
            <mesh position={[0, 2.5, 0]} castShadow>
              <boxGeometry args={[6, 5, 5]} />
              <meshLambertMaterial color="#6a4a2a" />
            </mesh>
            {/* Tin roof */}
            <mesh position={[0, 5.4, 0]} rotation={[0.2, 0, 0]}>
              <boxGeometry args={[7, 0.3, 6.5]} />
              <meshLambertMaterial color="#888878" />
            </mesh>
            {/* Dock */}
            <mesh position={[4, 0.15, 0]}>
              <boxGeometry args={[8, 0.2, 2.5]} />
              <meshLambertMaterial color="#7a5a3a" />
            </mesh>
            {/* Rusty barrel */}
            <mesh position={[-2.5, 0.7, -2]}>
              <cylinderGeometry args={[0.4, 0.4, 1.4, 8]} />
              <meshLambertMaterial color="#884422" />
            </mesh>
            <pointLight color="#ff8822" intensity={1.5} distance={12} position={[0, 4, 3]} />
          </group>
        ))}

        {/* Alligator (static) */}
        {[[-110, 85], [-175, 170], [-225, 130]].map(([ax, az], i) => (
          <group key={`gator${i}`} position={[ax, 0.12, az]}>
            <mesh position={[0, 0, 0]}>
              <boxGeometry args={[0.7, 0.28, 2.2]} />
              <meshLambertMaterial color="#2a4a1a" />
            </mesh>
            <mesh position={[0, 0.1, 1.25]}>
              <boxGeometry args={[0.6, 0.24, 0.7]} />
              <meshLambertMaterial color="#2a4a1a" />
            </mesh>
            {/* Eyes */}
            <mesh position={[-0.22, 0.22, 1.4]}><sphereGeometry args={[0.07, 4, 4]} /><meshLambertMaterial color="#ff8800" emissive="#ff4400" emissiveIntensity={1} /></mesh>
            <mesh position={[0.22, 0.22, 1.4]}><sphereGeometry args={[0.07, 4, 4]} /><meshLambertMaterial color="#ff8800" emissive="#ff4400" emissiveIntensity={1} /></mesh>
          </group>
        ))}

        {/* Flamingos */}
        {[[-95, 170], [-105, 180], [-90, 185]].map(([fx, fz], i) => (
          <group key={`flamingo${i}`} position={[fx, 0, fz]}>
            <mesh position={[0, 0.6, 0]}><cylinderGeometry args={[0.06, 0.06, 1.2, 5]} /><meshLambertMaterial color="#ff88aa" /></mesh>
            <mesh position={[0, 1.3, 0]}><sphereGeometry args={[0.28, 6, 6]} /><meshLambertMaterial color="#ff88aa" /></mesh>
            <mesh position={[0.1, 1.5, 0.22]}><boxGeometry args={[0.16, 0.08, 0.28]} /><meshLambertMaterial color="#ff4488" /></mesh>
          </group>
        ))}
      </group>
    </CulledGroup>
  );
}

// ─── Port Gellhorn ────────────────────────────────────────────────────────────
function PortGellhorn() {
  return (
    <CulledGroup cx={-305} cz={-230} r={380}>
      <group>
        {/* Ground */}
        <mesh position={[-305, -0.1, -230]} receiveShadow>
          <boxGeometry args={[280, 0.2, 260]} />
          <meshLambertMaterial color="#3a3a3a" />
        </mesh>

        {/* Office buildings */}
        {[
          { x: -260, z: -190, w: 16, h: 50, d: 14, c: "#5a6878", wc: "#7898b0" },
          { x: -285, z: -205, w: 14, h: 42, d: 12, c: "#4a5868", wc: "#6888a0" },
          { x: -310, z: -190, w: 15, h: 55, d: 14, c: "#505a68", wc: "#7090a8" },
          { x: -335, z: -205, w: 12, h: 38, d: 11, c: "#485060", wc: "#688898" },
          { x: -260, z: -240, w: 18, h: 30, d: 15, c: "#404858", wc: "#6088a8" },
          { x: -310, z: -240, w: 16, h: 26, d: 14, c: "#485060", wc: "#6888a0" },
          { x: -350, z: -225, w: 10, h: 22, d: 10, c: "#404858", wc: "#607890" },
        ].map((b, i) => <Building key={`pg${i}`} {...b} />)}

        {/* Docklands */}
        <mesh position={[-280, 0.1, -170]}>
          <boxGeometry args={[120, 0.2, 30]} />
          <meshLambertMaterial color="#555" />
        </mesh>
        {/* Dock water */}
        <mesh position={[-280, -0.5, -145]}>
          <boxGeometry args={[140, 1, 50]} />
          <meshLambertMaterial color="#1a3a5a" transparent opacity={0.82} />
        </mesh>
        {/* Cranes */}
        {[[-260, -155], [-295, -155], [-330, -155]].map(([cx, cz], i) => (
          <group key={i} position={[cx, 0, cz]}>
            <mesh position={[0, 15, 0]}><boxGeometry args={[1.5, 30, 1.5]} /><meshLambertMaterial color="#cc8822" /></mesh>
            <mesh position={[8, 29, 0]}><boxGeometry args={[18, 1, 1]} /><meshLambertMaterial color="#cc8822" /></mesh>
            <mesh position={[16, 28, 0]}><boxGeometry args={[0.5, 3, 0.5]} /><meshLambertMaterial color="#999" /></mesh>
            <pointLight color="#ff8800" intensity={1.5} distance={18} position={[0, 32, 0]} />
          </group>
        ))}
        {/* Container stacks */}
        {[
          [-270, -170, "#cc2200"], [-265, -170, "#2244cc"],
          [-290, -170, "#22aa22"], [-285, -170, "#cc8800"],
          [-310, -170, "#aa2288"],
        ].map(([cx, cz, col], i) => (
          <mesh key={i} position={[cx as number, 2.5, cz as number]} castShadow>
            <boxGeometry args={[8, 5, 4]} />
            <meshLambertMaterial color={col as string} />
          </mesh>
        ))}
        {/* Oil refinery tanks */}
        {[[-350, -250], [-365, -250], [-350, -270], [-365, -270]].map(([tx, tz], i) => (
          <group key={i} position={[tx, 0, tz]}>
            <mesh position={[0, 8, 0]} castShadow><cylinderGeometry args={[7, 7, 16, 12]} /><meshLambertMaterial color="#888878" /></mesh>
            <mesh position={[0, 16.5, 0]}><cylinderGeometry args={[7.2, 6, 2, 12]} /><meshLambertMaterial color="#777767" /></mesh>
          </group>
        ))}
        {/* Refinery chimneys */}
        {[[-355, -235], [-368, -240], [-340, -238]].map(([tx, tz], i) => (
          <group key={i} position={[tx, 0, tz]}>
            <mesh position={[0, 22, 0]}><cylinderGeometry args={[1.5, 2.2, 44, 8]} /><meshLambertMaterial color="#666" /></mesh>
            <mesh position={[0, 45, 0]}><cylinderGeometry args={[2.0, 1.5, 2, 8]} /><meshLambertMaterial color="#555" /></mesh>
            <pointLight color="#ff6600" intensity={2} distance={22} position={[0, 46, 0]} />
          </group>
        ))}
        {/* Port Gellhorn roads */}
        <Road x={-310} z={-220} l={220} w={14} />
        <Road x={-305} z={-205} l={220} w={10} r={Math.PI / 2} />
        <Road x={-305} z={-250} l={220} w={10} r={Math.PI / 2} />
      </group>
    </CulledGroup>
  );
}

// ─── Lake Leonida ──────────────────────────────────────────────────────────────
function LakeLeonida() {
  return (
    <CulledGroup cx={0} cz={-280} r={350}>
      <group>
        {/* Lake water */}
        <mesh position={[0, -0.8, -280]}>
          <boxGeometry args={[240, 1.5, 190]} />
          <meshLambertMaterial color="#1a5a8a" transparent opacity={0.82} />
        </mesh>
        {/* Surface shimmer */}
        <mesh position={[0, 0.0, -280]}>
          <boxGeometry args={[240, 0.04, 190]} />
          <meshLambertMaterial color="#3a8ab8" transparent opacity={0.4} />
        </mesh>
        {/* Beach around lake */}
        <mesh position={[0, -0.05, -280]} receiveShadow>
          <boxGeometry args={[260, 0.1, 210]} />
          <meshLambertMaterial color="#c8b880" />
        </mesh>
        {/* Surrounding land */}
        <mesh position={[0, -0.12, -280]} receiveShadow>
          <boxGeometry args={[290, 0.1, 240]} />
          <meshLambertMaterial color="#3a5a2a" />
        </mesh>
        {/* Boat docks */}
        {[[-80, -300], [0, -190], [80, -300]].map(([dx, dz], i) => (
          <group key={i} position={[dx, 0, dz]}>
            <mesh position={[0, 0.15, 0]}><boxGeometry args={[4, 0.25, 20]} /><meshLambertMaterial color="#9a7a5a" /></mesh>
            {/* Speed boat */}
            <group position={[0, 0.4, 6]}>
              <mesh><boxGeometry args={[2.2, 0.7, 5.5]} /><meshLambertMaterial color={["#cc2200", "#2244cc", "#22aa44"][i]} /></mesh>
              <mesh position={[0, 0.5, -1]}><boxGeometry args={[1.8, 0.5, 2.5]} /><meshLambertMaterial color="#f0f0f0" /></mesh>
              <mesh position={[0, 0.3, 2.9]}><boxGeometry args={[1.5, 0.18, 0.2]} /><meshLambertMaterial color="#fff" /></mesh>
            </group>
          </group>
        ))}
        {/* Lake-side trees */}
        {[
          [-120, -220], [-100, -210], [-90, -200], [100, -215], [115, -205],
          [-115, -340], [-100, -355], [90, -345], [110, -338],
        ].map(([tx, tz], i) => (
          <group key={i} position={[tx, 0, tz]}>
            <mesh position={[0, 4, 0]}><cylinderGeometry args={[0.18, 0.26, 8, 6]} /><meshLambertMaterial color="#4a3010" /></mesh>
            <mesh position={[0, 8.5, 0]}><coneGeometry args={[3, 6, 7]} /><meshLambertMaterial color="#1a5a1a" /></mesh>
            <mesh position={[0, 6, 0]}><coneGeometry args={[4, 4, 7]} /><meshLambertMaterial color="#1e6a1e" /></mesh>
          </group>
        ))}
        {/* Fishing village */}
        <Building x={-85} z={-340} w={7} h={10} d={6} c="#d0b888" wc="#f0d8a8" />
        <Building x={-72} z={-335} w={6} h={8} d={5} c="#c8b080" />
        <Building x={95} z={-338} w={7} h={10} d={6} c="#c8b888" />
      </group>
    </CulledGroup>
  );
}

// ─── Mount Caliga ─────────────────────────────────────────────────────────────
function MountCaliga() {
  return (
    <CulledGroup cx={0} cz={-510} r={450}>
      <group>
        {/* Mountain base terrain */}
        <mesh position={[0, -0.1, -510]} receiveShadow>
          <boxGeometry args={[500, 0.2, 240]} />
          <meshLambertMaterial color="#4a5a3a" />
        </mesh>

        {/* Main peak */}
        <mesh position={[0, 0, -490]}>
          <coneGeometry args={[130, 280, 7]} />
          <meshLambertMaterial color="#5a6a5a" />
        </mesh>
        {/* Snow cap */}
        <mesh position={[0, 120, -490]}>
          <coneGeometry args={[28, 50, 7]} />
          <meshLambertMaterial color="#f0f8ff" />
        </mesh>
        <mesh position={[0, 108, -490]}>
          <coneGeometry args={[38, 30, 7]} />
          <meshLambertMaterial color="#e8f0f8" transparent opacity={0.8} />
        </mesh>

        {/* Secondary peaks */}
        <mesh position={[110, 0, -510]}>
          <coneGeometry args={[90, 200, 6]} />
          <meshLambertMaterial color="#606a58" />
        </mesh>
        <mesh position={[110, 82, -510]}>
          <coneGeometry args={[20, 38, 6]} />
          <meshLambertMaterial color="#eef8ff" />
        </mesh>
        <mesh position={[-120, 0, -500]}>
          <coneGeometry args={[100, 220, 6]} />
          <meshLambertMaterial color="#506050" />
        </mesh>
        <mesh position={[-120, 92, -500]}>
          <coneGeometry args={[22, 40, 6]} />
          <meshLambertMaterial color="#eef6ff" />
        </mesh>
        <mesh position={[200, 0, -520]}>
          <coneGeometry args={[70, 140, 5]} />
          <meshLambertMaterial color="#5a6a50" />
        </mesh>
        <mesh position={[-200, 0, -515]}>
          <coneGeometry args={[75, 150, 5]} />
          <meshLambertMaterial color="#506050" />
        </mesh>

        {/* Forest belt at base */}
        {Array.from({ length: 28 }, (_, i) => {
          const angle = (i / 28) * Math.PI * 1.4 - 0.3;
          const r = 140 + (i % 4) * 20;
          const tx = Math.sin(angle) * r;
          const tz = -490 + Math.cos(angle) * r * 0.7;
          const th = 8 + (i % 5) * 2.5;
          return (
            <group key={i} position={[tx, 0, tz]}>
              <mesh position={[0, th / 2, 0]}><cylinderGeometry args={[0.22, 0.32, th, 5]} /><meshLambertMaterial color="#3a2810" /></mesh>
              <mesh position={[0, th + 1.5, 0]}><coneGeometry args={[th * 0.38, th * 0.75, 6]} /><meshLambertMaterial color="#1a4a1a" /></mesh>
              <mesh position={[0, th - 0.5, 0]}><coneGeometry args={[th * 0.48, th * 0.5, 6]} /><meshLambertMaterial color="#1e581e" /></mesh>
            </group>
          );
        })}

        {/* National Park ranger station */}
        <Building x={50} z={-380} w={10} h={8} d={8} c="#9a8868" wc="#c8b898" />
        <Building x={-45} z={-375} w={8} h={7} d={7} c="#887858" />
        {/* Cable car station */}
        <group position={[0, 0, -390]}>
          <mesh position={[0, 5.5, 0]}><boxGeometry args={[12, 11, 9]} /><meshLambertMaterial color="#8898a8" /></mesh>
          <mesh position={[0, 12, 0]}><boxGeometry args={[12.4, 1, 9.4]} /><meshLambertMaterial color="#6878a8" /></mesh>
          <mesh position={[0, 14, 0]}><boxGeometry args={[7, 2, 0.2]} /><meshLambertMaterial color="#446699" emissive="#224488" emissiveIntensity={0.4} /></mesh>
          <pointLight color="#4488ff" intensity={3} distance={25} position={[0, 15, 2]} />
        </group>
        {/* Cable car wire to peak */}
        <mesh position={[0, 80, -440]} rotation={[0.9, 0, 0]}>
          <cylinderGeometry args={[0.1, 0.1, 200, 4]} />
          <meshLambertMaterial color="#888" />
        </mesh>
      </group>
    </CulledGroup>
  );
}

// ─── Roads (Leonida highway network) ─────────────────────────────────────────
function Roads() {
  return (
    <group>
      {/* VC Main spine N-S and E-W */}
      <Road x={120} z={-100} l={700} w={18} r={Math.PI / 2} />
      <Road x={0}   z={0}    l={600} w={16} />
      <Road x={0}   z={70}   l={600} w={12} />
      <Road x={0}   z={-70}  l={600} w={12} />
      <Road x={200} z={-100} l={700} w={14} r={Math.PI / 2} />
      <Road x={60}  z={-100} l={700} w={11} r={Math.PI / 2} />
      <Road x={-60} z={-100} l={700} w={11} r={Math.PI / 2} />
      {/* Beach drive */}
      <Road x={265} z={70}   l={300} w={12} r={Math.PI / 2} />
      {/* Keys bridge approach */}
      <Road x={140} z={200}  l={130} w={12} r={Math.PI / 2} />
      {/* Grassrivers access */}
      <Road x={-100} z={60}  l={280} w={10} />
      <Road x={-150} z={30}  l={220} w={9}  r={Math.PI / 2} />
      {/* Port Gellhorn highway */}
      <Road x={-200} z={-120} l={350} w={16} />
      <Road x={-200} z={-130} l={280} w={12} r={Math.PI / 2} />
      {/* Mt Caliga approach */}
      <Road x={0}    z={-320} l={450} w={14} r={Math.PI / 2} />
      <Road x={0}    z={-200} l={300} w={12} />
      {/* Lake Leonida loop road */}
      <Road x={0}    z={-260} l={250} w={10} />
      <Road x={-110} z={-280} l={70}  w={10} r={Math.PI / 2} />
      <Road x={110}  z={-280} l={70}  w={10} r={Math.PI / 2} />
      {/* VC diagonal / expressway */}
      <Road x={140}  z={-80}  l={380} w={16} r={Math.PI * 0.08} />
      {/* Little Havana */}
      <Road x={-30}  z={30}   l={220} w={10} />
      <Road x={-30}  z={80}   l={220} w={10} />
    </group>
  );
}

// ─── Street Lamps network ─────────────────────────────────────────────────────
function Lamps() {
  const positions: [number, number, boolean][] = [
    [8, 28, false], [-8, 28, false], [8, -28, false], [-8, -28, false],
    [8, 70, false], [-8, 70, false], [8, -70, false], [-8, -70, false],
    [68, 8, false], [68, -8, false], [-68, 8, false], [-68, -8, false],
    [8, 140, false], [-8, 140, false], [8, -140, false], [-8, -140, false],
    [140, 8, false], [140, -8, false], [-140, 8, false], [-140, -8, false],
    // Neon beach lamps
    [270, -40, true], [270, -20, true], [270, 0, true], [270, 20, true],
    [270, 40, true], [270, 60, true], [270, 80, true], [270, 100, true],
    [270, 120, true], [270, 140, true], [270, 160, true],
    // Port Gellhorn
    [-260, -200, false], [-285, -200, false], [-310, -200, false],
    [-260, -235, false], [-285, -235, false], [-310, -235, false],
    // Keys approach
    [130, 200, false], [150, 200, false],
  ];
  return (
    <group>
      {positions.map(([x, z, neon], i) => <Lamp key={i} x={x} z={z} neon={neon} />)}
    </group>
  );
}

// ─── Palm Trees ───────────────────────────────────────────────────────────────
function Palms() {
  const positions = [
    [260, -20], [262, 20], [260, 60], [263, 100], [261, 140],
    [260, -60], [263, -100], [260, 180], [263, -140],
    [210, -10], [215, 50], [208, 100],
    [-50, 40], [-70, 60], [-90, 50], [-110, 40],
    [30, 100], [50, 110], [70, 90],
    [130, 240], [145, 255], [125, 260],
  ];
  return (
    <group>
      {positions.map(([x, z], i) => <PalmTree key={i} x={x} z={z} />)}
    </group>
  );
}

// ─── Main World ───────────────────────────────────────────────────────────────
export default function World() {
  return (
    <group>
      {/* ── Main ground plane — Leonida ── */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
        <planeGeometry args={[2400, 2400]} />
        <meshLambertMaterial color="#3a4a2a" />
      </mesh>

      {/* ── Roads ── */}
      <Roads />

      {/* ── Sidewalks ── */}
      <mesh position={[0, 0.05, 9.2]} receiveShadow><boxGeometry args={[600, 0.1, 1.4]} /><meshLambertMaterial color="#888" /></mesh>
      <mesh position={[0, 0.05, -9.2]} receiveShadow><boxGeometry args={[600, 0.1, 1.4]} /><meshLambertMaterial color="#888" /></mesh>
      <mesh position={[9.2, 0.05, 0]} receiveShadow rotation={[0, Math.PI / 2, 0]}><boxGeometry args={[700, 0.1, 1.4]} /><meshLambertMaterial color="#888" /></mesh>
      <mesh position={[-9.2, 0.05, 0]} receiveShadow rotation={[0, Math.PI / 2, 0]}><boxGeometry args={[700, 0.1, 1.4]} /><meshLambertMaterial color="#888" /></mesh>

      {/* ── Regions ── */}
      <ViceCity />
      <OceanDrive />
      <NightclubStrip />
      <ViceCityPD />
      <ViceMall />
      <LeonidaKeys />
      <Grassrivers />
      <PortGellhorn />
      <LakeLeonida />
      <MountCaliga />

      {/* ── Street furniture ── */}
      <Lamps />
      <Palms />

      {/* ── Parks ── */}
      <mesh position={[40, 0.02, -80]} receiveShadow><boxGeometry args={[38, 0.04, 26]} /><meshLambertMaterial color="#2a5a1a" /></mesh>
      <mesh position={[-60, 0.02, 100]} receiveShadow><boxGeometry args={[32, 0.04, 28]} /><meshLambertMaterial color="#2a6a1a" /></mesh>

      {/* ── Parking lots ── */}
      <mesh position={[170, 0.01, 40]} receiveShadow><boxGeometry args={[40, 0.02, 26]} /><meshLambertMaterial color="#282828" /></mesh>
      <mesh position={[50, 0.01, 55]} receiveShadow><boxGeometry args={[28, 0.02, 22]} /><meshLambertMaterial color="#282828" /></mesh>

      {/* ── Elevated highway / overpass ── */}
      <mesh position={[120, 5, 0]}><boxGeometry args={[10, 0.55, 450]} /><meshLambertMaterial color="#666" /></mesh>
      <mesh position={[0, 5, -70]} rotation={[0, Math.PI / 2, 0]}><boxGeometry args={[10, 0.55, 450]} /><meshLambertMaterial color="#666" /></mesh>
      {/* Overpass pillars */}
      {Array.from({ length: 8 }, (_, i) => (
        <mesh key={i} position={[120, 2.5, -160 + i * 50]}>
          <boxGeometry args={[1.5, 5, 1.5]} />
          <meshLambertMaterial color="#888" />
        </mesh>
      ))}

      {/* ── VC Airport ── */}
      <CulledGroup cx={150} cz={150} r={300}>
        <group position={[150, 0, 150]}>
          <mesh receiveShadow><boxGeometry args={[30, 0.04, 200]} /><meshLambertMaterial color="#1a1a1a" /></mesh>
          <mesh position={[50, 0.02, 0]} rotation={[0, 0.15, 0]}><boxGeometry args={[25, 0.04, 180]} /><meshLambertMaterial color="#1a1a1a" /></mesh>
          <mesh position={[-40, 9, 0]} castShadow><boxGeometry args={[40, 18, 30]} /><meshLambertMaterial color="#b0c0d0" /></mesh>
          <mesh position={[-40, 18.5, 0]}><boxGeometry args={[40.4, 1, 30.4]} /><meshLambertMaterial color="#8090a0" /></mesh>
          <mesh position={[-65, 18, 0]}><cylinderGeometry args={[1.4, 2, 36, 8]} /><meshLambertMaterial color="#90a0b0" /></mesh>
          <pointLight color="#ff4400" intensity={2.5} distance={22} position={[-65, 36, 0]} />
          {[0, 60, -60].map((oz, i) => (
            <mesh key={i} position={[40, 5.5, oz]} castShadow><boxGeometry args={[26, 11, 28]} /><meshLambertMaterial color="#888890" /></mesh>
          ))}
          {/* Runway markings */}
          {Array.from({ length: 10 }, (_, i) => (
            <mesh key={i} position={[0, 0.03, -80 + i * 18]}>
              <boxGeometry args={[0.5, 0.01, 8]} />
              <meshLambertMaterial color="#eeee00" />
            </mesh>
          ))}
        </group>
      </CulledGroup>

      {/* ── VC Hospital ── */}
      <CulledGroup cx={30} cz={-50} r={150}>
        <group position={[30, 0, -50]}>
          <mesh position={[0, 10, 0]} castShadow><boxGeometry args={[24, 20, 18]} /><meshLambertMaterial color="#f5f5f5" /></mesh>
          <mesh position={[-18, 7, 0]} castShadow><boxGeometry args={[12, 14, 14]} /><meshLambertMaterial color="#eeeeee" /></mesh>
          <mesh position={[0, 21, 0]}><boxGeometry args={[24.4, 1, 18.4]} /><meshLambertMaterial color="#ddd" /></mesh>
          <mesh position={[0, 12, 9.1]}><boxGeometry args={[2.2, 7, 0.12]} /><meshLambertMaterial color="#dd2222" emissive="#cc0000" emissiveIntensity={0.6} /></mesh>
          <mesh position={[0, 12, 9.1]}><boxGeometry args={[7, 2.2, 0.14]} /><meshLambertMaterial color="#dd2222" emissive="#cc0000" emissiveIntensity={0.6} /></mesh>
          <pointLight color="#ff3333" intensity={3} distance={24} position={[0, 14, 10]} />
        </group>
      </CulledGroup>

      {/* ── Helipad on top of Maze Bank ── */}
      <group position={[120, 101, -30]}>
        <mesh><cylinderGeometry args={[7, 7, 0.3, 20]} /><meshLambertMaterial color="#1a1a1a" /></mesh>
        <mesh><cylinderGeometry args={[6.5, 6.5, 0.02, 20]} /><meshLambertMaterial color="#ffcc00" transparent opacity={0.7} /></mesh>
        <mesh><boxGeometry args={[1.2, 0.02, 7]} /><meshLambertMaterial color="#ffcc00" /></mesh>
        <mesh><boxGeometry args={[7, 0.02, 1.2]} /><meshLambertMaterial color="#ffcc00" /></mesh>
        <pointLight color="#ffcc00" intensity={2} distance={12} position={[0, 1, 0]} />
      </group>

      {/* ── Vinewood-style sign (now LEONIDA) ── */}
      <CulledGroup cx={-180} cz={-180} r={400}>
        <group position={[-180, 0, -180]}>
          <mesh position={[0, 10, 0]}><boxGeometry args={[80, 20, 12]} /><meshLambertMaterial color="#4a6a3a" /></mesh>
          {"LEONIDA".split("").map((l, i) => (
            <group key={i} position={[-36 + i * 10, 28, 0]}>
              <mesh castShadow><boxGeometry args={[6, 12, 1]} /><meshLambertMaterial color="#f0f0f0" /></mesh>
              <mesh position={[0, -7, 0]}><cylinderGeometry args={[0.2, 0.2, 4, 5]} /><meshLambertMaterial color="#888" /></mesh>
            </group>
          ))}
        </group>
      </CulledGroup>
    </group>
  );
}
