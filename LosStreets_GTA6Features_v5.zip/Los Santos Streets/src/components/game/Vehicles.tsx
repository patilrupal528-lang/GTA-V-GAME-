import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { GameState } from "./types";
import { playerWorldPos } from "./Player";
import { resolveCollision } from "../../utils/buildingCollisions";

interface Props {
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  gameState: GameState;
}

type VehicleType = "sedan" | "suv" | "sports" | "super" | "muscle" | "classic" | "bike" | "armored";
type VehicleCategory = "Super" | "Sports" | "Muscle" | "Classics" | "SUV" | "Sedan";

interface VehicleDef {
  id: number;
  name: string;
  category: VehicleCategory;
  startX: number;
  startZ: number;
  color: string;
  bodyColor: string;
  type: VehicleType;
  rotation?: number;
  topSpeed?: number;
}

const VEHICLE_DEFS: VehicleDef[] = [
  // Super
  { id: 0,  name: "Adder",          category: "Super",   startX: 15,  startZ: 8,   color: "#f5e642", bodyColor: "#d4c820", type: "super",   topSpeed: 250 },
  { id: 1,  name: "Zentorno",       category: "Super",   startX: 25,  startZ: 8,   color: "#1a1a1a", bodyColor: "#cc1100", type: "super",   topSpeed: 245 },
  { id: 2,  name: "Osiris",         category: "Super",   startX: 35,  startZ: 8,   color: "#f0f0f0", bodyColor: "#d0d0d0", type: "super",   topSpeed: 240 },
  { id: 3,  name: "T20",            category: "Super",   startX: 45,  startZ: 8,   color: "#cc1100", bodyColor: "#aa0000", type: "super",   topSpeed: 235 },
  { id: 4,  name: "Entity XF",      category: "Super",   startX: 55,  startZ: 8,   color: "#e87700", bodyColor: "#c06000", type: "super",   topSpeed: 230 },
  { id: 5,  name: "Turismo R",      category: "Super",   startX: 65,  startZ: 8,   color: "#f0cc00", bodyColor: "#ccaa00", type: "super",   topSpeed: 228 },
  { id: 6,  name: "Cheetah",        category: "Super",   startX: 75,  startZ: 8,   color: "#f0d020", bodyColor: "#ccaa00", type: "super",   topSpeed: 220 },
  { id: 7,  name: "Infernus",       category: "Super",   startX: 85,  startZ: 8,   color: "#cc2200", bodyColor: "#aa1100", type: "super",   topSpeed: 215 },
  { id: 8,  name: "Vagner",         category: "Super",   startX: 95,  startZ: 8,   color: "#007788", bodyColor: "#005566", type: "super",   topSpeed: 246 },
  { id: 9,  name: "Krieger",        category: "Super",   startX: 105, startZ: 8,   color: "#1a4a1a", bodyColor: "#0a3a0a", type: "super",   topSpeed: 244 },
  { id: 10, name: "Emerus",         category: "Super",   startX: 115, startZ: 8,   color: "#5a0088", bodyColor: "#440066", type: "super",   topSpeed: 243 },
  // Sports
  { id: 11, name: "Elegy RH8",      category: "Sports",  startX: -15, startZ: 8,   color: "#111111", bodyColor: "#222222", type: "sports",  topSpeed: 185 },
  { id: 12, name: "Jester",         category: "Sports",  startX: -25, startZ: 8,   color: "#cc2200", bodyColor: "#aa1100", type: "sports",  topSpeed: 178 },
  { id: 13, name: "Massacro",       category: "Sports",  startX: -35, startZ: 8,   color: "#1a3a6a", bodyColor: "#0a2a5a", type: "sports",  topSpeed: 175 },
  { id: 14, name: "Banshee",        category: "Sports",  startX: -45, startZ: 8,   color: "#f5c020", bodyColor: "#1a1a1a", type: "sports",  topSpeed: 180 },
  { id: 15, name: "9F",             category: "Sports",  startX: -55, startZ: 8,   color: "#f0f0f0", bodyColor: "#d0d0d0", type: "sports",  topSpeed: 172 },
  { id: 16, name: "Carbonizzare",   category: "Sports",  startX: -65, startZ: 8,   color: "#667788", bodyColor: "#445566", type: "sports",  topSpeed: 170 },
  { id: 17, name: "Comet",          category: "Sports",  startX: -75, startZ: 8,   color: "#cccccc", bodyColor: "#aaaaaa", type: "sports",  topSpeed: 168 },
  { id: 18, name: "Feltzer",        category: "Sports",  startX: -85, startZ: 8,   color: "#2244aa", bodyColor: "#1133aa", type: "sports",  topSpeed: 165 },
  { id: 19, name: "Futo",           category: "Sports",  startX: -95, startZ: 8,   color: "#22aa22", bodyColor: "#118811", type: "sports",  topSpeed: 160 },
  { id: 20, name: "Kuruma (APB)",   category: "Sports",  startX: -105,startZ: 8,   color: "#1a1a1a", bodyColor: "#0a0a0a", type: "armored", topSpeed: 162 },
  { id: 21, name: "Itali RSX",      category: "Sports",  startX: -115,startZ: 8,   color: "#cc0022", bodyColor: "#aa0011", type: "sports",  topSpeed: 188 },
  // Muscle
  { id: 22, name: "Dominator",      category: "Muscle",  startX: 15,  startZ: -15, color: "#cc5500", bodyColor: "#aa4400", type: "muscle" },
  { id: 23, name: "Gauntlet",       category: "Muscle",  startX: 25,  startZ: -15, color: "#1a1a1a", bodyColor: "#111111", type: "muscle" },
  { id: 24, name: "Dukes",          category: "Muscle",  startX: 35,  startZ: -15, color: "#aa1100", bodyColor: "#881100", type: "muscle" },
  { id: 25, name: "Sabre Turbo",    category: "Muscle",  startX: 45,  startZ: -15, color: "#cccc00", bodyColor: "#1a1a1a", type: "muscle" },
  { id: 26, name: "Ruiner",         category: "Muscle",  startX: 55,  startZ: -15, color: "#666666", bodyColor: "#444444", type: "muscle" },
  { id: 27, name: "Phoenix",        category: "Muscle",  startX: 65,  startZ: -15, color: "#cc2200", bodyColor: "#aa1100", type: "muscle" },
  { id: 28, name: "Duke O'Death",   category: "Muscle",  startX: 75,  startZ: -15, color: "#111111", bodyColor: "#222222", type: "armored" },
  { id: 29, name: "Blade",          category: "Muscle",  startX: 85,  startZ: -15, color: "#ccaa00", bodyColor: "#aa8800", type: "muscle" },
  { id: 30, name: "Stallion",       category: "Muscle",  startX: 95,  startZ: -15, color: "#2244aa", bodyColor: "#1133aa", type: "muscle" },
  // Classics
  { id: 31, name: "JB 700",         category: "Classics",startX: -15, startZ: -15, color: "#aaaaaa", bodyColor: "#888888", type: "classic" },
  { id: 32, name: "Z-Type",         category: "Classics",startX: -25, startZ: -15, color: "#ccaa44", bodyColor: "#aa8822", type: "classic" },
  { id: 33, name: "Monroe",         category: "Classics",startX: -35, startZ: -15, color: "#f0f0f0", bodyColor: "#d0d0d0", type: "classic" },
  { id: 34, name: "Stinger",        category: "Classics",startX: -45, startZ: -15, color: "#228844", bodyColor: "#116633", type: "classic" },
  { id: 35, name: "Coquette Classic",category:"Classics",startX: -55, startZ: -15, color: "#cc2200", bodyColor: "#aa1100", type: "classic" },
  { id: 36, name: "Tornado",        category: "Classics",startX: -65, startZ: -15, color: "#44aacc", bodyColor: "#228899", type: "classic" },
  { id: 37, name: "Peyote",         category: "Classics",startX: -75, startZ: -15, color: "#f0cc20", bodyColor: "#ccaa00", type: "classic" },
  { id: 38, name: "Deluxo",         category: "Classics",startX: -85, startZ: -15, color: "#cccccc", bodyColor: "#aaaaaa", type: "classic" },
  // SUVs
  { id: 39, name: "Baller",         category: "SUV",     startX: 15,  startZ: 70,  color: "#1a1a1a", bodyColor: "#111111", type: "suv" },
  { id: 40, name: "Granger",        category: "SUV",     startX: 25,  startZ: 70,  color: "#222222", bodyColor: "#111111", type: "suv" },
  { id: 41, name: "Dubsta",         category: "SUV",     startX: 35,  startZ: 70,  color: "#f0f0f0", bodyColor: "#d0d0d0", type: "suv" },
  { id: 42, name: "Cavalcade",      category: "SUV",     startX: 45,  startZ: 70,  color: "#dddddd", bodyColor: "#bbbbbb", type: "suv" },
  { id: 43, name: "Sandking XL",    category: "SUV",     startX: 55,  startZ: 70,  color: "#cc8822", bodyColor: "#aa6600", type: "suv" },
  { id: 44, name: "Insurgent",      category: "SUV",     startX: 65,  startZ: 70,  color: "#2a3a1a", bodyColor: "#1a2a0a", type: "armored" },
  { id: 45, name: "Bodhi",          category: "SUV",     startX: 75,  startZ: 70,  color: "#887755", bodyColor: "#665533", type: "suv" },
  { id: 46, name: "Bifta",          category: "SUV",     startX: 85,  startZ: 70,  color: "#ccaa44", bodyColor: "#aa8822", type: "suv" },
  { id: 47, name: "Freecrawler",    category: "SUV",     startX: 95,  startZ: 70,  color: "#448844", bodyColor: "#336633", type: "suv" },
  // Sedans
  { id: 48, name: "Tailgater",      category: "Sedan",   startX: -15, startZ: 70,  color: "#336699", bodyColor: "#224477", type: "sedan" },
  { id: 49, name: "Buffalo S",      category: "Sedan",   startX: -25, startZ: 70,  color: "#111111", bodyColor: "#222222", type: "sedan" },
  { id: 50, name: "Oracle",         category: "Sedan",   startX: -35, startZ: 70,  color: "#f0f0f0", bodyColor: "#dddddd", type: "sedan" },
  { id: 51, name: "Felon",          category: "Sedan",   startX: -45, startZ: 70,  color: "#1a1a1a", bodyColor: "#111111", type: "sedan" },
  { id: 52, name: "Zion",           category: "Sedan",   startX: -55, startZ: 70,  color: "#224422", bodyColor: "#113311", type: "sedan" },
  { id: 53, name: "Sentinel",       category: "Sedan",   startX: -65, startZ: 70,  color: "#eeeeee", bodyColor: "#cccccc", type: "sedan" },
  { id: 54, name: "Jackal",         category: "Sedan",   startX: -75, startZ: 70,  color: "#668899", bodyColor: "#446677", type: "sedan" },
];

export const CAT_COLORS: Record<string, string> = {
  Super: "#ff6600", Sports: "#0088ff", Muscle: "#ff2244",
  Classics: "#ffcc00", SUV: "#44aa44", Sedan: "#888888",
};

function VehicleMesh({ color, bodyColor, type }: { color: string; bodyColor: string; type: VehicleType }) {
  const isSuper   = type === "super";
  const isSUV     = type === "suv";
  const isMuscle  = type === "muscle";
  const isArmored = type === "armored";
  const isClassic = type === "classic";
  const isSports  = type === "sports";

  const hw = isSUV ? 2.5 : isArmored ? 2.6 : isSuper ? 2.0 : isMuscle ? 2.4 : isClassic ? 2.1 : 2.2;
  const hh = isSUV ? 1.1 : isArmored ? 1.2 : isSuper ? 0.45 : isMuscle ? 0.72 : isClassic ? 0.78 : 0.72;
  const hd = isSUV ? 5.2 : isArmored ? 5.5 : isSuper ? 4.6 : isMuscle ? 5.0 : isClassic ? 4.9 : 4.5;
  const wheelR = isSUV || isArmored ? 0.5 : isSuper ? 0.35 : 0.42;
  const cabH = isSuper ? 0.35 : isClassic ? 0.72 : isMuscle ? 0.58 : isSUV ? 0.75 : 0.62;

  const wheels: [number, number, number][] = [
    [-(hw / 2 + 0.06), -hh / 2 + 0.22, hd / 2 - 1.3],
    [ hw / 2 + 0.06,  -hh / 2 + 0.22, hd / 2 - 1.3],
    [-(hw / 2 + 0.06), -hh / 2 + 0.22, -(hd / 2 - 1.3)],
    [ hw / 2 + 0.06,  -hh / 2 + 0.22, -(hd / 2 - 1.3)],
  ];

  return (
    <>
      {/* Main body */}
      <mesh position={[0, hh / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[hw, hh, hd]} />
        <meshLambertMaterial color={color} />
      </mesh>

      {/* Cabin / roof */}
      <mesh position={[0, hh + cabH / 2, isClassic ? 0 : -0.2]} castShadow>
        <boxGeometry args={[hw - 0.24, cabH, isClassic ? hd * 0.56 : hd * 0.47]} />
        <meshLambertMaterial color={bodyColor} />
      </mesh>

      {/* Windshield front */}
      <mesh position={[0, hh + cabH * 0.5, hd * 0.24]}>
        <boxGeometry args={[hw - 0.34, cabH * 0.84, 0.06]} />
        <meshLambertMaterial color="#88ccff" transparent opacity={0.55} />
      </mesh>

      {/* Windshield back */}
      <mesh position={[0, hh + cabH * 0.5, -(hd * 0.29)]}>
        <boxGeometry args={[hw - 0.34, cabH * 0.84, 0.06]} />
        <meshLambertMaterial color="#88ccff" transparent opacity={0.45} />
      </mesh>

      {/* Side windows (doors) */}
      <mesh position={[hw / 2 + 0.01, hh + cabH * 0.52, 0]}>
        <boxGeometry args={[0.04, cabH * 0.72, hd * 0.38]} />
        <meshLambertMaterial color="#88ccff" transparent opacity={0.4} />
      </mesh>
      <mesh position={[-(hw / 2 + 0.01), hh + cabH * 0.52, 0]}>
        <boxGeometry args={[0.04, cabH * 0.72, hd * 0.38]} />
        <meshLambertMaterial color="#88ccff" transparent opacity={0.4} />
      </mesh>

      {/* Door panels */}
      <mesh position={[hw / 2 + 0.02, hh * 0.5, 0]}>
        <boxGeometry args={[0.04, hh * 0.7, hd * 0.38]} />
        <meshLambertMaterial color={bodyColor} />
      </mesh>
      <mesh position={[-(hw / 2 + 0.02), hh * 0.5, 0]}>
        <boxGeometry args={[0.04, hh * 0.7, hd * 0.38]} />
        <meshLambertMaterial color={bodyColor} />
      </mesh>

      {/* Wheels */}
      {wheels.map(([wx, wy, wz], i) => (
        <mesh key={i} position={[wx, wy, wz]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[wheelR, wheelR, 0.32, 12]} />
          <meshLambertMaterial color="#111" />
        </mesh>
      ))}
      {/* Wheel rims */}
      {wheels.map(([wx, wy, wz], i) => (
        <mesh key={`h${i}`} position={[wx > 0 ? wx + 0.18 : wx - 0.18, wy, wz]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[wheelR * 0.6, wheelR * 0.6, 0.06, 8]} />
          <meshLambertMaterial color={isSuper ? "#cccccc" : "#888"} />
        </mesh>
      ))}
      {/* Wheel arch bumps */}
      {wheels.map(([wx, wy, wz], i) => (
        <mesh key={`arch${i}`} position={[wx > 0 ? hw / 2 + 0.02 : -(hw / 2 + 0.02), wy + wheelR * 0.6, wz]}>
          <boxGeometry args={[0.06, wheelR * 0.5, wheelR * 2.2]} />
          <meshLambertMaterial color={color} />
        </mesh>
      ))}

      {/* Headlights — split dual */}
      <mesh position={[-(hw / 2 - 0.55), hh * 0.58, hd / 2 + 0.03]}>
        <boxGeometry args={[0.55, 0.18, 0.05]} />
        <meshLambertMaterial color="#fff" emissive="#ffffa0" emissiveIntensity={0.8} />
      </mesh>
      <mesh position={[hw / 2 - 0.55, hh * 0.58, hd / 2 + 0.03]}>
        <boxGeometry args={[0.55, 0.18, 0.05]} />
        <meshLambertMaterial color="#fff" emissive="#ffffa0" emissiveIntensity={0.8} />
      </mesh>

      {/* Taillights */}
      <mesh position={[0, hh * 0.58, -(hd / 2 + 0.03)]}>
        <boxGeometry args={[hw - 0.28, 0.22, 0.05]} />
        <meshLambertMaterial color="#ff1111" emissive="#ff0000" emissiveIntensity={1.0} />
      </mesh>

      {/* Front bumper */}
      <mesh position={[0, hh * 0.25, hd / 2 + 0.05]}>
        <boxGeometry args={[hw - 0.1, hh * 0.22, 0.12]} />
        <meshLambertMaterial color={isSuper ? "#111" : bodyColor} />
      </mesh>

      {/* Rear bumper */}
      <mesh position={[0, hh * 0.25, -(hd / 2 + 0.05)]}>
        <boxGeometry args={[hw - 0.1, hh * 0.22, 0.12]} />
        <meshLambertMaterial color={bodyColor} />
      </mesh>

      {/* Rear spoiler for super/muscle cars */}
      {(isSuper || isMuscle) && (
        <>
          <mesh position={[0, hh + cabH + 0.18, -(hd / 2 - 0.6)]} castShadow>
            <boxGeometry args={[hw - 0.08, 0.1, 0.55]} />
            <meshLambertMaterial color={bodyColor} />
          </mesh>
          <mesh position={[-(hw / 2 - 0.25), hh + cabH + 0.05, -(hd / 2 - 0.6)]}>
            <boxGeometry args={[0.1, 0.28, 0.3]} />
            <meshLambertMaterial color={bodyColor} />
          </mesh>
          <mesh position={[hw / 2 - 0.25, hh + cabH + 0.05, -(hd / 2 - 0.6)]}>
            <boxGeometry args={[0.1, 0.28, 0.3]} />
            <meshLambertMaterial color={bodyColor} />
          </mesh>
        </>
      )}

      {/* Exhaust pipes for muscle */}
      {isMuscle && (
        <>
          <mesh position={[-(hw / 2 - 0.3), hh * 0.12, -(hd / 2 + 0.12)]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.14, 0.14, 0.3, 6]} />
            <meshLambertMaterial color="#888" />
          </mesh>
          <mesh position={[hw / 2 - 0.3, hh * 0.12, -(hd / 2 + 0.12)]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.14, 0.14, 0.3, 6]} />
            <meshLambertMaterial color="#888" />
          </mesh>
        </>
      )}

      {/* Armored plating overlay */}
      {isArmored && (
        <>
          <mesh position={[0, hh / 2, 0]}>
            <boxGeometry args={[hw + 0.24, hh + 0.18, hd + 0.24]} />
            <meshLambertMaterial color="#333" wireframe />
          </mesh>
          {/* Side armor plates */}
          <mesh position={[hw / 2 + 0.12, hh * 0.5, 0]}>
            <boxGeometry args={[0.1, hh * 0.55, hd * 0.7]} />
            <meshLambertMaterial color="#2a2a2a" />
          </mesh>
          <mesh position={[-(hw / 2 + 0.12), hh * 0.5, 0]}>
            <boxGeometry args={[0.1, hh * 0.55, hd * 0.7]} />
            <meshLambertMaterial color="#2a2a2a" />
          </mesh>
        </>
      )}

      {/* Classic chrome bumpers */}
      {isClassic && (
        <>
          <mesh position={[0, hh * 0.28, hd / 2 + 0.12]}>
            <boxGeometry args={[hw + 0.1, 0.14, 0.14]} />
            <meshLambertMaterial color="#cccccc" emissive="#888888" emissiveIntensity={0.2} />
          </mesh>
          <mesh position={[0, hh * 0.28, -(hd / 2 + 0.12)]}>
            <boxGeometry args={[hw + 0.1, 0.14, 0.14]} />
            <meshLambertMaterial color="#cccccc" emissive="#888888" emissiveIntensity={0.2} />
          </mesh>
          {/* Running boards */}
          <mesh position={[hw / 2 + 0.15, 0.12, 0]}>
            <boxGeometry args={[0.18, 0.1, hd * 0.65]} />
            <meshLambertMaterial color="#999" />
          </mesh>
          <mesh position={[-(hw / 2 + 0.15), 0.12, 0]}>
            <boxGeometry args={[0.18, 0.1, hd * 0.65]} />
            <meshLambertMaterial color="#999" />
          </mesh>
        </>
      )}

      {/* Super car front splitter */}
      {isSuper && (
        <mesh position={[0, 0.05, hd / 2 + 0.18]}>
          <boxGeometry args={[hw * 0.8, 0.08, 0.4]} />
          <meshLambertMaterial color="#111" />
        </mesh>
      )}

      {/* Roof detail */}
      <mesh position={[0, hh + cabH + 0.06, 0]}>
        <boxGeometry args={[hw - 0.5, 0.06, isClassic ? hd * 0.35 : hd * 0.28]} />
        <meshLambertMaterial color={isSUV ? bodyColor : "#1a1a1a"} />
      </mesh>
    </>
  );
}

function Vehicle({ def, setGameState, gameState }: {
  def: VehicleDef;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  gameState: GameState;
}) {
  const ref = useRef<THREE.Group>(null);

  useFrame(() => {
    if (!ref.current || gameState.inVehicle) return;

    const dx = def.startX - playerWorldPos.x;
    const dz = def.startZ - playerWorldPos.z;
    const distSq = dx * dx + dz * dz;
    ref.current.visible = distSq < 220 * 220;

    const dist = Math.sqrt(distSq);
    const near = dist < 5.5;
    setGameState((s) => {
      if (s.nearVehicle === near && s.vehicleName === (near ? def.name : "")) return s;
      return {
        ...s, nearVehicle: near,
        vehicleName: near ? def.name : s.inVehicle ? s.vehicleName : "",
        vehicleCategory: near ? def.category : s.vehicleCategory,
      };
    });
  });

  return (
    <group ref={ref} position={[def.startX, 0, def.startZ]} rotation={[0, def.rotation ?? 0, 0]}>
      <VehicleMesh color={def.color} bodyColor={def.bodyColor} type={def.type} />
    </group>
  );
}

export default function Vehicles({ setGameState, gameState }: Props) {
  return (
    <group>
      {VEHICLE_DEFS.map((v) => (
        <Vehicle key={v.id} def={v} setGameState={setGameState} gameState={gameState} />
      ))}
    </group>
  );
}

export { CAT_COLORS };
