/**
 * WeaponSystem — RDR2-inspired weapon carry limits + car trunk storage
 *
 * • Max 2 carried weapons (sidearm + primary)
 * • Heavy weapons (rifle, sniper, RPG) must be in car trunk
 * • Access trunk when near/in vehicle
 * • Visual carry wheel UI
 */

import { useState, useCallback } from "react";
import { GameState, WeaponSlot } from "./types";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

const WEAPON_CATALOG: WeaponSlot[] = [
  { id: "fists",    name: "Fists",         ammo: 999, maxAmmo: 999, icon: "👊", heavy: false },
  { id: "pistol",   name: "Pistol",         ammo: 30,  maxAmmo: 100, icon: "🔫", heavy: false },
  { id: "smg",      name: "SMG",            ammo: 50,  maxAmmo: 150, icon: "🔫", heavy: false },
  { id: "rifle",    name: "Assault Rifle",  ammo: 90,  maxAmmo: 250, icon: "🔫", heavy: true  },
  { id: "shotgun",  name: "Shotgun",        ammo: 12,  maxAmmo: 48,  icon: "🔫", heavy: true  },
  { id: "sniper",   name: "Sniper Rifle",   ammo: 8,   maxAmmo: 24,  icon: "🎯", heavy: true  },
  { id: "rpg",      name: "RPG",            ammo: 3,   maxAmmo: 8,   icon: "💣", heavy: true  },
  { id: "minigun",  name: "Minigun",        ammo: 200, maxAmmo: 600, icon: "🔫", heavy: true  },
  { id: "knife",    name: "Combat Knife",   ammo: 999, maxAmmo: 999, icon: "🗡️", heavy: false },
];

function WeaponCard({
  slot, active, onClick, inTrunk = false,
}: {
  slot: WeaponSlot; active: boolean; onClick: () => void; inTrunk?: boolean;
}) {
  return (
    <div onClick={onClick} style={{
      background: active
        ? "rgba(255,180,0,0.25)"
        : inTrunk ? "rgba(60,30,0,0.6)" : "rgba(20,20,40,0.8)",
      border: `1.5px solid ${active ? "rgba(255,200,0,0.7)" : inTrunk ? "rgba(150,80,0,0.4)" : "rgba(255,255,255,0.1)"}`,
      borderRadius: 10, padding: "6px 10px",
      display: "flex", alignItems: "center", gap: 8,
      cursor: "pointer", transition: "all 0.2s",
      boxShadow: active ? "0 0 12px rgba(255,180,0,0.3)" : "none",
    }}>
      <span style={{ fontSize: 20 }}>{slot.icon}</span>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: "monospace", fontSize: 10, fontWeight: 900, color: active ? "#ffd700" : inTrunk ? "#cc8800" : "#ccc" }}>
          {slot.name}
        </div>
        {slot.ammo < 999 && (
          <div style={{ fontFamily: "monospace", fontSize: 9, color: slot.ammo === 0 ? "#ff2222" : "#888" }}>
            {slot.ammo} / {slot.maxAmmo}
          </div>
        )}
      </div>
      {slot.heavy && (
        <div style={{
          background: "rgba(200,80,0,0.35)", borderRadius: 4, padding: "1px 5px",
          fontFamily: "monospace", fontSize: 7, color: "#ff8800", fontWeight: 700,
        }}>TRUNK</div>
      )}
      {active && <div style={{ fontSize: 10, color: "#ffd700" }}>✓</div>}
    </div>
  );
}

export default function WeaponSystem({ gameState, setGameState }: Props) {
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"carried" | "trunk">("carried");

  const equip = useCallback((slot: WeaponSlot) => {
    // Can only equip carried weapons directly
    if (slot.heavy && !gameState.inVehicle) return;
    setGameState((s) => ({
      ...s,
      weapon: slot.id,
      ammo: slot.ammo,
      maxAmmo: slot.maxAmmo,
    }));
    setOpen(false);
  }, [gameState.inVehicle, setGameState]);

  const moveToTrunk = useCallback((slot: WeaponSlot) => {
    if (!gameState.inVehicle) return;
    setGameState((s) => ({
      ...s,
      carriedWeapons: s.carriedWeapons.filter((w) => w.id !== slot.id),
      trunkWeapons: [...s.trunkWeapons, slot],
    }));
  }, [gameState.inVehicle, setGameState]);

  const takeFromTrunk = useCallback((slot: WeaponSlot) => {
    if (!gameState.inVehicle) return;
    const carried = gameState.carriedWeapons;
    const lightSlots = carried.filter((w) => !w.heavy).length;
    if (lightSlots >= gameState.maxCarrySlots && !slot.heavy) return; // full
    setGameState((s) => ({
      ...s,
      trunkWeapons: s.trunkWeapons.filter((w) => w.id !== slot.id),
      carriedWeapons: [...s.carriedWeapons, slot],
    }));
  }, [gameState.inVehicle, gameState.carriedWeapons, gameState.maxCarrySlots, setGameState]);

  const carriedCount = gameState.carriedWeapons?.length ?? 0;
  const maxSlots = gameState.maxCarrySlots ?? 2;
  const slotsUsed = carriedCount;

  return (
    <>
      {/* Weapon wheel button */}
      <div
        onClick={() => setOpen((o) => !o)}
        style={{
          position: "fixed", bottom: 205, right: 14,
          width: 52, height: 38,
          background: open ? "rgba(255,180,0,0.25)" : "rgba(0,0,0,0.82)",
          border: `1.5px solid ${open ? "rgba(255,200,0,0.6)" : "rgba(255,255,255,0.12)"}`,
          borderRadius: 9, cursor: "pointer", pointerEvents: "all", zIndex: 400,
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          gap: 1, transition: "all 0.2s",
          boxShadow: open ? "0 0 14px rgba(255,180,0,0.3)" : "none",
        }}
      >
        <span style={{ fontSize: 14 }}>🔫</span>
        <span style={{ fontFamily: "monospace", fontSize: 6, color: open ? "#ffd700" : "#666", fontWeight: 900 }}>WEAPONS</span>
        <span style={{ fontFamily: "monospace", fontSize: 6, color: "#888" }}>{slotsUsed}/{maxSlots}</span>
      </div>

      {/* Weapon panel */}
      {open && (
        <div style={{
          position: "fixed", bottom: 250, right: 72,
          width: 240, maxHeight: "55vh",
          background: "rgba(0,0,0,0.96)", border: "1.5px solid rgba(255,180,0,0.25)",
          borderRadius: 14, overflow: "hidden", zIndex: 405,
          boxShadow: "0 4px 30px rgba(0,0,0,0.7)",
          pointerEvents: "all",
        }}>
          {/* Header */}
          <div style={{ padding: "8px 12px", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(255,150,0,0.08)" }}>
            <div style={{ fontFamily: "monospace", fontWeight: 900, fontSize: 12, color: "#ffd700" }}>⚔️ WEAPON LOADOUT</div>
            <div style={{ fontFamily: "monospace", fontSize: 8, color: "#888", marginTop: 2 }}>
              {slotsUsed}/{maxSlots} carry slots used
              {!gameState.inVehicle && <span style={{ color: "#cc8800" }}> · Enter vehicle for trunk</span>}
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display: "flex", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
            {(["carried", "trunk"] as const).map((tab) => (
              <div key={tab} onClick={() => setActiveTab(tab)} style={{
                flex: 1, padding: "5px 0", textAlign: "center",
                fontFamily: "monospace", fontSize: 9, fontWeight: 900, cursor: "pointer",
                color: activeTab === tab ? "#ffd700" : "#555",
                borderBottom: activeTab === tab ? "2px solid #ffd700" : "2px solid transparent",
                background: activeTab === tab ? "rgba(255,180,0,0.1)" : "transparent",
                transition: "all 0.2s",
              }}>
                {tab === "carried" ? `🎒 ON BODY (${slotsUsed})` : `🚗 TRUNK (${gameState.trunkWeapons?.length ?? 0})`}
              </div>
            ))}
          </div>

          {/* Lists */}
          <div style={{ overflowY: "auto", maxHeight: 260, padding: 8, display: "flex", flexDirection: "column", gap: 5 }}>
            {activeTab === "carried" ? (
              <>
                {(gameState.carriedWeapons ?? []).map((slot) => (
                  <div key={slot.id}>
                    <WeaponCard
                      slot={slot}
                      active={gameState.weapon === slot.id}
                      onClick={() => equip(slot)}
                    />
                    {gameState.inVehicle && (
                      <div
                        onClick={() => moveToTrunk(slot)}
                        style={{
                          fontFamily: "monospace", fontSize: 8, color: "#cc8800",
                          cursor: "pointer", textAlign: "right", padding: "1px 4px",
                          marginTop: 1,
                        }}
                      >
                        → Move to Trunk
                      </div>
                    )}
                  </div>
                ))}
                {(gameState.carriedWeapons ?? []).length === 0 && (
                  <div style={{ fontFamily: "monospace", fontSize: 9, color: "#444", padding: 8, textAlign: "center" }}>
                    No weapons on body
                  </div>
                )}
              </>
            ) : (
              <>
                {!gameState.inVehicle && (
                  <div style={{
                    fontFamily: "monospace", fontSize: 9, color: "#cc8800",
                    background: "rgba(150,80,0,0.15)", borderRadius: 6, padding: "5px 8px",
                    border: "1px solid rgba(150,80,0,0.3)",
                  }}>
                    🚗 Enter a vehicle to access trunk
                  </div>
                )}
                {(gameState.trunkWeapons ?? []).map((slot) => (
                  <div key={slot.id}>
                    <WeaponCard slot={slot} active={false} onClick={() => {}} inTrunk />
                    {gameState.inVehicle && (
                      <div
                        onClick={() => takeFromTrunk(slot)}
                        style={{
                          fontFamily: "monospace", fontSize: 8, color: "#44cc88",
                          cursor: "pointer", textAlign: "right", padding: "1px 4px",
                          marginTop: 1,
                        }}
                      >
                        ← Equip from Trunk
                      </div>
                    )}
                  </div>
                ))}
                {(gameState.trunkWeapons ?? []).length === 0 && (
                  <div style={{ fontFamily: "monospace", fontSize: 9, color: "#444", padding: 8, textAlign: "center" }}>
                    Trunk is empty
                  </div>
                )}
              </>
            )}
          </div>

          {/* Carry limit tip */}
          <div style={{
            padding: "5px 10px", borderTop: "1px solid rgba(255,255,255,0.04)",
            fontFamily: "monospace", fontSize: 8, color: "#444",
          }}>
            💡 Heavy weapons must be stored in vehicle trunk
          </div>
        </div>
      )}
    </>
  );
}
