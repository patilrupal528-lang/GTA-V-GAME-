import { useState } from "react";
import { GameState } from "./types";

interface Props {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  onClose: () => void;
}

const SHOP_ITEMS = [
  { id: "health_pack", name: "Health Pack", desc: "Restore 50 HP", price: 200, icon: "❤️", type: "health" },
  { id: "armor_vest", name: "Armor Vest", desc: "Restore 50 AP", price: 300, icon: "🛡️", type: "armor" },
  { id: "pistol_ammo", name: "Pistol Ammo x30", desc: "Reload your pistol", price: 150, icon: "🔫", type: "ammo" },
  { id: "rifle", name: "Assault Rifle", desc: "High damage weapon", price: 1500, icon: "🔫", type: "weapon_rifle" },
  { id: "shotgun", name: "Shotgun", desc: "Spread shot", price: 1200, icon: "🔫", type: "weapon_shotgun" },
  { id: "sniper", name: "Sniper Rifle", desc: "Long range precision", price: 2000, icon: "🎯", type: "weapon_sniper" },
  { id: "wanted_clear", name: "Bribe Police", desc: "Clear wanted level", price: 1000, icon: "⭐", type: "wanted_clear" },
];

export default function ShopSystem({ gameState, setGameState, onClose }: Props) {
  const [msg, setMsg] = useState("");

  const buy = (item: typeof SHOP_ITEMS[0]) => {
    if (gameState.money < item.price) {
      setMsg(`❌ Not enough money! Need $${item.price}`);
      return;
    }
    let updates: Partial<GameState> = { money: gameState.money - item.price };
    if (item.type === "health") updates.health = Math.min(100, gameState.health + 50);
    else if (item.type === "armor") updates.armor = Math.min(100, gameState.armor + 50);
    else if (item.type === "ammo") { updates.ammo = gameState.maxAmmo; updates.weapon = gameState.weapon || "pistol"; }
    else if (item.type === "weapon_rifle") { updates.weapon = "rifle"; updates.ammo = 30; updates.maxAmmo = 30; }
    else if (item.type === "weapon_shotgun") { updates.weapon = "shotgun"; updates.ammo = 8; updates.maxAmmo = 8; }
    else if (item.type === "weapon_sniper") { updates.weapon = "sniper"; updates.ammo = 10; updates.maxAmmo = 10; }
    else if (item.type === "wanted_clear") updates.wanted = 0;
    setGameState((s) => ({ ...s, ...updates }));
    setMsg(`✅ Bought ${item.name}!`);
    setTimeout(() => setMsg(""), 2000);
  };

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)",
      zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "monospace",
    }}>
      <div style={{
        background: "#111", border: "2px solid rgba(255,255,255,0.15)",
        borderRadius: 16, padding: 28, width: "min(520px, 95vw)", maxHeight: "80vh",
        overflowY: "auto",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#fff" }}>🏪 AMMU-NATION</div>
            <div style={{ fontSize: 12, color: "#888" }}>Your one-stop weapon shop</div>
          </div>
          <div>
            <div style={{ color: "#00e060", fontSize: 18, fontWeight: 900 }}>${gameState.money.toLocaleString()}</div>
            <button onClick={onClose} style={{
              background: "#333", border: "1px solid #666", borderRadius: 6,
              color: "#fff", padding: "4px 12px", cursor: "pointer", marginTop: 4, fontSize: 12,
            }}>CLOSE</button>
          </div>
        </div>

        {msg && (
          <div style={{
            background: msg.startsWith("✅") ? "rgba(0,100,0,0.5)" : "rgba(100,0,0,0.5)",
            border: "1px solid rgba(255,255,255,0.2)", borderRadius: 8,
            padding: "8px 14px", marginBottom: 14, color: "#fff", fontSize: 13,
          }}>{msg}</div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {SHOP_ITEMS.map((item) => (
            <div key={item.id} style={{
              display: "flex", alignItems: "center", gap: 14,
              background: "rgba(255,255,255,0.05)", borderRadius: 10,
              padding: "12px 14px", border: "1px solid rgba(255,255,255,0.08)",
            }}>
              <span style={{ fontSize: 26 }}>{item.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>{item.name}</div>
                <div style={{ color: "#888", fontSize: 11 }}>{item.desc}</div>
              </div>
              <button
                onClick={() => buy(item)}
                style={{
                  background: gameState.money >= item.price ? "rgba(0,160,60,0.8)" : "rgba(80,80,80,0.6)",
                  border: "1px solid rgba(255,255,255,0.2)", borderRadius: 8,
                  color: "#fff", padding: "7px 14px", cursor: gameState.money >= item.price ? "pointer" : "not-allowed",
                  fontFamily: "monospace", fontWeight: 700, fontSize: 13,
                  transition: "background 0.2s",
                }}
              >
                ${item.price.toLocaleString()}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
