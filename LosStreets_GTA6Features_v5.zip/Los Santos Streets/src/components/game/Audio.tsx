import { useEffect, useRef } from "react";
import { useGameStore } from "../../store/gameStore";

let audioCtx: AudioContext | null = null;
let engineGain: GainNode | null = null;
let engineOsc: OscillatorNode | null = null;
let ambientGain: GainNode | null = null;
let isEngineOn = false;

function getAudioCtx(): AudioContext {
  if (!audioCtx) audioCtx = new AudioContext();
  return audioCtx;
}

export function playGunshot() {
  try {
    const ctx = getAudioCtx();
    const buf = ctx.createBuffer(1, ctx.sampleRate * 0.18, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      const t = i / ctx.sampleRate;
      data[i] = (Math.random() * 2 - 1) * Math.exp(-t * 40) * (1 - t * 5);
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    g.gain.value = 0.55;
    const distort = ctx.createWaveShaper();
    const curve = new Float32Array(256);
    for (let i = 0; i < 256; i++) curve[i] = ((i / 128) - 1) * 2;
    distort.curve = curve;
    src.connect(distort);
    distort.connect(g);
    g.connect(ctx.destination);
    src.start();
    g.gain.setTargetAtTime(0, ctx.currentTime + 0.06, 0.04);
  } catch {}
}

export function playExplosion() {
  try {
    const ctx = getAudioCtx();
    const buf = ctx.createBuffer(1, ctx.sampleRate * 1.2, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      const t = i / ctx.sampleRate;
      data[i] = (Math.random() * 2 - 1) * Math.exp(-t * 3.5) * 1.5;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    g.gain.value = 0.9;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 400;
    src.connect(lp);
    lp.connect(g);
    g.connect(ctx.destination);
    src.start();
    g.gain.setTargetAtTime(0, ctx.currentTime + 0.5, 0.3);
  } catch {}
}

export function playCheckpoint() {
  try {
    const ctx = getAudioCtx();
    const freqs = [523.25, 659.25, 783.99, 1046.5];
    freqs.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = f;
      g.gain.value = 0;
      osc.connect(g);
      g.connect(ctx.destination);
      const t = ctx.currentTime + i * 0.12;
      g.gain.setTargetAtTime(0.18, t, 0.01);
      g.gain.setTargetAtTime(0, t + 0.1, 0.06);
      osc.start(t);
      osc.stop(t + 0.4);
    });
  } catch {}
}

export function playPickup() {
  try {
    const ctx = getAudioCtx();
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(660, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(1320, ctx.currentTime + 0.1);
    g.gain.value = 0.15;
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.15);
  } catch {}
}

function startEngine(speed: number) {
  try {
    const ctx = getAudioCtx();
    if (!engineOsc) {
      engineOsc = ctx.createOscillator();
      engineGain = ctx.createGain();
      const dist = ctx.createWaveShaper();
      const c = new Float32Array(256);
      for (let i = 0; i < 256; i++) {
        const x = (i * 2) / 256 - 1;
        c[i] = (Math.PI + 200) * x / (Math.PI + 200 * Math.abs(x));
      }
      dist.curve = c;
      engineOsc.type = "sawtooth";
      engineOsc.frequency.value = 80 + speed * 1.5;
      engineGain.gain.value = 0.06;
      const lp = ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 800;
      engineOsc.connect(dist);
      dist.connect(lp);
      lp.connect(engineGain);
      engineGain.connect(ctx.destination);
      engineOsc.start();
      isEngineOn = true;
    }
  } catch {}
}

function updateEngine(speed: number) {
  if (!engineOsc || !engineGain || !audioCtx) return;
  engineOsc.frequency.setTargetAtTime(80 + speed * 2.2, audioCtx.currentTime, 0.1);
  engineGain.gain.setTargetAtTime(speed > 1 ? 0.07 : 0.03, audioCtx.currentTime, 0.1);
}

function stopEngine() {
  try {
    if (engineGain && audioCtx) {
      engineGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.2);
      setTimeout(() => {
        try { engineOsc?.stop(); } catch {}
        engineOsc = null;
        engineGain = null;
        isEngineOn = false;
      }, 400);
    }
  } catch {}
}

function startAmbient() {
  try {
    const ctx = getAudioCtx();
    if (ambientGain) return;
    ambientGain = ctx.createGain();
    ambientGain.gain.value = 0.018;
    const buf = ctx.createBuffer(1, ctx.sampleRate * 4, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    noise.buffer = buf;
    noise.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = "bandpass";
    lp.frequency.value = 600;
    lp.Q.value = 0.4;
    noise.connect(lp);
    lp.connect(ambientGain);
    ambientGain.connect(ctx.destination);
    noise.start();
  } catch {}
}

export default function AudioEngine() {
  const prevInVehicle = useRef(false);
  const prevSpeed = useRef(0);
  const started = useRef(false);

  useEffect(() => {
    const unsub = useGameStore.subscribe(
      (s) => ({ inVehicle: s.gameState.inVehicle, speed: s.gameState.vehicleSpeed }),
      ({ inVehicle, speed }) => {
        if (!started.current) return;
        if (inVehicle && !prevInVehicle.current) {
          startEngine(speed);
        } else if (!inVehicle && prevInVehicle.current) {
          stopEngine();
        } else if (inVehicle) {
          updateEngine(speed);
        }
        prevInVehicle.current = inVehicle;
        prevSpeed.current = speed;
      }
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    const handleInteraction = () => {
      if (started.current) return;
      started.current = true;
      try { getAudioCtx().resume(); } catch {}
      startAmbient();
    };
    window.addEventListener("touchstart", handleInteraction, { once: true });
    window.addEventListener("mousedown", handleInteraction, { once: true });
    window.addEventListener("keydown", handleInteraction, { once: true });
    return () => {
      window.removeEventListener("touchstart", handleInteraction);
      window.removeEventListener("mousedown", handleInteraction);
      window.removeEventListener("keydown", handleInteraction);
    };
  }, []);

  return null;
}
