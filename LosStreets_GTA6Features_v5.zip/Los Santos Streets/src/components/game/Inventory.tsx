import { useState } from "react";
import { GameState } from "./types";

interface Props {
  gameState: GameState;
  onClose: () => void;
}

const WEAPON_STATS: Record<string, { damage: number; range: string; rate: string; desc: string }> = {
  pistol:  { damage: 35, range: "Medium", rate: "4/s",  desc: "Standard sidearm. Reliable and fast." },
  rifle:   { damage: 65, range: "Long",   rate: "8/s",  desc: "Automatic rifle. High fire rate." },
  shotgun: { damage: 90, range: "Short",  rate: "1/s",  desc: "Devastating at close range." },
  sniper:  { damage: 150, range: "Very Long", rate: "0.5/s", desc: "One-shot precision at long range." },
};

export default function Inventory({ gameState, onClose }: Props) {
  const [tab, setTab] = useState<"weapons" | "items">("weapons");

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.90)",
      zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "monospace",
    }}>
      <div style={{
        background: "linear-gradient(160deg, #111 0%, #151525 100%)",
        border: "2px solid rgba(255,255,255,0.12)",
        borderRadius: 20, padding: 28, width: "min(560px, 95vw)",
        maxHeight: "85vh", overflowY: "auto",
      }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#fff" }}>🎒 INVENTORY</div>
            <div style={{ fontSize: 11, color: "#666" }}>Weapons & collected items</div>
          </div>
          <button onClick={onClose} style={{
            background: "#333", border: "1px solid #555", borderRadius: 8,
            color: "#fff", padding: "6px 14px", cursor: "pointer", fontFamily: "monospace",
          }}>✕ CLOSE</button>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          {(["weapons", "items"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                background: tab === t ? "rgba(60,100,200,0.6)" : "rgba(255,255,255,0.05)",
                border: `1px solid ${tab === t ? "rgba(100,160,255,0.5)" : "rgba(255,255,255,0.1)"}`,
                borderRadius: 8, color: tab === t ? "#fff" : "#888",
                padding: "7px 18px", cursor: "pointer", fontFamily: "monospace",
                fontWeight: tab === t ? 700 : 400, fontSize: 13, textTransform: "uppercase",
              }}
            >
              {t === "weapons" ? "🔫 Weapons" : "📦 Items"}
            </button>
          ))}
        </div>

        {/* Stats row */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 20,
        }}>
          {[
            { label: "Kills", value: gameState.kills, icon: "🎯" },
            { label: "Deaths", value: gameState.deaths, icon: "💀" },
            { label: "Money", value: `$${gameState.money.toLocaleString()}`, icon: "💰" },
            { label: "Score", value: gameState.score.toLocaleString(), icon: "🏆" },
          ].map((s) => (
            <div key={s.label} style={{
              background: "rgba(255,255,255,0.04)", borderRadius: 10,
              padding: "10px 8px", textAlign: "center",
            }}>
              <div style={{ fontSize: 18 }}>{s.icon}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#fff", marginTop: 2 }}>{s.value}</div>
              <div style={{ fontSize: 10, color: "#666" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Content */}
        {tab === "weapons" ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {["pistol", "rifle", "shotgun", "sniper"].map((w) => {
              const stats = WEAPON_STATS[w];
              const isEquipped = gameState.weapon === w;
              const hasWeapon = w === "pistol" || gameState.inventory.some((i) => i.id === `weapon_${w}`) || isEquipped;
              return (
                <div key={w} style={{
                  background: isEquipped ? "rgba(60,100,60,0.4)" : hasWeapon ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.3)",
                  border: `1px solid ${isEquipped ? "rgba(100,200,100,0.4)" : "rgba(255,255,255,0.08)"}`,
                  borderRadius: 10, padding: "12px 14px",
                  opacity: hasWeapon ? 1 : 0.4,
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                        <span style={{ fontSize: 20 }}>🔫</span>
                        <span style={{ fontSize: 15, fontWeight: 700, color: "#fff", textTransform: "uppercase" }}>{w}</span>
                        {isEquipped && (
                          <span style={{
                            background: "rgba(0,200,80,0.3)", border: "1px solid rgba(0,200,80,0.5)",
                            borderRadius: 4, padding: "1px 7px", fontSize: 9, color: "#00cc50", fontWeight: 700,
                          }}>EQUIPPED</span>
                        )}
                        {!hasWeapon && (
                          <span style={{ fontSize: 10, color: "#666" }}>NOT OWNED</span>
                        )}
                      </div>
                      <div style={{ fontSize: 11, color: "#888" }}>{stats.desc}</div>
                    </div>
                    {isEquipped && (
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontSize: 16, fontWeight: 900, color: gameState.ammo <= 5 ? "#ff4444" : "#fff" }}>
                          {gameState.ammo}
                        </div>
                        <div style={{ fontSize: 10, color: "#666" }}>/ {gameState.maxAmmo}</div>
                      </div>
                    )}
                  </div>
                  {hasWeapon && (
                    <div style={{ display: "flex", gap: 14, marginTop: 8 }}>
                      <StatPill label="DMG" value={stats.damage} max={150} color="#ff4444" />
                      <StatPill label="RATE" value={stats.rate} />
                      <StatPill label="RANGE" value={stats.range} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {gameState.inventory.length === 0 ? (
              <div style={{ color: "#555", textAlign: "center", padding: "30px 0", fontSize: 14 }}>
                No items collected yet.<br />
                <span style={{ fontSize: 12, color: "#444" }}>Walk over glowing pickups in the city!</span>
              </div>
            ) : (
              gameState.inventory.map((item) => (
                <div key={item.id} style={{
                  display: "flex", alignItems: "center", gap: 14,
                  background: "rgba(255,255,255,0.05)", borderRadius: 10, padding: "10px 14px",
                }}>
                  <span style={{ fontSize: 24 }}>{item.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: "#fff", fontWeight: 700, fontSize: 13, textTransform: "capitalize" }}>
                      {item.name.replace(/_/g, " ")}
                    </div>
                  </div>
                  <div style={{
                    background: "rgba(255,255,255,0.1)", borderRadius: 6,
                    padding: "3px 10px", fontSize: 13, fontWeight: 700, color: "#ddd",
                  }}>
                    ×{item.quantity}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function StatPill({ label, value, max, color }: { label: string; value: string | number; max?: number; color?: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
      <div style={{ fontSize: 9, color: "#555" }}>{label}</div>
      {typeof value === "number" && max ? (
        <div style={{ width: 60, height: 5, background: "rgba(255,255,255,0.1)", borderRadius: 3, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${(value / max) * 100}%`, background: color || "#4488ff", borderRadius: 3 }} />
        </div>
      ) : (
        <div style={{ fontSize: 11, color: "#aaa", fontWeight: 700 }}>{value}</div>
      )}
    </div>
  );
}
