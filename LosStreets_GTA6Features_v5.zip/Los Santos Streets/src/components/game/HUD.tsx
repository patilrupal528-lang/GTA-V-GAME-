import { GameState } from "./types";
import { CAT_COLORS } from "./Vehicles";

interface Props {
  gameState: GameState;
  onToggleNoCrash: () => void;
  onOpenInventory: () => void;
  onOpenWardrobe: () => void;
  onToggleRain: () => void;
  raining: boolean;
}

function WantedStars({ count }: { count: number }) {
  return (
    <div style={{ display: "flex", gap: 2 }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i} style={{
          fontSize: 17, fontWeight: 900,
          color: i <= count ? "#ffd700" : "#333",
          textShadow: i <= count ? "0 0 10px #ffd700, 0 0 20px #cc8800" : "none",
          transition: "all 0.25s",
        }}>★</span>
      ))}
    </div>
  );
}

function Bar({ val, max, gradient, icon }: { val: number; max: number; gradient: string; icon: string }) {
  const pct = Math.max(0, Math.min(100, (val / max) * 100));
  const low = pct < 25;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 5, width: 195 }}>
      <span style={{ fontSize: 13, width: 18 }}>{icon}</span>
      <div style={{
        flex: 1, height: 11, background: "rgba(0,0,0,0.65)",
        borderRadius: 5, border: "1px solid rgba(255,255,255,0.1)", overflow: "hidden",
      }}>
        <div style={{
          width: `${pct}%`, height: "100%", borderRadius: 5,
          background: low ? "#ff2222" : gradient,
          boxShadow: low ? "0 0 8px #ff0000" : "none",
          transition: "width 0.3s, background 0.3s",
        }} />
      </div>
      <span style={{
        fontSize: 11, color: low ? "#ff6666" : "#ddd",
        width: 26, textAlign: "right", fontFamily: "monospace", fontWeight: 700,
      }}>{Math.round(val)}</span>
    </div>
  );
}

/* ── Leonida MiniMap ────────────────────────────────────────────────────────── */
function LeonidaMiniMap({ px, pz }: { px: number; pz: number }) {
  // World extents: x ≈ -420 to +400, z ≈ -620 to +680
  const WORLD_X_MIN = -420, WORLD_X_MAX = 420;
  const WORLD_Z_MIN = -650, WORLD_Z_MAX = 700;
  const WORLD_W = WORLD_X_MAX - WORLD_X_MIN;
  const WORLD_H = WORLD_Z_MAX - WORLD_Z_MIN;

  function toMap(wx: number, wz: number) {
    return {
      l: Math.max(2, Math.min(97, ((wx - WORLD_X_MIN) / WORLD_W) * 100)),
      t: Math.max(2, Math.min(97, ((wz - WORLD_Z_MIN) / WORLD_H) * 100)),
    };
  }

  const player = toMap(px, pz);

  const regions = [
    // Atlantic Ocean (east strip)
    { l: 82, t: 28, w: 18, h: 44, color: "rgba(20,80,180,0.7)", label: "" },
    // Ocean Drive beach
    { l: 76, t: 29, w: 6,  h: 42, color: "rgba(200,180,60,0.55)", label: "" },
    // Vice City core
    { l: 54, t: 30, w: 22, h: 34, color: "rgba(50,60,80,0.85)", label: "" },
    // Nightclub strip
    { l: 58, t: 62, w: 18, h: 9, color: "rgba(120,0,80,0.6)", label: "" },
    // Leonida Keys (south chain)
    { l: 58, t: 68, w: 12, h: 26, color: "rgba(20,140,140,0.7)", label: "" },
    // Grassrivers (west swamp)
    { l: 6,  t: 38, w: 28, h: 34, color: "rgba(20,60,20,0.8)", label: "" },
    // Grassrivers water channels
    { l: 10, t: 46, w: 22, h: 5,  color: "rgba(10,80,60,0.65)", label: "" },
    { l: 8,  t: 54, w: 24, h: 4,  color: "rgba(10,80,60,0.65)", label: "" },
    // Port Gellhorn
    { l: 4,  t: 16, w: 24, h: 18, color: "rgba(60,60,60,0.85)", label: "" },
    // Port Gellhorn docks water
    { l: 4,  t: 12, w: 24, h: 5,  color: "rgba(20,50,90,0.7)", label: "" },
    // Lake Leonida
    { l: 40, t: 8,  w: 20, h: 14, color: "rgba(20,90,160,0.75)", label: "" },
    // Lake Leonida beach ring
    { l: 38, t: 6,  w: 24, h: 18, color: "rgba(180,160,80,0.4)", label: "" },
    // Mount Caliga base
    { l: 28, t: 0,  w: 36, h: 9,  color: "rgba(70,90,60,0.85)", label: "" },
    // Snow peak
    { l: 42, t: 0,  w: 10, h: 5,  color: "rgba(230,240,255,0.9)", label: "" },
    // VC parks / green
    { l: 55, t: 42, w: 6,  h: 5,  color: "rgba(40,120,40,0.7)", label: "" },
    // VC Airport (south VC)
    { l: 56, t: 62, w: 14, h: 7,  color: "rgba(40,40,50,0.85)", label: "" },
  ];

  const landmarks = [
    { l: 68, t: 36, color: "#ff44aa",  icon: "⬥", tip: "VICE CITY" },
    { l: 14, t: 20, color: "#888",     icon: "⬦", tip: "PORT GELLHORN" },
    { l: 15, t: 48, color: "#1a6a1a",  icon: "⬦", tip: "GRASSRIVERS" },
    { l: 48, t: 10, color: "#4488ff",  icon: "⬦", tip: "LAKE LEONIDA" },
    { l: 45, t: 2,  color: "#aaccff",  icon: "▲", tip: "MT CALIGA" },
    { l: 62, t: 70, color: "#1a8888",  icon: "⬥", tip: "LEONIDA KEYS" },
    { l: 82, t: 38, color: "#4488ff",  icon: "~", tip: "OCEAN" },
    { l: 68, t: 56, color: "#ff2244",  icon: "✚", tip: "HOSPITAL" },
    { l: 58, t: 38, color: "#2244cc",  icon: "★", tip: "LCPD" },
    { l: 72, t: 62, color: "#444",     icon: "✈", tip: "AIRPORT" },
  ];

  return (
    <div style={{
      width: 138, height: 138, borderRadius: "50%",
      background: "rgba(0,10,22,0.94)", border: "2.5px solid rgba(255,200,0,0.3)",
      position: "relative", overflow: "hidden",
      boxShadow: "0 0 24px rgba(0,0,0,0.8), inset 0 0 18px rgba(0,0,0,0.6)",
    }}>
      {/* Base ground */}
      <div style={{ position: "absolute", inset: 0, background: "rgba(35,45,28,0.8)" }} />

      {/* Region fills */}
      {regions.map((r, i) => (
        <div key={i} style={{
          position: "absolute",
          left: `${r.l}%`, top: `${r.t}%`,
          width: `${r.w}%`, height: `${r.h}%`,
          background: r.color,
        }} />
      ))}

      {/* Road grid */}
      {/* N-S highway */}
      <div style={{ position: "absolute", top: 0, bottom: 0, left: "68%", width: 2, background: "#333" }} />
      <div style={{ position: "absolute", top: 0, bottom: 0, left: "58%", width: 1, background: "#2a2a2a" }} />
      <div style={{ position: "absolute", top: 0, bottom: 0, left: "79%", width: 1, background: "#2a2a2a" }} />
      {/* E-W highway */}
      <div style={{ position: "absolute", left: 0, right: 0, top: "48%", height: 2, background: "#333" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: "38%", height: 1, background: "#2a2a2a" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: "58%", height: 1, background: "#2a2a2a" }} />
      {/* Keys bridge */}
      <div style={{ position: "absolute", left: "62%", top: "64%", width: 1, height: "20%", background: "#444" }} />
      {/* Mt Caliga road */}
      <div style={{ position: "absolute", left: "46%", top: 0, width: 1, height: "28%", background: "#2a2a2a" }} />

      {/* Landmark icons */}
      {landmarks.map((lm, i) => (
        <div key={i} style={{
          position: "absolute", left: `${lm.l}%`, top: `${lm.t}%`,
          transform: "translate(-50%,-50%)",
          fontSize: 8, color: lm.color, fontWeight: 900,
          textShadow: `0 0 4px ${lm.color}`,
          zIndex: 4,
        }}>
          {lm.icon}
        </div>
      ))}

      {/* NPC dots */}
      {[[42,46],[58,52],[36,55],[72,42],[60,38],[44,58],[56,44],[38,62],[65,50]].map(([l, t], i) => (
        <div key={i} style={{
          position: "absolute", width: 3, height: 3, borderRadius: "50%",
          background: "#44aaff", left: `${l}%`, top: `${t}%`,
          transform: "translate(-50%,-50%)", opacity: 0.7, zIndex: 5,
        }} />
      ))}

      {/* Player dot */}
      <div style={{
        position: "absolute",
        left: `${player.l}%`, top: `${player.t}%`,
        width: 10, height: 10, borderRadius: "50%",
        background: "#ffd700", border: "1.5px solid #fff",
        transform: "translate(-50%,-50%)",
        boxShadow: "0 0 8px #ffd700",
        zIndex: 10,
      }} />

      {/* Region labels */}
      <div style={{ position: "absolute", left: "60%", top: "36%", fontSize: 6.5, color: "#ff88cc", fontFamily: "monospace", fontWeight: 900, letterSpacing: 0.5, transform: "translate(-50%,-50%)", zIndex: 8, textShadow: "0 0 4px #ff44aa" }}>VC</div>
      <div style={{ position: "absolute", left: "16%", top: "47%", fontSize: 5.5, color: "#44cc44", fontFamily: "monospace", fontWeight: 700, transform: "translate(-50%,-50%)", zIndex: 8 }}>GR</div>
      <div style={{ position: "absolute", left: "14%", top: "23%", fontSize: 5.5, color: "#aaa", fontFamily: "monospace", fontWeight: 700, transform: "translate(-50%,-50%)", zIndex: 8 }}>PG</div>
      <div style={{ position: "absolute", left: "47%", top: "13%", fontSize: 5.5, color: "#88bbff", fontFamily: "monospace", fontWeight: 700, transform: "translate(-50%,-50%)", zIndex: 8 }}>LL</div>
      <div style={{ position: "absolute", left: "46%", top: "4%", fontSize: 5.5, color: "#cceeff", fontFamily: "monospace", fontWeight: 700, transform: "translate(-50%,-50%)", zIndex: 8 }}>MC</div>
      <div style={{ position: "absolute", left: "63%", top: "77%", fontSize: 5.5, color: "#88dddd", fontFamily: "monospace", fontWeight: 700, transform: "translate(-50%,-50%)", zIndex: 8 }}>KEYS</div>

      {/* Compass */}
      <div style={{ position: "absolute", top: 3, left: "50%", transform: "translateX(-50%)", fontSize: 9, fontWeight: 900, color: "#ff4444", fontFamily: "monospace", zIndex: 12 }}>N</div>
      <div style={{ position: "absolute", bottom: 3, left: "50%", transform: "translateX(-50%)", fontSize: 9, color: "#888", fontFamily: "monospace", zIndex: 12 }}>S</div>
      <div style={{ position: "absolute", right: 5, top: "50%", transform: "translateY(-50%)", fontSize: 9, color: "#888", fontFamily: "monospace", zIndex: 12 }}>E</div>
      <div style={{ position: "absolute", left: 5, top: "50%", transform: "translateY(-50%)", fontSize: 9, color: "#888", fontFamily: "monospace", zIndex: 12 }}>W</div>

      {/* Vignette */}
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: "radial-gradient(circle, transparent 52%, rgba(0,0,0,0.72) 100%)", zIndex: 11 }} />
    </div>
  );
}

function WeaponBox({ weapon, ammo, maxAmmo }: { weapon: string | null; ammo: number; maxAmmo: number }) {
  if (!weapon) return null;
  const icons: Record<string, string> = { pistol: "🔫", rifle: "🔫", shotgun: "🔫", sniper: "🎯" };
  const names: Record<string, string> = { pistol: "PISTOL", rifle: "RIFLE", shotgun: "SHOTGUN", sniper: "SNIPER" };
  return (
    <div style={{
      background: "rgba(0,0,0,0.72)", border: "1px solid rgba(255,255,255,0.14)",
      borderRadius: 10, padding: "6px 14px", display: "flex", alignItems: "center", gap: 10,
    }}>
      <span style={{ fontSize: 22 }}>{icons[weapon] || "🔫"}</span>
      <div>
        <div style={{ fontSize: 9, color: "#888", letterSpacing: 2, fontFamily: "monospace" }}>{names[weapon] || weapon.toUpperCase()}</div>
        <div style={{
          fontFamily: "monospace", fontWeight: 900, fontSize: 20,
          color: ammo === 0 ? "#ff2222" : ammo <= 5 ? "#ff8800" : "#fff",
        }}>
          {ammo} <span style={{ fontSize: 11, color: "#666" }}>/ {maxAmmo}</span>
        </div>
      </div>
    </div>
  );
}

export default function HUD({ gameState, onToggleNoCrash, onOpenInventory, onOpenWardrobe, onToggleRain, raining }: Props) {
  const hrs  = Math.floor(gameState.timeOfDay * 24);
  const mins = Math.floor((gameState.timeOfDay * 24 * 60) % 60);
  const isPM = hrs >= 12;
  const h12  = hrs % 12 || 12;
  const timeStr = `${h12}:${String(mins).padStart(2, "0")} ${isPM ? "PM" : "AM"}`;
  const isNight = gameState.timeOfDay < 0.22 || gameState.timeOfDay > 0.78;
  const catColor = gameState.vehicleCategory ? (CAT_COLORS[gameState.vehicleCategory] ?? "#aaa") : "#aaa";

  return (
    <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 10, userSelect: "none" }}>

      {/* TOP-LEFT — Branding + Quick Buttons */}
      <div style={{
        position: "absolute", top: 12, left: 12,
        background: "rgba(0,0,0,0.82)", borderRadius: 12,
        padding: "8px 12px", border: "1px solid rgba(255,200,0,0.15)",
        display: "flex", flexDirection: "column", gap: 5,
      }}>
        <div style={{ fontWeight: 900, color: "#fff", fontSize: 18, letterSpacing: 3, lineHeight: 1 }}>GTA VI</div>
        <div style={{ fontSize: 8, color: "#ff88cc", fontWeight: 700, letterSpacing: 3, marginBottom: 2 }}>LEONIDA STATE</div>

        <button onClick={onToggleNoCrash} style={{
          pointerEvents: "all",
          background: gameState.noCrash ? "rgba(0,180,60,0.4)" : "rgba(60,60,60,0.4)",
          border: `1px solid ${gameState.noCrash ? "rgba(0,255,100,0.5)" : "rgba(150,150,150,0.2)"}`,
          borderRadius: 6, color: gameState.noCrash ? "#00ff66" : "#777",
          fontSize: 10, fontFamily: "monospace", padding: "3px 8px", cursor: "pointer",
          fontWeight: 700, letterSpacing: 0.5, display: "block", width: "100%",
          boxShadow: gameState.noCrash ? "0 0 12px rgba(0,255,80,0.3)" : "none",
          transition: "all 0.3s",
        }}>
          {gameState.noCrash ? "🛡️ GOD MODE ON" : "☠ MORTAL"}
        </button>

        <button onClick={onOpenInventory} style={{
          pointerEvents: "all",
          background: "rgba(40,60,160,0.4)", border: "1px solid rgba(80,120,255,0.3)",
          borderRadius: 6, color: "#8899ff", fontSize: 10, fontFamily: "monospace",
          padding: "3px 8px", cursor: "pointer", display: "block", width: "100%", fontWeight: 700,
        }}>🎒 INVENTORY [I]</button>

        <button onClick={onOpenWardrobe} style={{
          pointerEvents: "all",
          background: "rgba(120,40,160,0.4)", border: "1px solid rgba(200,100,255,0.3)",
          borderRadius: 6, color: "#cc88ff", fontSize: 10, fontFamily: "monospace",
          padding: "3px 8px", cursor: "pointer", display: "block", width: "100%", fontWeight: 700,
        }}>👕 WARDROBE [C]</button>
      </div>

      {/* TOP-RIGHT — Money + Time + Wanted + Stats */}
      <div style={{ position: "absolute", top: 12, right: 12, display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5 }}>
        <div style={{
          background: "rgba(0,0,0,0.82)", borderRadius: 8, padding: "5px 14px",
          fontFamily: "monospace", fontWeight: 900, fontSize: 22, color: "#00e060",
          textShadow: "0 0 12px #00cc44", border: "1px solid rgba(0,200,80,0.2)",
        }}>
          ${gameState.money.toLocaleString()}
        </div>

        <div style={{
          background: "rgba(0,0,0,0.75)", borderRadius: 8, padding: "4px 12px",
          fontFamily: "monospace", fontSize: 13, color: "#ccc",
          border: "1px solid rgba(255,255,255,0.07)",
        }}>
          {isNight ? "🌙" : "☀️"} {timeStr}
        </div>

        <div style={{
          background: "rgba(0,0,0,0.75)", borderRadius: 8, padding: "5px 12px",
          border: "1px solid rgba(255,255,255,0.07)",
        }}>
          <WantedStars count={gameState.wanted} />
        </div>

        <div style={{
          background: "rgba(0,0,0,0.55)", borderRadius: 6, padding: "3px 10px",
          fontFamily: "monospace", fontSize: 11, color: "#888",
          display: "flex", gap: 12,
        }}>
          <span>🏆 {gameState.score.toLocaleString()}</span>
          <span>🎯 {gameState.kills}</span>
          <span>💀 {gameState.deaths}</span>
        </div>

        {/* Location badge */}
        <div style={{
          background: "rgba(0,0,0,0.65)", borderRadius: 6, padding: "3px 10px",
          fontFamily: "monospace", fontSize: 10, color: "#ff88cc",
          border: "1px solid rgba(255,100,180,0.2)",
        }}>
          📍 {getRegionName(gameState.playerX, gameState.playerZ)}
        </div>

        {gameState.character?.outfitName && (
          <div style={{
            background: "rgba(80,40,120,0.5)", borderRadius: 6, padding: "2px 10px",
            fontFamily: "monospace", fontSize: 10, color: "#cc88ff",
            border: "1px solid rgba(180,100,255,0.3)",
          }}>
            👕 {gameState.character.outfitName}
          </div>
        )}
      </div>

      {/* BOTTOM-LEFT — HP/Armor + Minimap */}
      <div style={{
        position: "absolute", bottom: 14, left: 12,
        display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-start",
      }}>
        <div style={{
          background: "rgba(0,0,0,0.78)", borderRadius: 10, padding: "8px 12px",
          border: "1px solid rgba(255,255,255,0.07)", display: "flex", flexDirection: "column", gap: 5,
        }}>
          <Bar val={gameState.health} max={100} gradient="linear-gradient(90deg,#cc2020,#ff5555)" icon="❤️" />
          <Bar val={gameState.armor}  max={100} gradient="linear-gradient(90deg,#2060cc,#55aaff)" icon="🛡️" />
        </div>
        <LeonidaMiniMap px={gameState.playerX} pz={gameState.playerZ} />
      </div>

      {/* BOTTOM-RIGHT — Vehicle + Weapon */}
      <div style={{ position: "absolute", bottom: 14, right: 12, display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
        {gameState.inVehicle && (
          <div style={{
            background: "rgba(0,0,0,0.85)", borderRadius: 10, padding: "8px 16px",
            textAlign: "center", border: "1px solid rgba(255,255,255,0.1)",
          }}>
            {gameState.vehicleName && (
              <div style={{ fontFamily: "monospace", fontSize: 11, color: catColor, fontWeight: 700, letterSpacing: 1, marginBottom: 2 }}>
                {gameState.vehicleName}
              </div>
            )}
            {gameState.vehicleCategory && (
              <div style={{ fontFamily: "monospace", fontSize: 9, color: "#555", letterSpacing: 1, marginBottom: 4 }}>
                {gameState.vehicleCategory.toUpperCase()}
              </div>
            )}
            <div style={{ fontFamily: "monospace", fontWeight: 900, fontSize: 32, color: "#fff", lineHeight: 1 }}>
              {gameState.vehicleSpeed}
            </div>
            <div style={{ fontSize: 9, color: "#666", fontWeight: 700, letterSpacing: 1 }}>MPH</div>
          </div>
        )}
        <WeaponBox weapon={gameState.weapon} ammo={gameState.ammo} maxAmmo={gameState.maxAmmo} />
      </div>

      {/* MISSION BANNER */}
      {gameState.missionText && (
        <div style={{
          position: "absolute", top: 58, left: "50%", transform: "translateX(-50%)",
          background: gameState.missionActive ? "rgba(0,30,80,0.92)" : "rgba(0,0,0,0.75)",
          border: `1px solid ${gameState.missionActive ? "rgba(255,100,200,0.5)" : "rgba(255,255,255,0.1)"}`,
          borderRadius: 10, padding: "7px 22px", maxWidth: 520,
          textAlign: "center", backdropFilter: "blur(8px)",
          boxShadow: gameState.missionActive ? "0 4px 20px rgba(255,60,180,0.2)" : "none",
        }}>
          <div style={{ fontSize: 12, color: gameState.missionActive ? "#ffccee" : "#cce4ff", fontFamily: "monospace", lineHeight: 1.5 }}>
            {gameState.missionText}
          </div>
        </div>
      )}

      {/* CONTEXTUAL PROMPTS */}
      <div style={{
        position: "absolute", top: "42%", left: "50%", transform: "translateX(-50%)",
        display: "flex", flexDirection: "column", gap: 6, alignItems: "center", pointerEvents: "none",
      }}>
        {gameState.nearVehicle && !gameState.inVehicle && (
          <Prompt color="#ffd700" border="rgba(255,200,0,0.5)">
            🚗 <b>{gameState.vehicleName}</b> — Press <b>F</b> to Enter
            {gameState.vehicleCategory && (
              <span style={{ marginLeft: 8, fontSize: 10, color: catColor }}>({gameState.vehicleCategory})</span>
            )}
          </Prompt>
        )}
        {gameState.swimming && (
          <Prompt color="#66ccff" border="rgba(50,150,255,0.5)">
            🌊 Swimming in the Atlantic! Return to shore
          </Prompt>
        )}
        {gameState.wanted >= 3 && (
          <Prompt color="#ff4444" border="rgba(255,50,50,0.5)" pulse>
            ⚠ LCPD PURSUIT — WANTED {gameState.wanted} STARS
          </Prompt>
        )}
        {gameState.ammo === 0 && gameState.weapon && (
          <Prompt color="#ff8800" border="rgba(255,120,0,0.5)">
            🔫 OUT OF AMMO — Visit Ammu-Nation!
          </Prompt>
        )}
        {gameState.noCrash && (
          <div style={{
            background: "rgba(0,180,60,0.15)", border: "1px solid rgba(0,255,80,0.3)",
            borderRadius: 6, padding: "3px 16px",
            color: "#00ff66", fontFamily: "monospace", fontSize: 11, fontWeight: 700,
          }}>
            🛡️ GOD MODE ACTIVE
          </div>
        )}
      </div>

      {/* Desktop hint */}
      <div style={{
        position: "absolute", bottom: 10, left: "50%", transform: "translateX(-50%)",
        background: "rgba(0,0,0,0.5)", borderRadius: 6, padding: "3px 16px",
        fontSize: 10, color: "#555", fontFamily: "monospace", display: "none",
      }} className="desktop-hint">
        WASD Move &nbsp;|&nbsp; Shift Run &nbsp;|&nbsp; Space Shoot &nbsp;|&nbsp; F Car &nbsp;|&nbsp; I Inventory &nbsp;|&nbsp; C Wardrobe &nbsp;|&nbsp; P Pause
      </div>

      <style>{`
        @media (min-width:768px) { .desktop-hint { display:block !important; } }
        @keyframes pulse { from{opacity:1} to{opacity:0.45} }
      `}</style>
    </div>
  );
}

function Prompt({ color, border, pulse = false, children }: {
  color: string; border: string; pulse?: boolean; children: React.ReactNode;
}) {
  return (
    <div style={{
      background: "rgba(0,0,0,0.82)", border: `1px solid ${border}`,
      borderRadius: 7, padding: "5px 18px",
      color, fontFamily: "monospace", fontSize: 12, fontWeight: 700,
      animation: pulse ? "pulse 0.5s infinite alternate" : "none",
      textAlign: "center",
    }}>
      {children}
    </div>
  );
}

function getRegionName(x: number, z: number): string {
  if (z > 250)         return "Leonida Keys";
  if (z > 130 && x < -60) return "Grassrivers";
  if (z > 0   && x > 200) return "Ocean Drive";
  if (z > -20 && x > 60)  return "Vice City";
  if (z < -200 && z > -360) return "Lake Leonida";
  if (z < -360)        return "Mount Caliga";
  if (x < -180 && z < -130) return "Port Gellhorn";
  if (x < -60 && z > 50) return "Grassrivers";
  return "Leonida State";
}
