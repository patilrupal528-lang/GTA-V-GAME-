import { Component, ReactNode } from "react";

interface Props { children: ReactNode; }
interface State { hasError: boolean; error: string; }

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: "" };

  static getDerivedStateFromError(err: Error): State {
    return { hasError: true, error: err.message };
  }

  componentDidCatch(err: Error, info: any) {
    console.error("[GTA V Mobile] Caught error:", err, info);
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: "" });
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div style={{
        position: "fixed", inset: 0,
        background: "linear-gradient(135deg, #0a0010 0%, #100020 100%)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "monospace", zIndex: 9999,
      }}>
        <div style={{
          textAlign: "center", padding: 36, maxWidth: 480,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,50,50,0.4)",
          borderRadius: 16,
        }}>
          {/* GTA-style wasted */}
          <div style={{
            fontSize: 48, fontWeight: 900, color: "#cc0000",
            letterSpacing: 8, marginBottom: 8,
            textShadow: "0 0 30px #ff0000, 0 0 60px #880000",
            animation: "pulse 1s infinite alternate",
          }}>
            ERROR
          </div>
          <div style={{ fontSize: 13, color: "#ff8888", marginBottom: 20, lineHeight: 1.6 }}>
            {this.state.error || "An unexpected error occurred"}
          </div>
          <div style={{ fontSize: 11, color: "#666", marginBottom: 24, lineHeight: 1.8 }}>
            No-Crash System activated.<br />
            Your game progress is auto-saved.<br />
            Click retry to resume playing.
          </div>
          <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
            <button
              onClick={this.handleRetry}
              style={{
                background: "#006030", border: "1px solid #00aa60",
                borderRadius: 8, color: "#fff", padding: "10px 24px",
                fontFamily: "monospace", fontWeight: 700, fontSize: 14,
                cursor: "pointer",
              }}
            >
              ▶ RETRY
            </button>
            <button
              onClick={() => window.location.reload()}
              style={{
                background: "#303030", border: "1px solid #666",
                borderRadius: 8, color: "#aaa", padding: "10px 24px",
                fontFamily: "monospace", fontWeight: 700, fontSize: 14,
                cursor: "pointer",
              }}
            >
              ↺ RELOAD
            </button>
          </div>
        </div>
        <style>{`@keyframes pulse { from { opacity:1 } to { opacity:0.6 } }`}</style>
      </div>
    );
  }
}
