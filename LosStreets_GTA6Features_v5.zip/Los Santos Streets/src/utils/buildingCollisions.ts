import * as THREE from "three";

export interface BuildingAABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

const PAD = 0.9;

// Leonida map building colliders — grouped by region
const RAW_BUILDINGS: { x: number; z: number; w: number; d: number }[] = [
  // ── VICE CITY DOWNTOWN ──────────────────────────────────────────
  { x: 80,  z: -20,  w: 12, d: 12 }, { x: 100, z: -10, w: 10, d: 10 },
  { x: 120, z: -30,  w: 9,  d: 9  }, { x: 140, z: -15, w: 11, d: 11 },
  { x: 160, z: -25,  w: 8,  d: 8  }, { x: 100, z: -40, w: 8,  d: 8  },
  { x: 120, z: -50,  w: 10, d: 10 }, { x: 140, z: -45, w: 7,  d: 7  },
  { x: 160, z: -45,  w: 9,  d: 9  }, { x: 80,  z: -50, w: 8,  d: 8  },
  { x: 180, z: -20,  w: 8,  d: 8  }, { x: 200, z: -35, w: 10, d: 10 },
  { x: 60,  z: -30,  w: 8,  d: 8  }, { x: 60,  z: -55, w: 7,  d: 7  },
  { x: 220, z: -20,  w: 9,  d: 9  }, { x: 220, z: -45, w: 8,  d: 8  },
  // ── OCEAN DRIVE / BEACH STRIP ────────────────────────────────────
  { x: 250, z: 20,   w: 8,  d: 6  }, { x: 250, z: 40,  w: 7,  d: 6  },
  { x: 250, z: 60,   w: 8,  d: 6  }, { x: 250, z: 80,  w: 7,  d: 6  },
  { x: 250, z: 100,  w: 8,  d: 6  }, { x: 250, z: 120, w: 7,  d: 6  },
  { x: 230, z: 30,   w: 10, d: 8  }, { x: 230, z: 70,  w: 9,  d: 8  },
  { x: 230, z: 110,  w: 10, d: 8  },
  // ── VICE CITY SUBURBS ────────────────────────────────────────────
  { x: 50,  z: 30,   w: 9,  d: 9  }, { x: 70,  z: 50,  w: 7,  d: 7  },
  { x: 50,  z: 60,   w: 8,  d: 8  }, { x: 30,  z: 40,  w: 7,  d: 7  },
  { x: 30,  z: 70,   w: 8,  d: 8  }, { x: 10,  z: 50,  w: 7,  d: 7  },
  // ── PORT GELLHORN ────────────────────────────────────────────────
  { x: -280,z: -200, w: 20, d: 15 }, { x: -310,z: -220,w: 18, d: 14 },
  { x: -330,z: -195, w: 12, d: 12 }, { x: -280,z: -250,w: 16, d: 12 },
  { x: -310,z: -260, w: 14, d: 11 }, { x: -350,z: -220,w: 10, d: 10 },
  { x: -260,z: -215, w: 10, d: 10 }, { x: -340,z: -250,w: 12, d: 12 },
  { x: -300,z: -280, w: 14, d: 10 }, { x: -260,z: -280,w: 10, d: 10 },
  // ── GRASSRIVERS STRUCTURES ───────────────────────────────────────
  { x: -100,z: 80,   w: 8,  d: 8  }, { x: -130,z: 100, w: 7,  d: 7  },
  { x: -110,z: 130,  w: 8,  d: 8  }, { x: -150,z: 80,  w: 6,  d: 6  },
  { x: -80, z: 120,  w: 7,  d: 7  }, { x: -160,z: 130, w: 8,  d: 8  },
  { x: -200,z: 100,  w: 9,  d: 9  }, { x: -200,z: 140, w: 7,  d: 7  },
  // ── MOUNT CALIGA BASE ────────────────────────────────────────────
  { x: 0,   z: -350, w: 10, d: 10 }, { x: -40, z: -370,w: 8,  d: 8  },
  { x: 40,  z: -380, w: 8,  d: 8  }, { x: -20, z: -400,w: 6,  d: 6  },
  // ── LANDMARK COLLIDERS ───────────────────────────────────────────
  { x: 100, z: 50,   w: 24, d: 12 }, // Vice City Mall
  { x: 0,   z: -30,  w: 20, d: 14 }, // Vice City PD
  { x: 150, z: 150,  w: 30, d: 20 }, // VC Airport terminal
  { x: -280,z: -180, w: 30, d: 20 }, // Port Gellhorn docks
];

export const BUILDING_AABBS: BuildingAABB[] = RAW_BUILDINGS.map(({ x, z, w, d }) => ({
  minX: x - w / 2 - PAD,
  maxX: x + w / 2 + PAD,
  minZ: z - d / 2 - PAD,
  maxZ: z + d / 2 + PAD,
}));

export function resolveCollision(position: THREE.Vector3, radius = 0.4): THREE.Vector3 {
  for (const aabb of BUILDING_AABBS) {
    const inX = position.x + radius > aabb.minX && position.x - radius < aabb.maxX;
    const inZ = position.z + radius > aabb.minZ && position.z - radius < aabb.maxZ;

    if (inX && inZ) {
      const overlapLeft  = (position.x + radius) - aabb.minX;
      const overlapRight = aabb.maxX - (position.x - radius);
      const overlapFront = (position.z + radius) - aabb.minZ;
      const overlapBack  = aabb.maxZ - (position.z - radius);

      const minOverlapX = Math.min(overlapLeft, overlapRight);
      const minOverlapZ = Math.min(overlapFront, overlapBack);

      if (minOverlapX < minOverlapZ) {
        position.x += overlapLeft < overlapRight ? -overlapLeft : overlapRight;
      } else {
        position.z += overlapFront < overlapBack ? -overlapFront : overlapBack;
      }
    }
  }
  return position;
}

export function isInsideBuilding(x: number, z: number, radius = 0.4): boolean {
  for (const aabb of BUILDING_AABBS) {
    if (
      x + radius > aabb.minX && x - radius < aabb.maxX &&
      z + radius > aabb.minZ && z - radius < aabb.maxZ
    ) return true;
  }
  return false;
}
