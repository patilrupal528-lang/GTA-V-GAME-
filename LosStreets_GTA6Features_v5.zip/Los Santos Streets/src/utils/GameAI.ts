/**
 * GameAI — Autonomous Self-Healing Game Intelligence
 *
 * Features:
 *  • Silent background operation — zero UI shown to player
 *  • Zero internet usage — all local, uses localStorage only
 *  • Global error trapping + automatic state recovery
 *  • Frame-rate monitoring + dynamic quality adjustment
 *  • State integrity tests every 8 seconds
 *  • State snapshots every 25 seconds
 *  • Auto-save every 90 seconds
 *  • Memory pressure monitoring
 *  • WebGL context-loss recovery
 *  • Exposed as window.__gameAI for DevTools debugging only
 */

import { deviceProfile } from "./DeviceProfile";

type StatePatch = Record<string, unknown>;
type GetStateFn = () => Record<string, unknown> | null;
type PatchStateFn = (patch: StatePatch) => void;

interface ErrorRecord {
  time: number;
  msg: string;
  stack?: string;
}

class AutonomousGameAI {
  private static _instance: AutonomousGameAI | null = null;
  private initialized = false;
  private getState: GetStateFn = () => null;
  private patchState: PatchStateFn = () => {};

  // FPS tracking
  private frameTimes: number[] = [];
  private currentFPS = 60;
  // Start at tier matching detected device — avoids wasting time on downgrade
  private qualityLevel: number = { low: 0, mid: 1, high: 2 }[deviceProfile.tier] ?? 1;

  // Error tracking
  private errors: ErrorRecord[] = [];
  private totalErrors = 0;
  private lastRecovery = 0;

  // Snapshots
  private snapshots: StatePatch[] = [];
  private lastSnapshotAt = 0;

  // Test log (in-memory only, never rendered)
  private log: string[] = [];

  static getInstance(): AutonomousGameAI {
    if (!AutonomousGameAI._instance) {
      AutonomousGameAI._instance = new AutonomousGameAI();
    }
    return AutonomousGameAI._instance;
  }

  /** Call once at app startup — idempotent */
  init(getState: GetStateFn, patchState: PatchStateFn): void {
    if (this.initialized) return;
    this.initialized = true;
    this.getState = getState;
    this.patchState = patchState;

    // ── Global error traps ──────────────────────────────────────
    window.addEventListener("error", this._onError, true);
    window.addEventListener("unhandledrejection", this._onRejection, true);

    // ── WebGL context loss ──────────────────────────────────────
    window.addEventListener("webglcontextlost", (e) => {
      e.preventDefault();
      this._log("WebGL context lost — suspended rendering");
    }, false);
    window.addEventListener("webglcontextrestored", () => {
      this._log("WebGL context restored — resuming");
    }, false);

    // ── Staggered periodic tasks (minimise CPU spikes) ──────────
    //  State tests   — every 8 s, start after 3 s
    setTimeout(() => setInterval(this._runTests, 8_000), 3_000);
    //  Snapshots     — every 25 s, start after 6 s
    setTimeout(() => setInterval(this._snapshot, 25_000), 6_000);
    //  Memory check  — every 20 s, start after 10 s
    setTimeout(() => setInterval(this._checkMemory, 20_000), 10_000);
    //  Auto-save     — every 90 s, start after 15 s
    setTimeout(() => setInterval(this._autoSave, 90_000), 15_000);

    this._log("GameAI v1.0 initialised — silent mode active");

    // Expose for DevTools debugging (not accessible from game UI)
    (window as unknown as Record<string, unknown>).__gameAI = this;
  }

  // ── Called from useFrame — tracks FPS ──────────────────────────
  tick(): void {
    const now = performance.now();
    this.frameTimes.push(now);
    if (this.frameTimes.length > 60) this.frameTimes.shift();

    if (this.frameTimes.length >= 10) {
      const span = now - this.frameTimes[0];
      this.currentFPS = ((this.frameTimes.length - 1) / span) * 1000;

      // Dynamic quality reduction when severely under-performing
      const targetFPS = deviceProfile.maxFPS;
      const dropThreshold = targetFPS * 0.15;   // 15% of target = bad
      const recoverThreshold = targetFPS * 0.65; // 65% of target = good again
      if (this.currentFPS < dropThreshold && this.qualityLevel > 0) {
        this.qualityLevel--;
        window.dispatchEvent(
          new CustomEvent("gameai:quality", { detail: { level: this.qualityLevel } })
        );
        this._log(`Low FPS ${this.currentFPS.toFixed(1)}/${targetFPS} → quality ${this.qualityLevel}`);
      } else if (this.currentFPS > recoverThreshold && this.qualityLevel < 2) {
        this.qualityLevel++;
        window.dispatchEvent(
          new CustomEvent("gameai:quality", { detail: { level: this.qualityLevel } })
        );
        this._log(`FPS recovered ${this.currentFPS.toFixed(1)} → quality ${this.qualityLevel}`);
      }
    }
  }

  // ── Error handlers ──────────────────────────────────────────────
  private _onError = (e: ErrorEvent): void => {
    e.preventDefault();
    this.totalErrors++;
    const rec: ErrorRecord = { time: Date.now(), msg: e.message ?? "unknown", stack: e.error?.stack };
    this.errors.push(rec);
    if (this.errors.length > 10) this.errors.shift();

    const now = Date.now();
    if (now - this.lastRecovery > 3_000) {
      this.lastRecovery = now;
      this._recover();
    }
    this._persistErrors();
  };

  private _onRejection = (e: PromiseRejectionEvent): void => {
    e.preventDefault();
    this.errors.push({ time: Date.now(), msg: `Unhandled promise: ${String(e.reason)}` });
    if (this.errors.length > 10) this.errors.shift();
  };

  // ── State integrity tests ────────────────────────────────────────
  private _runTests = (): void => {
    const s = this.getState();
    if (!s) return;
    const fix: StatePatch = {};
    let dirty = false;

    const clamp = (v: unknown, min: number, max: number, fallback: number): number => {
      const n = typeof v === "number" && !isNaN(v) ? v : fallback;
      return Math.max(min, Math.min(max, n));
    };

    // Health
    const health = clamp(s.health, 0, 100, 100);
    if (health !== s.health) { fix.health = health; dirty = true; }

    // God mode heal
    if (s.noCrash && (s.health as number) < 20) { fix.health = 100; dirty = true; }

    // Armor
    const armor = clamp(s.armor, 0, 100, 0);
    if (armor !== s.armor) { fix.armor = armor; dirty = true; }

    // Ammo
    const ammo = clamp(s.ammo, 0, 9999, 0);
    if (ammo !== s.ammo) { fix.ammo = ammo; dirty = true; }

    // Money
    const money = clamp(s.money, 0, 99_999_999, 0);
    if (money !== s.money) { fix.money = money; dirty = true; }

    // Wanted
    const wanted = clamp(s.wanted, 0, 5, 0);
    if (wanted !== s.wanted) { fix.wanted = wanted; dirty = true; }

    // Vehicle speed display
    if (typeof s.vehicleSpeed !== "number" || isNaN(s.vehicleSpeed as number)) {
      fix.vehicleSpeed = 0; dirty = true;
    }

    if (dirty) {
      this.patchState(fix);
      this._log(`Tests: auto-fixed ${Object.keys(fix).join(", ")}`);
    }
  };

  // ── Snapshot ─────────────────────────────────────────────────────
  private _snapshot = (): void => {
    const s = this.getState();
    if (!s || (s.health as number) <= 0) return;
    const snap: StatePatch = {
      health: s.health, armor: s.armor, money: s.money, score: s.score,
      kills: s.kills, deaths: s.deaths, weapon: s.weapon,
      ammo: s.ammo, maxAmmo: s.maxAmmo,
      inventory: JSON.parse(JSON.stringify(s.inventory ?? [])),
      character: JSON.parse(JSON.stringify(s.character ?? {})),
      _at: Date.now(),
    };
    this.snapshots.push(snap);
    if (this.snapshots.length > 5) this.snapshots.shift();
    this.lastSnapshotAt = Date.now();
    this._log("Snapshot taken");
  };

  // ── Recovery ─────────────────────────────────────────────────────
  private _recover = (): void => {
    if (this.snapshots.length === 0) return;
    const snap = this.snapshots[this.snapshots.length - 1];
    if (!snap || (snap.health as number) <= 0) return;
    // Soft recovery — only patch vital stats, not position/vehicle
    this.patchState({
      health: snap.health,
      armor:  snap.armor,
      wanted: snap.wanted,
    });
    this._log("Partial state recovery from snapshot");
  };

  // ── Memory check ─────────────────────────────────────────────────
  private _checkMemory = (): void => {
    const perf = performance as Performance & { memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number } };
    if (!perf.memory) return;
    const used  = perf.memory.usedJSHeapSize / 1_048_576;  // MB
    const limit = perf.memory.jsHeapSizeLimit / 1_048_576;
    if (used / limit > 0.85) {
      // Trim in-memory caches to relieve pressure
      this.snapshots = this.snapshots.slice(-1);
      this.errors    = this.errors.slice(-3);
      this._log(`Memory pressure ${used.toFixed(0)}/${limit.toFixed(0)} MB — caches trimmed`);
      window.dispatchEvent(new CustomEvent("gameai:memory-pressure"));
    }
  };

  // ── Auto-save ─────────────────────────────────────────────────────
  private _autoSave = (): void => {
    const s = this.getState();
    if (!s || (s.health as number) <= 0) return;
    try {
      localStorage.setItem("gameai_autosave", JSON.stringify({
        health: s.health, armor: s.armor, money: s.money, score: s.score,
        kills: s.kills, deaths: s.deaths, weapon: s.weapon,
        ammo: s.ammo, maxAmmo: s.maxAmmo,
        inventory: s.inventory, character: s.character,
        _savedAt: Date.now(),
      }));
      this._log("Auto-saved");
    } catch { /* storage full — ignore */ }
  };

  // ── Persist error log ─────────────────────────────────────────────
  private _persistErrors = (): void => {
    try {
      localStorage.setItem("gameai_errors", JSON.stringify(this.errors.slice(-5)));
    } catch { /* ignore */ }
  };

  // ── Internal log (DevTools only, never rendered) ──────────────────
  private _log(msg: string): void {
    const entry = `[${new Date().toLocaleTimeString()}] ${msg}`;
    this.log.push(entry);
    if (this.log.length > 40) this.log.shift();
    if (import.meta.env.DEV) console.debug("[GameAI]", msg);
  }

  // ── Public diagnostics (accessible via browser DevTools only) ────
  getReport() {
    return {
      fps:          Math.round(this.currentFPS),
      targetFPS:    deviceProfile.maxFPS,
      quality:      ["Low", "Medium", "High"][this.qualityLevel] ?? "High",
      deviceTier:   deviceProfile.tier,
      resolution:   deviceProfile.resLabel,
      dpr:          deviceProfile.dpr.toFixed(2),
      gpu:          deviceProfile.gpuRenderer,
      totalErrors:  this.totalErrors,
      snapshots:    this.snapshots.length,
      lastSnapshot: this.lastSnapshotAt
        ? new Date(this.lastSnapshotAt).toLocaleTimeString()
        : "none",
      recentErrors: this.errors.slice(-3).map((e) => e.msg),
      log:          this.log.slice(-10),
    };
  }

  /** Restore from last auto-save (called on load) */
  loadAutoSave(): StatePatch | null {
    try {
      const raw = localStorage.getItem("gameai_autosave");
      return raw ? (JSON.parse(raw) as StatePatch) : null;
    } catch { return null; }
  }
}

export const gameAI = AutonomousGameAI.getInstance();
