import { isInsideBuilding } from "./buildingCollisions";

const GRID_SIZE = 2;     // world units per grid cell
const WORLD_MIN = -180;
const WORLD_MAX = 180;
const COLS = Math.ceil((WORLD_MAX - WORLD_MIN) / GRID_SIZE);

function worldToGrid(wx: number, wz: number): [number, number] {
  const gx = Math.floor((wx - WORLD_MIN) / GRID_SIZE);
  const gz = Math.floor((wz - WORLD_MIN) / GRID_SIZE);
  return [
    Math.max(0, Math.min(COLS - 1, gx)),
    Math.max(0, Math.min(COLS - 1, gz)),
  ];
}

function gridToWorld(gx: number, gz: number): [number, number] {
  return [
    WORLD_MIN + gx * GRID_SIZE + GRID_SIZE / 2,
    WORLD_MIN + gz * GRID_SIZE + GRID_SIZE / 2,
  ];
}

function heuristic(ax: number, az: number, bx: number, bz: number): number {
  return Math.abs(ax - bx) + Math.abs(az - bz);
}

function isWalkable(gx: number, gz: number): boolean {
  const [wx, wz] = gridToWorld(gx, gz);
  return !isInsideBuilding(wx, wz, 0.5);
}

interface Node {
  gx: number;
  gz: number;
  g: number;
  f: number;
  parent: Node | null;
}

const DIR8 = [
  [-1,0],[1,0],[0,-1],[0,1],
  [-1,-1],[-1,1],[1,-1],[1,1],
];

/**
 * A* pathfinding from (startX,startZ) to (goalX,goalZ) in world space.
 * Returns an array of [wx, wz] waypoints, or [] if no path found.
 * Max iterations capped for performance.
 */
export function findPath(
  startX: number, startZ: number,
  goalX: number, goalZ: number,
  maxIter = 600
): [number, number][] {
  const [sx, sz] = worldToGrid(startX, startZ);
  const [gx, gz] = worldToGrid(goalX, goalZ);

  if (sx === gx && sz === gz) return [];

  const open: Node[] = [{ gx: sx, gz: sz, g: 0, f: heuristic(sx, sz, gx, gz), parent: null }];
  const closed = new Set<string>();
  const gScore = new Map<string, number>();
  gScore.set(`${sx},${sz}`, 0);

  let iter = 0;

  while (open.length > 0 && iter++ < maxIter) {
    // pop lowest f
    let best = 0;
    for (let i = 1; i < open.length; i++) {
      if (open[i].f < open[best].f) best = i;
    }
    const current = open.splice(best, 1)[0];
    const key = `${current.gx},${current.gz}`;

    if (closed.has(key)) continue;
    closed.add(key);

    if (current.gx === gx && current.gz === gz) {
      // Reconstruct path
      const path: [number, number][] = [];
      let node: Node | null = current;
      while (node) {
        path.unshift(gridToWorld(node.gx, node.gz));
        node = node.parent;
      }
      return simplifyPath(path);
    }

    for (const [dx, dz] of DIR8) {
      const nx = current.gx + dx;
      const nz = current.gz + dz;
      if (nx < 0 || nx >= COLS || nz < 0 || nz >= COLS) continue;
      const nKey = `${nx},${nz}`;
      if (closed.has(nKey)) continue;
      if (!isWalkable(nx, nz)) continue;

      const diag = dx !== 0 && dz !== 0;
      const cost = diag ? 1.414 : 1.0;
      const ng = current.g + cost;

      if (ng >= (gScore.get(nKey) ?? Infinity)) continue;
      gScore.set(nKey, ng);
      open.push({
        gx: nx, gz: nz,
        g: ng,
        f: ng + heuristic(nx, nz, gx, gz),
        parent: current,
      });
    }
  }

  return []; // no path
}

/** Remove collinear waypoints to simplify path */
function simplifyPath(path: [number, number][]): [number, number][] {
  if (path.length <= 2) return path;
  const result: [number, number][] = [path[0]];
  for (let i = 1; i < path.length - 1; i++) {
    const [ax, az] = path[i - 1];
    const [bx, bz] = path[i];
    const [cx, cz] = path[i + 1];
    const cross = (bx - ax) * (cz - az) - (bz - az) * (cx - ax);
    if (Math.abs(cross) > 0.5) result.push(path[i]);
  }
  result.push(path[path.length - 1]);
  return result;
}
