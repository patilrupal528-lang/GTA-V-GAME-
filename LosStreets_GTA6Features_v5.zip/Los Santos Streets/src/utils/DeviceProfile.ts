/**
 * DeviceProfile — Runtime device capability detection
 *
 * Tiers:
 *   low   — budget GPU  → 30 FPS, DPR 1.0  (HD)
 *   mid   — mid GPU     → 60 FPS, DPR 2.0  (2K / QHD)
 *   high  — flagship    → 120 FPS, DPR 4.0 (4K/8K render buffer)
 */

export type DeviceTier = "low" | "mid" | "high";

export interface DeviceProfile {
  tier:        DeviceTier;
  maxFPS:      30 | 60 | 120;
  dpr:         number;
  perfMin:     number;
  starCount:   number;
  antialias:   boolean;
  maxTexSize:  number;
  resLabel:    string;
  gpuRenderer: string;
}

function probeWebGL(): { maxTexSize: number; gpuTier: DeviceTier; renderer: string } {
  let maxTexSize  = 4096;
  let gpuTier: DeviceTier = "mid";
  let renderer    = "unknown";
  try {
    const cv = document.createElement("canvas");
    const gl = (cv.getContext("webgl2") ??
                cv.getContext("webgl") ??
                cv.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (gl) {
      maxTexSize = gl.getParameter(gl.MAX_TEXTURE_SIZE) as number;
      const ext = gl.getExtension("WEBGL_debug_renderer_info");
      if (ext) {
        renderer = (gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) as string) ?? "";
        if (/Adreno[^0-9]*[78]\d\d|Apple GPU|A1[5-9] GPU|A2\d GPU|Mali-G7[1-9]\d|Mali-G9\d\d|ANGLE.*Snapdragon|RTX|RX 6|RX 7|GTX 10|GTX 16|GTX 20/i.test(renderer)) {
          gpuTier = "high";
        } else if (/Adreno[^0-9]*6\d\d|Mali-G[5-7][0-9][0-9]|PowerVR|Tegra|Intel Iris|Intel UHD/i.test(renderer)) {
          gpuTier = "mid";
        } else {
          gpuTier = "low";
        }
      } else {
        if (maxTexSize >= 16384) gpuTier = "high";
        else if (maxTexSize >= 8192) gpuTier = "mid";
        else gpuTier = "low";
      }
    }
  } catch { /* ignore */ }
  return { maxTexSize, gpuTier, renderer };
}

function buildProfile(): DeviceProfile {
  const nav   = navigator as Navigator & { deviceMemory?: number; connection?: { effectiveType?: string } };
  const memGB = nav.deviceMemory ?? 4;
  const cores = navigator.hardwareConcurrency ?? 4;
  const rawDPR = window.devicePixelRatio ?? 1;
  const { maxTexSize, gpuTier, renderer } = probeWebGL();

  const slowNetwork = nav.connection?.effectiveType === "2g" || nav.connection?.effectiveType === "slow-2g";

  let tier: DeviceTier;
  if (memGB >= 8 && cores >= 8 && gpuTier === "high" && !slowNetwork) {
    tier = "high";
  } else if (memGB >= 4 || cores >= 6 || gpuTier === "mid") {
    tier = "mid";
  } else {
    tier = "low";
  }

  // Check for explicit 2K override via URL param (e.g. ?quality=2k)
  const params = new URLSearchParams(window.location.search);
  const qualityParam = params.get("quality");
  if (qualityParam === "2k" || qualityParam === "high") tier = "high";
  if (qualityParam === "low") tier = "low";

  const presets: Record<DeviceTier, Omit<DeviceProfile, "maxTexSize" | "gpuRenderer" | "resLabel">> = {
    low: {
      tier:      "low",
      maxFPS:    30,
      dpr:       Math.min(rawDPR, 1.0),
      perfMin:   0.4,
      starCount: 0,
      antialias: false,
    },
    mid: {
      tier:      "mid",
      maxFPS:    60,
      // 2K support: DPR 2.0 gives 2560×1440 on a 1280×720 screen
      dpr:       Math.min(rawDPR, 2.0),
      perfMin:   0.5,
      starCount: 3000,
      antialias: true,
    },
    high: {
      tier:      "high",
      maxFPS:    120,
      // 4K/8K: DPR 4.0 = 8K render buffer on a 4K screen
      dpr:       Math.min(rawDPR, 4.0),
      perfMin:   0.6,
      starCount: 6000,
      antialias: true,
    },
  };

  const p = presets[tier];

  // Resolution label
  const screenW = window.screen.width  * p.dpr;
  const screenH = window.screen.height * p.dpr;
  const megapixels = (screenW * screenH) / 1_000_000;
  let resLabel: string;
  if (megapixels >= 30)       resLabel = "8K";
  else if (megapixels >= 7.5) resLabel = "4K";
  else if (megapixels >= 3.3) resLabel = "2K / QHD";
  else if (megapixels >= 2)   resLabel = "FHD";
  else                        resLabel = "HD";

  return { ...p, maxTexSize, gpuRenderer: renderer, resLabel };
}

export const deviceProfile: DeviceProfile = buildProfile();

(window as unknown as Record<string, unknown>).__deviceProfile = deviceProfile;
