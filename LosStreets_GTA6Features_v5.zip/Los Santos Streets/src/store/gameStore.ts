import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import {
  GameState, BulletData, ExplosionData,
  DEFAULT_CHARACTER, INITIAL_CARRIED_WEAPONS, TRUNK_WEAPONS_DEFAULT,
} from "../components/game/types";
import { gameAI } from "../utils/GameAI";

const SAVE_KEY = "lss_save_v2";

const DEFAULT_STATE: GameState = {
  health: 100,
  armor: 50,
  money: 5000,
  wanted: 0,
  inVehicle: false,
  vehicleSpeed: 0,
  vehicleName: "",
  vehicleCategory: "",
  timeOfDay: 0.3,
  score: 0,
  ammo: 30,
  maxAmmo: 100,
  weapon: "pistol",
  missionText: "🗺️ Welcome to Leonida! Find the pink checkpoint to start your story.",
  missionActive: true,
  nearVehicle: false,
  noCrash: false,
  swimming: false,
  deaths: 0,
  kills: 0,
  inventory: [],
  playerX: 60,
  playerZ: 0,
  character: DEFAULT_CHARACTER,
  // Stealth
  isProne: false,
  isCrouching: false,
  stealthMode: false,
  // Weapon system
  carriedWeapons: INITIAL_CARRIED_WEAPONS,
  trunkWeapons: TRUNK_WEAPONS_DEFAULT,
  maxCarrySlots: 2,
  // Social
  socialFeedActive: false,
  socialRecordingNpc: false,
  // Interior
  currentInterior: null,
  // Police
  policeAlertLevel: "none",
  // Wildlife
  wildlifeAlert: false,
};

interface GameStore {
  gameState: GameState;
  paused: boolean;
  shopOpen: boolean;
  inventoryOpen: boolean;
  wardrobeOpen: boolean;
  raining: boolean;
  saveMsg: string;
  bullets: BulletData[];
  explosions: ExplosionData[];

  setGameState: (updater: Partial<GameState> | ((prev: GameState) => GameState)) => void;
  setPaused:        (v: boolean | ((p: boolean) => boolean)) => void;
  setShopOpen:      (v: boolean) => void;
  setInventoryOpen: (v: boolean | ((p: boolean) => boolean)) => void;
  setWardrobeOpen:  (v: boolean | ((p: boolean) => boolean)) => void;
  setRaining:       (v: boolean | ((p: boolean) => boolean)) => void;
  setSaveMsg:       (msg: string) => void;

  spawnBullet:    (pos: [number, number, number], dir: [number, number, number]) => void;
  removeBullet:   (id: number) => void;
  spawnExplosion: (x: number, y: number, z: number) => void;
  removeExplosion:(id: number) => void;

  handleSave:    () => void;
  handleLoad:    () => void;
  toggleNoCrash: () => void;
}

let bulletId    = 0;
let explosionId = 0;

function tryLoadSave(): GameState {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<GameState>;
      return {
        ...DEFAULT_STATE, ...p,
        character: { ...DEFAULT_CHARACTER, ...(p.character ?? {}) },
        carriedWeapons: p.carriedWeapons ?? INITIAL_CARRIED_WEAPONS,
        trunkWeapons:   p.trunkWeapons   ?? TRUNK_WEAPONS_DEFAULT,
      };
    }
  } catch { /* ignore */ }
  const aiSave = gameAI.loadAutoSave();
  if (aiSave) {
    return {
      ...DEFAULT_STATE,
      ...(aiSave as Partial<GameState>),
      character: { ...DEFAULT_CHARACTER, ...((aiSave as Record<string, unknown>).character as Partial<GameState["character"]> ?? {}) },
    };
  }
  return DEFAULT_STATE;
}

export const useGameStore = create<GameStore>()(
  subscribeWithSelector((set, get) => ({
    gameState:     tryLoadSave(),
    paused:        false,
    shopOpen:      false,
    inventoryOpen: false,
    wardrobeOpen:  false,
    raining:       false,
    saveMsg:       "",
    bullets:       [],
    explosions:    [],

    setGameState: (updater) => {
      if (typeof updater === "function") {
        set((s) => ({ gameState: updater(s.gameState) }));
      } else {
        set((s) => ({ gameState: { ...s.gameState, ...updater } }));
      }
    },

    setPaused:        (v) => set((s) => ({ paused: typeof v === "function" ? v(s.paused) : v })),
    setShopOpen:      (v) => set({ shopOpen: v }),
    setInventoryOpen: (v) => set((s) => ({ inventoryOpen: typeof v === "function" ? v(s.inventoryOpen) : v })),
    setWardrobeOpen:  (v) => set((s) => ({ wardrobeOpen: typeof v === "function" ? v(s.wardrobeOpen) : v })),
    setRaining:       (v) => set((s) => ({ raining: typeof v === "function" ? v(s.raining) : v })),
    setSaveMsg:       (msg) => set({ saveMsg: msg }),

    spawnBullet: (pos, dir) => {
      set((s) => ({
        bullets: [...s.bullets.slice(-30), { id: bulletId++, position: pos, direction: dir }],
      }));
    },
    removeBullet: (id) => set((s) => ({ bullets: s.bullets.filter((b) => b.id !== id) })),

    spawnExplosion: (x, y, z) => {
      set((s) => ({
        explosions: [...s.explosions.slice(-5), { id: explosionId++, x, y, z, startTime: 0 }],
      }));
    },
    removeExplosion: (id) => set((s) => ({ explosions: s.explosions.filter((e) => e.id !== id) })),

    handleSave: () => {
      try {
        const s = get().gameState;
        localStorage.setItem(SAVE_KEY, JSON.stringify({
          health: s.health, armor: s.armor, money: s.money, wanted: s.wanted,
          score: s.score, ammo: s.ammo, maxAmmo: s.maxAmmo, weapon: s.weapon,
          timeOfDay: s.timeOfDay, deaths: s.deaths, kills: s.kills,
          inventory: s.inventory, character: s.character,
          carriedWeapons: s.carriedWeapons, trunkWeapons: s.trunkWeapons,
        }));
        get().setSaveMsg("✅ Game Saved!");
      } catch { get().setSaveMsg("❌ Save failed."); }
      setTimeout(() => get().setSaveMsg(""), 2500);
    },

    handleLoad: () => {
      try {
        const raw = localStorage.getItem(SAVE_KEY);
        if (raw) {
          const p = JSON.parse(raw) as Partial<GameState>;
          get().setGameState((s) => ({
            ...s, ...p,
            character: { ...DEFAULT_CHARACTER, ...(p.character ?? {}) },
          }));
          get().setSaveMsg("📂 Game Loaded!");
        } else {
          get().setSaveMsg("No save file found.");
        }
      } catch { get().setSaveMsg("❌ Load failed."); }
      setTimeout(() => get().setSaveMsg(""), 2500);
    },

    toggleNoCrash: () => {
      get().setGameState((s) => ({
        ...s,
        noCrash: !s.noCrash,
        health:  !s.noCrash ? 100 : s.health,
        missionText: !s.noCrash
          ? "🛡️ GOD MODE ON — You're invincible!"
          : "⚠️ God Mode OFF — Stay alive!",
      }));
    },
  }))
);

useGameStore.subscribe(() => {});
setTimeout(() => {
  gameAI.init(
    () => useGameStore.getState().gameState as unknown as Record<string, unknown>,
    (patch) => useGameStore.getState().setGameState(patch as Partial<GameState>),
  );
}, 0);
