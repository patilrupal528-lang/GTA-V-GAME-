import { KeyboardControls } from "@react-three/drei";
import Game from "@/pages/Game";
import "./index.css";

enum Controls {
  forward = "forward",
  back    = "back",
  left    = "left",
  right   = "right",
  run     = "run",
  enter   = "enter",
  shoot   = "shoot",
}

const keyMap = [
  { name: Controls.forward, keys: ["ArrowUp",    "KeyW"] },
  { name: Controls.back,    keys: ["ArrowDown",  "KeyS"] },
  { name: Controls.left,    keys: ["ArrowLeft",  "KeyA"] },
  { name: Controls.right,   keys: ["ArrowRight", "KeyD"] },
  { name: Controls.run,     keys: ["ShiftLeft",  "ShiftRight"] },
  { name: Controls.enter,   keys: ["KeyF"] },
  { name: Controls.shoot,   keys: ["Space"] },
];

export default function App() {
  return (
    <KeyboardControls map={keyMap}>
      <Game />
    </KeyboardControls>
  );
}
